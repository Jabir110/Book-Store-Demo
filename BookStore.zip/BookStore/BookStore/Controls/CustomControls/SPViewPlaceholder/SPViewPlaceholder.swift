//
//  BMHViewPlaceholder.swift
//  BestMeHealth
//
//  Created by agileimac-2 on 04/01/19.
//  Copyright © 2019 agileimac-2. All rights reserved.
//

import UIKit

class SPViewPlaceholder: UIView {
    
    //MARK:- OUTLETS
    @IBOutlet private var contentView:UIView?
    @IBOutlet private var titleLabel:SPLabelSemiBold!

    //@IBOutlet fileprivate weak var lblMessage: BMHLabelBlack!
    
    var bgColor:UIColor {
        set {
            contentView?.backgroundColor = newValue
        }
        get {
            return UIColor.white
        }
    }
//    var labelColor:UIColor {
//        set {
//           // self.lblMessage.textColor = newValue
//        }
//        get {
//            return self.lblMessage.textColor
//        }
//    }
    
    
    // MARK:- INIT
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.commonInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func commonInit()    {
        
        // LOADING NIB FILE
        Bundle.main.loadNibNamed("SPViewPlaceholder", owner: self, options: nil)
        self.addSubview(self.contentView!);
        
        // UI
//        self.contentView!.backgroundColor = UIColor.clear
//        self.backgroundColor = UIColor.clear
        
        self.titleLabel?.textColor = UIColor.appColor.appBlackColor
    }
    
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        if((self.superview) != nil){
            self.frame = CGRect(x: 0, y: 0, width: self.superview!.width, height: self.superview!.height)
            self.contentView?.frame = self.frame
        }
    }
    
    //MARK:- SETUP
    func setupPlaceHolderViewWith(message:String){
        self.titleLabel.text = message
    }
    
    
    
    //MARK:- SHOW / HIDE LOADER
    func showLoader(){
        self.titleLabel.isHidden = false
    }
    func hideLoader(){
        self.titleLabel.isHidden = true
    }
    
}
