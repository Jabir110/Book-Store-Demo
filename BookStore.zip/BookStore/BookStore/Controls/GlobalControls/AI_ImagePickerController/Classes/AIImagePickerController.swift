//
//  AIImagePickerController.swift
//
//
//  Created by Agile Infoways.
//  Copyright © 2017 Agile. All rights reserved.
//

/*
 Use this key medetory to add in info.plist
 
Photo :

Key    :  Privacy - Photo Library Usage Description
Value  :  $(PRODUCT_NAME) photo use

Camera :

Key    :  Privacy - Camera Usage Description
Value  :  $(PRODUCT_NAME) camera use

*/

import Foundation
import UIKit
import AVFoundation

public enum AIImagePickerOption:Int{

	case
	camera,
	savedPhotosAlbum,
	photoLibrary,
	askForOption
	
	var name:String {
		switch self {
		case .photoLibrary:
			return "Photo Library"
		case .camera:
			return "Camera"
		case .savedPhotosAlbum:
			return "Saved Photos Album"
		case .askForOption:
			return "Ask for option"
		}
	}
}

open class AIImagePickerController: UIImagePickerController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
	
	//MARK:- PROPERTIES
	public var blockCompletion:((_ isCancelled:Bool,_ pickedImage:UIImage?) -> Void)?
	var option:AIImagePickerOption = .photoLibrary
    let AppName = Bundle.main.infoDictionary![kCFBundleNameKey as String] as! String
    
    // MARK: - SHARED MANAGER
	public static let shared = AIImagePickerController()

	
	//MARK:- SHOW IMAGE PICKER

	
    /// Display image picker with option
    ///
    /// - Parameters:
    ///   - vc: UiViewController
    ///   - option: picker type [.askForOption or .camera]
    ///   - completion: completion from return success and UIImage
	public func showImagePickerFrom(vc:UIViewController,
                             withOption option:AIImagePickerOption,
                             andCompletion completion:@escaping ((_ isCancelled:Bool,_ pickedImage:UIImage?) -> Void)){
		
		self.blockCompletion = completion

		if(option == .askForOption){
			let options:[String] = [AIImagePickerOption.camera.name,
			                        AIImagePickerOption.savedPhotosAlbum.name,
			                        AIImagePickerOption.photoLibrary.name]
			showActionSheetWithTitleFromVC(vc: vc, title: "Choose Option", andMessage: "", buttons: options, canCancel: true, completion: { (index) in
				print("selected option : \(index)")
				
				if(index == options.count){
					if(self.blockCompletion != nil){
						self.blockCompletion!(true, nil)
					}
					return
				}
				self.option = AIImagePickerOption(rawValue: index)!
				self.checkPermissionAndProceedFurther(vc: vc)
			})
		}else{
			self.option = option
			checkPermissionAndProceedFurther(vc: vc)
		}
	}
	
    
    /// Check photo permission
    ///
    /// - Parameter vc: UIViewController
	private func checkPermissionAndProceedFurther(vc:UIViewController){
		
        let cameraMediaType = AVMediaType.video
        let cameraAuthorizationStatus = AVCaptureDevice.authorizationStatus(for: cameraMediaType)
		
		var strMessage = ""
		switch cameraAuthorizationStatus {
		case .denied:
			strMessage = "image : denied"
		case .authorized:
			strMessage = "image : authorized"
		case .restricted:
			strMessage = "image : restricted"
		case .notDetermined:
			strMessage = "image : notDetermined"
		}
		print("IMAGE PERMISSION : \(strMessage)")
		
		if(cameraAuthorizationStatus == .authorized){
			takeOrSelectPhotoFrom(vc: vc)
		}else{
			
			var shouldAlertForGoToSetting:Bool = false
			if(cameraAuthorizationStatus == .notDetermined){
                AVCaptureDevice.requestAccess(for: cameraMediaType) { granted in
					if granted {
						print("Granted access to \(cameraMediaType)")
						self.takeOrSelectPhotoFrom(vc: vc)
					} else {
						print("Denied access to \(cameraMediaType)")
						shouldAlertForGoToSetting = true
					}
				}
			}else{
				shouldAlertForGoToSetting = true
			}

			if(shouldAlertForGoToSetting){
				showAlertWithTitleFromVC(vc: vc, title: AppName, andMessage: "App needs permission to take photo from your library, go to settings and allow access", buttons: ["Dismiss","Settings"], completion: { (index) in
					if(index == 1){
                        if let url = URL(string: UIApplication.openSettingsURLString) {
							
							if #available(iOS 10.0, *) {
								UIApplication.shared.open(url, options: [:], completionHandler: nil)
							} else {
								UIApplication.shared.openURL(url)
							}
						}
					}
				})
			}
		}
	}
	
	
    /// Retun seelcted image
    ///
    /// - Parameter vc: UIViewController
	private func takeOrSelectPhotoFrom(vc:UIViewController){
		
		if self.option == .camera{
			
            if !UIImagePickerController.isCameraDeviceAvailable(UIImagePickerController.CameraDevice.rear) {
				showAlertWithTitleFromVC(vc: vc, title: AppName, andMessage: "Device is not compatible for the required operation", buttons: ["Dismiss"], completion: { (index) in
					if(self.blockCompletion != nil){
						self.blockCompletion!(false, nil)
					}
				})
				return
			}
		}
		
		
		self.delegate = self
		self.allowsEditing = true//false
		
		switch self.option {
		case .photoLibrary:
			self.sourceType = .photoLibrary
		case .savedPhotosAlbum:
			self.sourceType = .savedPhotosAlbum
		case .camera:
			self.sourceType = .camera
		default:
			break
		}
		
		if(UIImagePickerController.isSourceTypeAvailable(self.sourceType)){
			vc.present(self, animated: true) {
			}
		}else{
            showAlertWithTitleFromVC(vc: vc, title: AppName, andMessage: "Device is not compatible for the required operation", buttons: ["Dismiss"], completion: { (index) in
				if(self.blockCompletion != nil){
					self.blockCompletion!(false, nil)
				}
			})
		}
	}
	
	//MARK:- DELEGATE
    
    
    /// Default Deleget for return selected image
    ///
    /// - Parameters:
    ///   - picker: picker type
    ///   - info: piking info [string : Any]
    public func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        
        let imageKey = picker.allowsEditing ? UIImagePickerController.InfoKey.editedImage : UIImagePickerController.InfoKey.originalImage
        
        if let pickedImage = info[imageKey ] as? UIImage {
            
            if(self.blockCompletion != nil){
                self.blockCompletion!(false, pickedImage)
            }
        }else{
            if(self.blockCompletion != nil){
                self.blockCompletion!(false, nil)
            }
        }
        
        dismiss(animated: true) {
        }
    }
    
    public func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {

		if(self.blockCompletion != nil){
			self.blockCompletion!(true, nil)
		}
		dismiss(animated: true) {
            
        }
	}
    
    
    
    //MARK:- ALERT CONTROLLER
    private func showAlertWithTitleFromVC(vc:UIViewController, title:String,
                                  andMessage message:String,
                                  buttons:[String], completion:((_ index:Int) -> Void)!) -> Void {
        
        let newMessage = message
        
        let alertController = UIAlertController(title: title, message: newMessage, preferredStyle: .alert)
        for index in 0..<buttons.count    {
            
            let action = UIAlertAction(title: buttons[index], style: .default, handler: {
                (alert: UIAlertAction!) in
                if(completion != nil){
                    completion(index)
                }
            })
            
            alertController.addAction(action)
        }
        vc.present(alertController, animated: true, completion: nil)
    }
    
    //MARK:- ACTION SHEET
    private func showActionSheetWithTitleFromVC(vc:UIViewController,
                                        title:String, andMessage message:String,
                                        buttons:[String],canCancel:Bool,
                                        completion:((_ index:Int) -> Void)!) -> Void {
        
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .actionSheet)
        
        for index in 0..<buttons.count    {
            
            let action = UIAlertAction(title: buttons[index], style: .default, handler: {
                (alert: UIAlertAction!) in
                if(completion != nil){
                    completion(index)
                }
            })
            
            alertController.addAction(action)
        }
        
        if(canCancel){
            let action = UIAlertAction(title: "Cancel", style: .cancel, handler: {
                (alert: UIAlertAction!) in
                if(completion != nil){
                    completion(buttons.count)
                }
            })
            
            alertController.addAction(action)
        }
        
        vc.present(alertController, animated: true, completion: nil)
    }
    
    
}
