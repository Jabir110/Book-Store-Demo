//
//  AICollectionView.swift
//
//
//  Created by Agile Infoways.
//  Copyright © 2017 Agile. All rights reserved.
//


import UIKit
import TPKeyboardAvoiding


open class AICollectionView: UICollectionView , UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {

   
	
	//MARK:- INIT
    required public init?(coder aDecoder: NSCoder) {
		super.init(coder: aDecoder)
    }
	
    override open func awakeFromNib() {
		super.awakeFromNib()
		commonInit()
	}
	
	private func commonInit(){
		self.delegate = self
		self.dataSource = self
		self.showsVerticalScrollIndicator = false
		self.showsHorizontalScrollIndicator = false
	}
	
    override open func layoutSubviews() {
		super.layoutSubviews()
	}
	
	

	
	
	//MARK:- DATASOURCE
	
    open func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
		return 1
	}
	
    open func numberOfSections(in collectionView: UICollectionView) -> Int {
		return 1
	}
	
    open func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
		return UICollectionViewCell(frame: CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: 50))
	}
    
	
	//MARK:- DELEGATE
}

open class AICollectionView_TPKeyboard: TPKeyboardAvoidingCollectionView , UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    
    
    //MARK:- INIT
    required public init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    override open func awakeFromNib() {
        super.awakeFromNib()
        commonInit()
    }
    
    private func commonInit(){
        self.delegate = self
        self.dataSource = self
        self.showsVerticalScrollIndicator = false
        self.showsHorizontalScrollIndicator = false
    }
    
    override open func layoutSubviews() {
        super.layoutSubviews()
    }
    
    
    
    
    
    //MARK:- DATASOURCE
    
    open func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 1
    }
    
    open func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    open func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        return UICollectionViewCell(frame: CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: 50))
    }
    
    
    //MARK:- DELEGATE
}
