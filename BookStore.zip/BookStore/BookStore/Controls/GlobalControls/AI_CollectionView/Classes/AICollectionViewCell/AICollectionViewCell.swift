//
//  AICollectionViewCell.swift
//
//
//  Created by Agile Infoways.
//  Copyright © 2017 Agile. All rights reserved.
//


import UIKit

open class AICollectionViewCell: UICollectionViewCell {
    
}
