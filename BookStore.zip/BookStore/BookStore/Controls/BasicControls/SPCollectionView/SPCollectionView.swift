//
//  SPCollectionView.swift
//  ServiceProvider
//
//  Created by agileimac-2 on 18/03/19.
//  Copyright © 2019 agileimac-2. All rights reserved.
//

import UIKit

class SPCollectionView: AICollectionView {
    
    //MARK:- PROPERTIES
    var viewPlaceHolder:SPViewPlaceholder!
    var refreshControlTable:UIRefreshControl!
    var blockScrolledCellIndex:((IndexPath)->Void)?

    //MARK:- BLOCK
    public var blockRefreshHandler:(()->Void)?
    
    /// Pulltorefress add in table view background
    public var isPullToRefreshEnabled:Bool
    {
        set {
            if newValue == true {
                //self.refreshControlTable = UIRefreshControl()
                self.addSubview(refreshControlTable)
            }else{
                if refreshControlTable != nil{
                    refreshControlTable.removeFromSuperview()
                }
            }
        }
        get {
            return self.isPullToRefreshEnabled
        }
    }
    //MARK:- INIT
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        commonInit()
    }
    
    private func commonInit(){
        
        self.allowsMultipleSelection = true
        self.backgroundColor = UIColor.clear
        
        
        refreshControlTable = UIRefreshControl()
        refreshControlTable.tintColor = UIColor.black
        refreshControlTable.addTarget(self, action: #selector(self.refresh(sender:)), for: .valueChanged)
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
    }
   
    
    //MARK:- REFRESH CONTROL ACTION
    @objc func refresh(sender:UIRefreshControl) {
        print("\n\n PULL TO REFRESH")
        
        if self.blockRefreshHandler != nil {
            self.blockRefreshHandler!()
        }
        
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 0.5) {
            sender.endRefreshing()
        }
    }
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView)
    {
        
        for cell in self.visibleCells{
            let indexPathForVisibleCell = self.indexPath(for: cell)
            //print("scrollViewDidEndDecelerating \(indexPathForVisibleCell)")
            if self.blockScrolledCellIndex != nil{
                self.blockScrolledCellIndex!(indexPathForVisibleCell!)
            }
        }
    }
    
    //MARK:- SHOW / HIDE LOADER
    func showLoader(with message : String = AILocalization.shared.placeholderNoDataFoundBlank){
        self.viewPlaceHolder = SPViewPlaceholder()
        // self.viewPlaceHolder.labelColor = UIColor.black
        self.viewPlaceHolder.setupPlaceHolderViewWith(message: message)
        self.viewPlaceHolder.frame = self.frame
        self.backgroundView = self.viewPlaceHolder
        
        
        self.viewPlaceHolder.showLoader()
    }
    
    func hideLoader()
    {
        if  self.viewPlaceHolder != nil{
            self.viewPlaceHolder.removeFromSuperview()
        }
        self.backgroundView = nil
    }
    
}
