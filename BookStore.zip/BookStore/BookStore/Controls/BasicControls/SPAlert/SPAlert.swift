//
//  SPAlert.swift
//  ServiceProvider
//
//  Created by agilemac-9 on 3/20/19.
//  Copyright © 2019 agileimac-2. All rights reserved.
//

import Foundation
import UIKit

class SPAlert: NSObject {
    
    static let shared : SPAlert = SPAlert()
    
    /// Show AlertController
    ///
    /// - Parameters:
    ///   - title: set your title
    ///   - message: set your message
    ///   - buttonTitles: set button array
    ///   - completion: completion handler
    func displayAlert(withtitle title: String, message : String, buttons : [String], completion : ((_ selectedIndex : NSInteger) -> Void)?) -> Void {
        
        let alert: UIAlertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        
        ///CUSTOMIZE TITLE
        if title.count != 0 {
            let attributeTitle = NSMutableAttributedString(string: title, attributes: [NSAttributedString.Key.font : UIFont.appRegularFont(WithSize: 14.0),NSAttributedString.Key.foregroundColor : UIColor.appColor.appDarkGrayColor])
            alert.setValue(attributeTitle, forKey: "attributedTitle")
        }
        
        ///CUSTOMIZE MESSAGE
        if message.count != 0 {
            let attributeTitle = NSMutableAttributedString(string: message, attributes: [NSAttributedString.Key.font : UIFont.appRegularFont(WithSize: 13.0),NSAttributedString.Key.foregroundColor : UIColor.appColor.appGrayColor])
            alert.setValue(attributeTitle, forKey: "attributedMessage")
        }
        
        ///CUSTOMIZE BUTTON
        for i in 0..<buttons.count {
            let buttontitle = buttons[i]
            let buttonAction : UIAlertAction = UIAlertAction(title: buttontitle, style: .default, handler: { (action) in
                completion? (i)
            })
            let actionColor = ((buttontitle.lowercased() == "cancel") || (buttontitle.lowercased() == "delete") || (buttontitle.lowercased() == "no")) ? UIColor.appColor.appGrayColor : UIColor.appColor.appThemeColor_PersianGreen
            buttonAction.setValue(actionColor, forKey: "titleTextColor")
            alert.addAction(buttonAction)
        }
        UIViewController.topMostController.present(alert, animated: true, completion: nil)
    }
    
    /// Show AlertController
    ///
    /// - Parameters:
    ///   - title: set your title
    ///   - message: set your message
    ///   - buttonTitles: set button array
    ///   - completion: completion handler
    func displaySimpleAlert(withtitle title: String, message : String, buttons : [String], completion : ((_ selectedIndex : NSInteger) -> Void)?) -> Void {
        
        let alert: UIAlertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        
        ///CUSTOMIZE BUTTON
        for i in 0..<buttons.count {
            let buttontitle = buttons[i]
            let buttonAction : UIAlertAction = UIAlertAction(title: buttontitle, style: .default, handler: { (action) in
                completion? (i)
            })
            alert.addAction(buttonAction)
        }
        UIViewController.topMostController.present(alert, animated: true, completion: nil)
    }

    
    /// Show AlertController with Textfield
    ///
    /// - Parameters:
    ///   - placeholder: set your textfield placeholder text
    ///   - title: set your title
    ///   - message: set your message
    ///   - buttonTitles: set button array
    ///   - completion: completion handler
    func displayAlertWithTextField(withPlaceholder placeholder: String,isForCurrency:Bool=true, title: String, message : String, buttons : [String], completion : ((_ selectedIndex : NSInteger, _ textfieldText: String) -> Void)?) -> Void {
        
        let alert: UIAlertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        
        ///CUSTOMIZE TEXTFIELD
        alert.addTextField { (textField : UITextField!) -> Void in
            
            //TEXTFIELD SETUP
            textField.placeholder = placeholder
            textField.setPlaceHolderTextColor(UIColor.appColor.appGrayColor)
            textField.keyboardType = .numberPad
            textField.font = UIFont.appRegularFont(WithSize: 14.0)
            textField.textColor = UIColor.appColor.appBlackColor
            
            if isForCurrency
            {
                textField.addTarget(self, action: #selector(self.myTextFieldDidChange), for: .editingChanged)
            }
            
        }
        
        let firstTextField = alert.textFields![0] as UITextField

        ///CUSTOMIZE TITLE
        if title.count != 0 {
            let attributeTitle = NSMutableAttributedString(string: title, attributes: [NSAttributedString.Key.font : UIFont.appRegularFont(WithSize: 14.0),NSAttributedString.Key.foregroundColor : UIColor.appColor.appDarkGrayColor])
            alert.setValue(attributeTitle, forKey: "attributedTitle")
        }
        
        ///CUSTOMIZE MESSAGE
        if message.count != 0 {
            let attributeTitle = NSMutableAttributedString(string: message, attributes: [NSAttributedString.Key.font : UIFont.appRegularFont(WithSize: 13.0),NSAttributedString.Key.foregroundColor : UIColor.appColor.appGrayColor])
            alert.setValue(attributeTitle, forKey: "attributedMessage")
        }
        
        ///CUSTOMIZE BUTTON
        for i in 0..<buttons.count {
            let buttontitle = buttons[i]
            let buttonAction : UIAlertAction = UIAlertAction(title: buttontitle, style: .default, handler: { (action) in
                completion? (i,firstTextField.text!)
            })
            let actionColor = ((buttontitle.lowercased() == "cancel") || (buttontitle.lowercased() == "delete") || (buttontitle.lowercased() == "no")) ? UIColor.appColor.appGrayColor : UIColor.appColor.appThemeColor_PersianGreen
            buttonAction.setValue(actionColor, forKey: "titleTextColor")
            alert.addAction(buttonAction)
        }
        UIViewController.topMostController.present(alert, animated: true, completion: nil)
    }
    
    @objc func myTextFieldDidChange(_ textField: UITextField) {
        if let amountString = textField.text?.currencyInputFormatting() {
            textField.text = amountString
        }
    }
    
    /// Show Actionsheet with message and title
    ///
    /// - Parameters:
    ///   - vc: where you display (UIViewController)
    ///   - title: Alert title
    ///   - message: your message
    ///   - buttons: button array
    ///   - canCancel: with cancel button
    ///   - completion: completion handler
    static public func showActionSheetWithTitleFromVC(vc:UIViewController,
                                                                   title: String,
                                                                   buttons:[String],
                                                                   canCancel:Bool,
                                                                   completion:((_ index:Int) -> Void)!) -> Void {
        
        let alertController = UIAlertController(title: title, message: nil, preferredStyle: .actionSheet)
        
        for index in 0..<buttons.count    {
            
            let action = UIAlertAction(title: buttons[index], style: .default, handler: {
                (alert: UIAlertAction!) in
                if(completion != nil){
                    completion(index)
                }
            })
            
            alertController.addAction(action)
        }
        
        if(canCancel){
            let action = UIAlertAction(title: AILocalization.shared.buttonTitleCancel, style: .cancel, handler: {
                (alert: UIAlertAction!) in
                if(completion != nil){
                    completion(buttons.count)
                }
            })
            
            alertController.addAction(action)
        }
        
        if(UIDevice.isIpad){
            
            if(vc.view != nil){
                alertController.popoverPresentationController?.sourceView = vc.view
                alertController.popoverPresentationController?.sourceRect = CGRect(x: 0, y: (vc.view?.frame.size.height)!, width: 1.0, height: 1.0)
            }else{
                alertController.popoverPresentationController?.sourceView = UIApplication.shared.delegate!.window!?.rootViewController!.view
                alertController.popoverPresentationController?.sourceRect = CGRect(x: 0, y: 0, width: 1.0, height: 1.0)
            }
        }
        UIApplication.shared.delegate!.window!?.rootViewController!.present(alertController, animated: true, completion:nil)
        
    }

    
    /// Show Actionsheet with message and title
    ///
    /// - Parameters:
    ///   - vc: where you display (UIViewController)
    ///   - title: Alert title
    ///   - message: your message
    ///   - buttons: button array
    ///   - canCancel: with cancel button
    ///   - completion: completion handler
    static public func showActionSheetFromVC(vc:UIViewController,
                                                      buttons:[String],
                                                      canCancel:Bool,
                                                      completion:((_ index:Int) -> Void)!) -> Void {
        
        let alertController = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
        
        for index in 0..<buttons.count    {
            
            let action = UIAlertAction(title: buttons[index], style: .default, handler: {
                (alert: UIAlertAction!) in
                if(completion != nil){
                    completion(index)
                }
            })
            
            alertController.addAction(action)
        }
        
        if(canCancel){
            let action = UIAlertAction(title: AILocalization.shared.buttonTitleCancel, style: .cancel, handler: {
                (alert: UIAlertAction!) in
                if(completion != nil){
                    completion(buttons.count)
                }
            })
            
            alertController.addAction(action)
        }
        
        if(UIDevice.isIpad){
            
            if(vc.view != nil){
                alertController.popoverPresentationController?.sourceView = vc.view
                alertController.popoverPresentationController?.sourceRect = CGRect(x: 0, y: (vc.view?.frame.size.height)!, width: 1.0, height: 1.0)
            }else{
                alertController.popoverPresentationController?.sourceView = UIApplication.shared.delegate!.window!?.rootViewController!.view
                alertController.popoverPresentationController?.sourceRect = CGRect(x: 0, y: 0, width: 1.0, height: 1.0)
            }
        }
        UIApplication.shared.delegate!.window!?.rootViewController!.present(alertController, animated: true, completion:nil)
        
    }

}

extension String {
    
    // formatting text for currency textField
    func currencyInputFormatting() -> String {
        
        var number: NSNumber!
        let formatter = NumberFormatter()
        formatter.numberStyle = .currencyAccounting
        formatter.currencySymbol = ""
        formatter.maximumFractionDigits = 2
        formatter.minimumFractionDigits = 2
        
        var amountWithPrefix = self
        
        // remove from String: "$", ".", ","
        let regex = try! NSRegularExpression(pattern: "[^0-9]", options: .caseInsensitive)
        amountWithPrefix = regex.stringByReplacingMatches(in: amountWithPrefix, options: NSRegularExpression.MatchingOptions(rawValue: 0), range: NSMakeRange(0, self.count), withTemplate: "")
        
        let double = (amountWithPrefix as NSString).doubleValue
        number = NSNumber(value: (double / 100))
        
        print(number)
        
        // if first number is 0 or all numbers were deleted
        guard number != 0 as NSNumber else {
            return ""
        }
        
        return formatter.string(from: number)!
    }
}

