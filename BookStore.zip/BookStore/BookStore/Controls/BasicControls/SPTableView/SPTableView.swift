//
//  SPTableView.swift
//  ServiceProvider
//
//  Created by agileimac-2 on 18/03/19.
//  Copyright © 2019 agileimac-2. All rights reserved.
//

import UIKit

class SPTableView: AITableView {
    
    //MARK:- PROPERTIES
    var viewPlaceHolder:SPViewPlaceholder!
    var emptyTitle : String = ""
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        commonInit()
    }
    
    private func commonInit(){
        self.tintColor = UIColor.black
        self.backgroundColor = UIColor.clear
        self.keyboardDismissMode = UIScrollView.KeyboardDismissMode.onDrag
    }
    
    //MARK:- Dequeue Reusable Cell
    func dequeueReusableCell<T: UITableViewCell>() -> T {
        guard let cell = dequeueReusableCell(withIdentifier: T.className) as? T else {
            self.registerCell(T.self)
            guard let cell = dequeueReusableCell(withIdentifier: T.className) as? T else {
                fatalError("Could not dequeue cell with identifier: \(T.className)")
            }
            return cell
        }
        return cell
    }
    
    //MARK:- Register Cell
    private func registerCell<T: UITableViewCell>(_: T.Type) {
        self.register(T.nibName, forCellReuseIdentifier: T.className)
    }
    
    //MARK:- Register Class
    private func registerClass<T: UITableViewCell>(_: T.Type) {
        self.register(T.self, forCellReuseIdentifier: T.className)
    }
    
    //MARK:- SHOW / HIDE PLACEHOLDER
    func showPlaceHolder(with message : String = AILocalization.shared.placeholderNoDataFoundBlank)
    {
        self.viewPlaceHolder = SPViewPlaceholder()
        self.viewPlaceHolder.setupPlaceHolderViewWith(message: message)
        self.viewPlaceHolder.frame = self.frame
        self.backgroundView = self.viewPlaceHolder
        
        self.viewPlaceHolder.showLoader()
    }
    
    func hidePlaceholder()
    {
        if  self.viewPlaceHolder != nil{
            self.viewPlaceHolder.removeFromSuperview()
        }
        self.backgroundView = nil
    }
}

class SPTableViewScroll: AITableView_TPKeyboard {
    
    //MARK:- PROPERTIES
    var viewPlaceHolder:SPViewPlaceholder!
    var emptyTitle : String = ""
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        commonInit()
    }
    
    private func commonInit(){
        
        self.tintColor = UIColor.black
        self.backgroundColor = UIColor.clear
    }
    
    //MARK:- Dequeue Reusable Cell
    func dequeueReusableCell<T: UITableViewCell>() -> T {
        guard let cell = dequeueReusableCell(withIdentifier: T.className) as? T else {
            self.registerCell(T.self)
            guard let cell = dequeueReusableCell(withIdentifier: T.className) as? T else {
                fatalError("Could not dequeue cell with identifier: \(T.className)")
            }
            return cell
        }
        return cell
    }
    
    //MARK:- Register Cell
    private func registerCell<T: UITableViewCell>(_: T.Type) {
        self.register(T.nibName, forCellReuseIdentifier: T.className)
    }
    
    //MARK:- Register Class
    private func registerClass<T: UITableViewCell>(_: T.Type) {
        self.register(T.self, forCellReuseIdentifier: T.className)
    }
    
    //MARK:- SHOW / HIDE LOADER
    
    
    func showLoader(with message : String = AILocalization.shared.placeholderNoDataFoundBlank){
        self.viewPlaceHolder = SPViewPlaceholder()
        //self.viewPlaceHolder.labelColor = UIColor.appColor.appWhiteBackgroundColor
        self.viewPlaceHolder.setupPlaceHolderViewWith(message: message)
        self.viewPlaceHolder.frame = self.frame
        self.backgroundView = self.viewPlaceHolder
        self.viewPlaceHolder.showLoader()
    }
    
    func hideLoader(){
        self.viewPlaceHolder.removeFromSuperview()
        self.backgroundView = nil
    }
}

