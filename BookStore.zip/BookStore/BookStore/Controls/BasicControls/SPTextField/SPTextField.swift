//
//  SPTextField.swift
//  ServiceProvider
//
//  Created by agileimac-2 on 18/03/19.
//  Copyright © 2019 agileimac-2. All rights reserved.
//

import UIKit

//public enum ESTextFieldKeyboardType: Int{
//
//    case creditCard
//    case none
//}

public enum ESTextFieldStyle: Int{
    case FloatingLabel
    case BottomLine
    case none
}

class SPTextField: AITextField
{
    
    // varibales
    var blocKNumberOfCharacter:((Int)->Void)?
    var blocKRetuenNewText:((String)->Void)?
    var validationType:EITextFieldValidationType?
//    var textKeyboardType:ESTextFieldKeyboardType?
    var textTopPadding = 0.0
    
    
    // MARK:-
    override func textRect(forBounds bounds: CGRect) -> CGRect {
        return bounds.insetBy(dx: (leftView?.frame.size.width ?? 0), dy: CGFloat(textTopPadding))
    }
    override func editingRect(forBounds bounds: CGRect) -> CGRect {
        return bounds.insetBy(dx: (leftView?.frame.size.width ?? 0), dy: CGFloat(textTopPadding))
    }
    
    convenience  override init(frame: CGRect) {
        self.init(frame: frame)
        self.commonInit()
    }
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.commonInit()
    }
    
    override var text: String?{
        
        didSet{
            if self.text?.count == 0
            {
                self.font = UIFont.appRegularFont(WithSize: self.font!.pointSize, shouldResize: false)
            }else{
                self.font = UIFont.appRegularFont(WithSize: self.font!.pointSize, shouldResize: false)
            }
        }
    }
    
    var textFieldStyle: ESTextFieldStyle = .none {
        didSet{
            self.setupTextfieldColor(style: self.textFieldStyle)
        }
    }
    var minLength : Int = 0
    var maxLength : Int = 256
    
    override func commonInit() -> Void {
        
        self.isExclusiveTouch = true
        
        if #available(iOS 11.0, *) {
            self.smartInsertDeleteType = .no
        }
        
        // Set font
        self.font = UIFont.appRegularFont(WithSize: self.font!.pointSize, shouldResize: true)
        
        //DELEGATE
        self.delegate = self
        
        if(self.placeholder != nil ){
            self.config.placeholderColor = UIColor.appColor.appGrayColor
            
        }
        // set left view
        self.rightViewMode = UITextField.ViewMode.always
        
        self.autocorrectionType = .no
        
    }
    
    func setupTextfieldColor(style : ESTextFieldStyle) {
        
        switch style {
        case .FloatingLabel:
            var config :SPTextField.Config          = SPTextField.Config()
            
            config.bottomLineEditingColor           = UIColor.appColor.appBorderColor
            config.bottomLineNormalColor            = UIColor.appColor.appBorderColor
            
            config.floatingLabelEditingColor        = UIColor.appColor.appGrayColor
            config.placeholderColor                 = UIColor.appColor.appGrayColor
            
            config.textColor                        = UIColor.appColor.appBlackColor
            self.config = config
//             self.tintColor = self.config.textColor
            self.contentVerticalAlignment = .fill
            //            self.textTopPadding = 8.0
            
            if AILocalization.getCurruntDeviceLanguage() == .english
            {
                self.textAlignment = .natural
            }else {
                self.textAlignment = .right
            }
            
            switch UIDevice.deviceType
            {
            case .iPhone5or5s:
                self.textTopPadding = Double(GET_PROPORTIONAL_HEIGHT(height: 16.0))
            default:
                self.textTopPadding = Double(GET_PROPORTIONAL_HEIGHT(height: 16.0))
            }
                        
            // setUpFloatingLabelTextFieldColors(placeholderColor: UIColor.red, floatingLabelEditingColor: UIColor.appColor.textBlueColor, bottomLineNormalColor: UIColor.red, bottomLineEditingColor: UIColor.black)
            
        case .BottomLine:
            
            var config : SPTextField.Config         = SPTextField.Config()
            config.bottomLineEditingColor           = UIColor.appColor.appBorderColor
            config.bottomLineNormalColor            = UIColor.appColor.appBorderColor
            
            config.floatingLabelEditingColor        = UIColor.appColor.appBorderColor
            config.placeholderColor                 = UIColor.appColor.appGrayColor
            
            config.textColor                        = UIColor.appColor.appBlackColor
            self.config = config
            self.tintColor = self.config.textColor
            self.contentVerticalAlignment = .bottom
            self.textTopPadding = 4.0
            break
            
        case .none:
            
            var config : SPTextField.Config         = SPTextField.Config()
            config.bottomLineNormalColor            = UIColor.clear
            config.bottomLineEditingColor           = UIColor.clear
            config.placeholderColor                 = UIColor.appColor.appBlackColor
            config.floatingLabelEditingColor        = UIColor.appColor.appBlackColor
            config.textColor                        = UIColor.appColor.appBlackColor
            self.config = config
            self.tintColor = self.config.textColor
            self.textTopPadding = 0.0
        }
        
    }
    
    
    func setUpPlaceholderText(strPlaceholder:String)
    {
        self.placeholder(text: strPlaceholder, color: config.placeholderColor ?? UIColor.appColor.appGrayColor)
        self.titleLabel.text = strPlaceholder
    }
    
    //MARK:- LENGHT VALIDATION
    //MARK:
    
    
    
    
    func textFieldEditChange(_ textField : UITextField) -> Void {
        
        
    }
    
    override func textFieldDidBeginEditing(_ textField: UITextField) {
        
        super.textFieldDidBeginEditing(textField)
        
    }
    
    
    override func textFieldDidEndEditing(_ textField: UITextField) {
        
        super.textFieldDidEndEditing(textField)
        
    }
    
    override func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool
    {
        if self.blockTextFieldShouldBeginEditing != nil {
            self.blockTextFieldShouldBeginEditing?(textField as! AITextField)
        }
        
        if self.validationType == .EIType_Nationality || self.validationType == .EIType_Country || self.validationType == .EIType_State || self.validationType == .EIType_City || self.validationType == .EIType_Job
        {
            return false
        }
        
        return true
    }
    
    override func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        // Return for Paste blank string
        //        if string == UIPasteboard.general.string && string.length > 0 && string.first == " "
        //        {
        //            // code to execute in case user is using PASTE
        //            return false
        //        }
        
        
        
        // For Credit Card validation
        /*
        if self.textKeyboardType == .creditCard{
            //self.updateTextFieldKeyboardType()
            guard string.characters.compactMap({ Int(String($0)) }).count == string.characters.count else { return false }
            let fullText = ((textField.text! as NSString).replacingCharacters(in: range, with: string) as NSString).replacingOccurrences(of: " ", with: "")
            let curruntCardType = STPCardValidator.brand(forNumber: fullText)
            switch curruntCardType {
                
            case .visa,.masterCard,.discover,.JCB:
                self.config.maxLength = 19
            case .amex:
                self.config.maxLength! = 18
            case .dinersClub:
                self.config.maxLength! = 17
            default:
                self.config.maxLength! = 19
            }
            
            self.config.minLength = self.config.maxLength!
            
            if self.checkMaxLength(range, maxLength: self.config.maxLength!, current: string) == false{
                let fullText = (textField.text! as NSString).replacingCharacters(in: range, with: string)
                if self.blockShouldChangeCharactersIn != nil {
                    self.blockShouldChangeCharactersIn?(textField as! AITextField, fullText)
                }
                return false
            }
            
            let isSuccess : Bool = self.checkNumberBlock1(textField, range: range, string: string, txtType: self.config.textFieldKeyboardType)
            
            
            if string.length == 0, fullText.length == 0 {
                if self.blocKRetuenNewText != nil
                {
                    let newString = fullText
                    self.blocKRetuenNewText!(newString as String)
                }
                textField.text = fullText
            }
            else {
                var formattedPatternCard = ""
                var arrSpacePosition: [Int] = []
                if (curruntCardType == .amex) {
                    arrSpacePosition = [4, 8, 12];
                } else {
                    arrSpacePosition = [4, 8, 12];
                }
                
                for i in 0...fullText.count - 1  {
                    if arrSpacePosition.contains(i) {
                        formattedPatternCard = formattedPatternCard + " " + (fullText as NSString).substring(with: NSMakeRange(i, 1))
                    }
                    else {
                        formattedPatternCard = formattedPatternCard + (fullText as NSString).substring(with: NSMakeRange(i, 1))
                    }
                }
                if isSuccess {
                    
                    if self.blocKRetuenNewText != nil
                    {
                        //let newString = (textField.text! as NSString).replacingCharacters(in: range, with: string) as NSString
                        let newString = formattedPatternCard
                        self.blocKRetuenNewText!(newString as String)
                    }
                    
                    self.text = formattedPatternCard
                }
                
            }
            
            
            return false
            
        }else{
            */
            
            // Return value
            if(self.blocKRetuenNewText != nil){
                let newString = (textField.text! as NSString).replacingCharacters(in: range, with: string) as NSString
                self.blocKRetuenNewText!(newString as String)
            }
            
            if(self.blocKNumberOfCharacter != nil){
                let newString = (textField.text! as NSString).replacingCharacters(in: range, with: string) as NSString
                self.blocKNumberOfCharacter!(newString.length)
            }
            
            let isSuccess = super.textField(textField, shouldChangeCharactersIn: range, replacementString: string)
            
            if isSuccess
            {
                if let newString = (textField.text! as NSString).replacingCharacters(in: range, with: string) as? String
                {
                    if newString.count == 0 || (newString.count == 1 && newString == " ")
                    {
                        self.font = UIFont.appRegularFont(WithSize: self.font!.pointSize, shouldResize: false)
                    }else{
                        self.font = UIFont.appRegularFont(WithSize: self.font!.pointSize, shouldResize: false)
                    }
                }
            }
            
            
            return isSuccess
            
//        }
        
    }
    
    func checkMaxLength(_ range: NSRange,  maxLength : NSInteger, current string : String) -> Bool {
        
        if maxLength != 0 {
            if string != "" && string.count < 2
            {
                if (self.text?.count)! < maxLength{
                    if range.location >= maxLength {
                        return false
                    }
                }else{
                    return false
                }
            }
            else if string != "" && string.count > 1
            {
                let expLength = (self.text?.count)! + string.count
                
                if expLength-1 < maxLength
                {
                    if range.location >= maxLength {
                        return false
                    }
                }else
                {
                    return false
                }
            }
            
            return true
        }
        return true
    }
    
    
    func checkNumberBlock1(_ textField: UITextField, range: NSRange, string: String, txtType : AITextFieldKeyboardType?) -> Bool  {
        
        var charactersToBlock : CharacterSet = CharacterSet()
        
        if txtType == .Number {
            charactersToBlock = CharacterSet(charactersIn: "0123456789 ")
            if  (range.location == 0 &&  string == "0") {
                return false
            }
        }
        
        
        if range.location == 0 {
            if string.hasPrefix(" ") {
                return false
            }
        }
        if string == ""  {
            return true
        }
        
        
        
        if (string.rangeOfCharacter(from: charactersToBlock) != nil) {
            return true
        }
        else {
            return false
        }
        
    }
    
}
