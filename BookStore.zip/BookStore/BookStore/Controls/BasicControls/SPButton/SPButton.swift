//
//  SPButton.swift
//  ServiceProvider
//
//  Created by agileimac-2 on 18/03/19.
//  Copyright © 2019 agileimac-2. All rights reserved.
//

import UIKit

enum SPThemeButtonBoldType:Int {
    case themeGreen
    case redBackground
    case grayBackground
}

//MARK:- ICON BUTTON
//MARK:-

class SPIconButton: AIButton {
    
    // INIT
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        commonInit()
    }
    
    private func commonInit(){
        
        self.setAttributedTitle(SPCustomFont.getIconNew(iconName: (self.titleLabel?.text)!, Size: self.titleLabel!.font.pointSize, Color: (self.titleLabel?.textColor)!), for: .normal)
        self.isExclusiveTouch = true
    }
    
    func btnIsEnable(object:Bool,enablecolor:UIColor = UIColor.appColor.appGreenColor,disableColor:UIColor = UIColor.appColor.appGrayColor)
    {
        self.isEnabled = object
        
        if object
        {
            self.setAttributedTitle(SPCustomFont.getIconNew(iconName: (self.titleLabel?.text)!, Size: self.titleLabel!.font.pointSize, Color: enablecolor), for: .normal)
            
        }else
        {
            self.setAttributedTitle(SPCustomFont.getIconNew(iconName: (self.titleLabel?.text)!, Size: self.titleLabel!.font.pointSize, Color: disableColor), for: .normal)
        }
    }
    
    func changeIconColor(color:UIColor)
    {
        self.setAttributedTitle(SPCustomFont.getIconNew(iconName: (self.titleLabel?.text)!, Size: self.titleLabel!.font.pointSize, Color: color), for: .normal)
    }
    
    func setImage(withCode code:String, withColor color:UIColor = UIColor.black,withSize size:CGFloat = 20.0, withControlState state:State = .normal)
    {
//        self.setAttributedTitle(SPCustomFont.getIconNew(iconName: code, Size: size, Color:color), for: state)
        
        self.setAttributedTitle(SPCustomFont.getImageIcon(iconName: code, Size: size, Color:color), for: state)

    }
    
//    func setBackgroundImage(withCode code:String, withColor color:UIColor = UIColor.black,withSize size:CGFloat = 20.0, withControlState state:State)
//    {
//        self.setImage(SPCustomFont.getImage(fromiconName: code, size: size, color: color), for: state)
//    }

}

//MARK:- ICON BUTTON
//MARK:-

class SPIconTextButton: AIButton {
    
    // INIT
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        commonInit()
    }
    
    private func commonInit() {
        self.isExclusiveTouch = true
    }
    
    func btnIsEnable(withObject isEnable:Bool, withImageCode code:String, withImageSize imageSize:CGFloat = 20.0, withTitleText title:String, withFontSize fontSize:CGFloat = 14.0) {
        
        //ENABLE-DISABLE COLOR
        let enableColor:UIColor = UIColor.appColor.appThemeColor_PersianGreen
        let disableColor:UIColor = UIColor.appColor.appGrayColor
        
        //ENABLE-DISABLE BUTTON
        self.isEnabled = isEnable
        
        if isEnable {
            
            //SET IMAGE
            self.setImage(SPCustomFont.getImage(fromiconName: code, size: imageSize, color: enableColor), for: .normal)
            self.tintColor = enableColor
            //SET TITLE
            let titleWithSpace:String = " " + title
            let objText = NSMutableAttributedString.init(string: titleWithSpace, attributes: [
                NSAttributedString.Key.font : UIFont.appRegularFont(WithSize: fontSize, shouldResize: false),
                NSAttributedString.Key.foregroundColor:enableColor
                ])
            self.setAttributedTitle(objText, for: .normal)
        
        }else {
            
            //SET IMAGE
            self.setImage(SPCustomFont.getImage(fromiconName: code, size: imageSize, color: disableColor), for: .disabled)
            self.tintColor = disableColor
            //SET TITLE
            let titleWithSpace:String = " " + title
            let objText = NSMutableAttributedString.init(string: titleWithSpace, attributes: [
                NSAttributedString.Key.font : UIFont.appRegularFont(WithSize: fontSize, shouldResize: false),
                NSAttributedString.Key.foregroundColor:disableColor
                ])
            self.setAttributedTitle(objText, for: .disabled)
        }
    }
}
    
//MARK:- REGULAR BUTTON
//MARK:-
class SPButton: AIButton {
    
    // INIT
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        commonInit()
    }
    
    private func commonInit()
    {
        self.titleLabel!.font = UIFont.appRegularFont(WithSize: self.titleLabel!.font.pointSize, shouldResize: true)
        self.isExclusiveTouch = true
    }
}


//MARK:- SEMI BOLD BUTTON
//MARK:-
class SPButtonSemiBold: AIButton {
    
    //INIT
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        commonInit()
    }
    
    private func commonInit()
    {
        self.titleLabel!.font = UIFont.appSemiBoldFont(WithSize: self.titleLabel!.font.pointSize, shouldResize: true)
        self.isExclusiveTouch = true
    }
}

//MARK:- BOLD BUTTON
//MARK:-
class SPButtonBold: AIButton {
    
    // INIT
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        commonInit()
    }
    
    private func commonInit()
    {
        self.titleLabel!.font = UIFont.appBoldFont(WithSize: self.titleLabel!.font.pointSize, shouldResize: true)
        self.isExclusiveTouch = true
    }
}

//MARK:- THEME BOLD BUTTON
//MARK:-
class SPThemeButtonBold: AIButton
{
    var themeButtonType:SPThemeButtonBoldType = .themeGreen{
        didSet{
            self.updateUIAccordingToButtonType()
        }
    }

    // INIT
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        commonInit()
    }
    
    override func draw(_ rect: CGRect) {
        super.draw(rect)
    }
    
    private func commonInit()
    {
        self.updateUIAccordingToButtonType()
        self.isExclusiveTouch = true
    }
    
    func updateUIAccordingToButtonType() -> Void
    {
        switch self.themeButtonType {
        case .redBackground:
            self.setTitleColor(UIColor.appColor.appWhiteColor, for: .normal)
            self.backgroundColor = UIColor.appColor.appRedColor
            self.titleLabel!.font = UIFont.appBoldFont(WithSize: 14.0, shouldResize: true)
        case .grayBackground:
            self.setTitleColor(UIColor.appColor.appGrayColor, for: .normal)
            self.backgroundColor = UIColor.appColor.appLightGrayColor
            self.titleLabel!.font = UIFont.appBoldFont(WithSize: 14.0, shouldResize: true)
        default:
            self.setTitleColor(UIColor.appColor.appWhiteColor, for: .normal)
            self.backgroundColor = UIColor.appColor.appThemeColor_PersianGreen
            self.titleLabel!.font = UIFont.appBoldFont(WithSize: 14.0, shouldResize: true)
            break
        }
    }
}

//MARK:- ICON BUTTON
//MARK:-

class SPStatusButton: AIButton {
    
    // INIT
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        commonInit()
    }
    
    private func commonInit() {
        self.isExclusiveTouch = true
    }
    
    func btnIsEnable(withObject isEnable:Bool, withImageCode code:String, withImageSize imageSize:CGFloat = 24.0, withInsectSize insectSize:CGFloat = 8.0) {
        
        //ENABLE-DISABLE COLOR
        let enableColor:UIColor = UIColor.appColor.appThemeColor_PersianGreen
        let disableColor:UIColor = UIColor.appColor.appGrayColor
        let whiteColor:UIColor = UIColor.appColor.appWhiteColor

        //ENABLE-DISABLE BUTTON
        self.isEnabled = isEnable
        
        //CONTENT INSET
        self.imageEdgeInsets = UIEdgeInsets(top: insectSize, left: insectSize, bottom: insectSize, right: insectSize)
        
        if isEnable {
            
            //SET IMAGE
            self.setImage(SPCustomFont.getImage(fromiconName: code, size: imageSize, color: whiteColor), for: .normal)
            self.setCircleView(view: self, backgroundColor: enableColor, borderColor: enableColor, borderWidth: 1.0)

        }else {
            
            //SET IMAGE
            self.setImage(SPCustomFont.getImage(fromiconName: code, size: imageSize, color: disableColor), for: .disabled)
            self.setCircleView(view: self, backgroundColor: whiteColor, borderColor: disableColor, borderWidth: 1.0)
        }
    }
}
