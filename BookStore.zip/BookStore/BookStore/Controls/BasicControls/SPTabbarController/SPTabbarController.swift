//
//  SPTabbarController.swift
//  ServiceProvider
//
//  Created by agileimac-2 on 18/03/19.
//  Copyright © 2019 agileimac-2. All rights reserved.
//

import UIKit


enum SPTabBarIndex: Int{
    
    case
    home,
    chats,
    notifications,
    orders,
    settings
        
    var imageName: String {
        switch self {
        case .home:
            return SPCustomFont.SPFontName.icon_home.getHexCode()
        case .chats:
            return SPCustomFont.SPFontName.icon_chat.getHexCode()
        case .notifications:
            return SPCustomFont.SPFontName.icon_notification.getHexCode()
        case .orders:
            return SPCustomFont.SPFontName.icon_order.getHexCode()
        case .settings:
            return SPCustomFont.SPFontName.icon_more.getHexCode()
        }
    }
    
//    var imageNameSelected: String {
//        switch self {
//        case .home:
//            return SPCustomFont.SPFontName.icon_home.getIconCode()
//
//        case .chats:
//            return SPCustomFont.SPFontName.icon_chat.getIconCode()
//        case .notifications:
//            return SPCustomFont.SPFontName.icon_notification.getIconCode()
//        case .orders:
//            return SPCustomFont.SPFontName.icon_order.getIconCode()
//        case .settings:
//            return SPCustomFont.SPFontName.icon_more.getIconCode()
//        }
//    }
}

class SPTabbarController: UITabBarController {
    
    
    //MARK:- PROPERTIES
    public var viewBottomLine:UIView!
    var blockTabBarVeiwDidSelect:((SPTabBarIndex) -> Void)?
    let tabbar = UITabBar()
    
    
    //MARK:- VIEW LIFE CYCLE
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        self.delegate = self
        
        self.doSetupTabbar()
        //self.addTopLineInTabBar()
        self.tabbar.tintColor = UIColor.appColor.appThemeColor_PersianGreen
        
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    // MARK: - TABBAR SETUP
    fileprivate func doSetupTabbar() {
        
        let tabBarItem1 = self.tabBar.items![0] as UITabBarItem
        let tabBarItem2 = self.tabBar.items![1] as UITabBarItem
        let tabBarItem3 = self.tabBar.items![2] as UITabBarItem
        let tabBarItem4 = self.tabBar.items![3] as UITabBarItem
        let tabBarItem5 = self.tabBar.items![4] as UITabBarItem
        
        let appearance = UITabBarItem.appearance()
        let attributes =  [kCTFontAttributeName: UIFont.appIconFont(WithSize: 25.0, shouldResize: true)]
        appearance.setTitleTextAttributes(attributes as [NSAttributedString.Key : Any], for: .normal)
        
        
        tabBarItem1.title = SPTabBarIndex.home.imageName
        tabBarItem1.tag = SPTabBarIndex.home.rawValue
        tabBarItem1.titlePositionAdjustment  =  UIOffset(horizontal: 0.0, vertical: -12.0)
        
        tabBarItem2.title = SPTabBarIndex.chats.imageName
        tabBarItem2.tag = SPTabBarIndex.chats.rawValue
        tabBarItem2.titlePositionAdjustment  =  UIOffset(horizontal: 0.0, vertical: -12.0)
        
        //Set Badge : change color after setup color class
//        tabBarItem2.badgeValue = "5"
//        tabBarItem2.badgeColor = UIColor.red

        tabBarItem3.title = SPTabBarIndex.notifications.imageName
        tabBarItem3.tag = SPTabBarIndex.notifications.rawValue
        tabBarItem3.titlePositionAdjustment  =  UIOffset(horizontal: 0.0, vertical: -12.0)
        
        tabBarItem4.title = SPTabBarIndex.orders.imageName
        tabBarItem4.tag = SPTabBarIndex.orders.rawValue
        tabBarItem4.titlePositionAdjustment  =  UIOffset(horizontal: 0.0, vertical: -12.0)
        
        tabBarItem5.title = SPTabBarIndex.settings.imageName
        tabBarItem5.tag = SPTabBarIndex.settings.rawValue
        tabBarItem5.titlePositionAdjustment  =  UIOffset(horizontal: 0.0, vertical: -12.0)
        
        
        self.tabBar.isTranslucent = false
        self.tabBar.tintColor = UIColor.appColor.appThemeColor_PersianGreen
        self.tabBar.barTintColor = UIColor.white
        
        //        if AIUser.current.userId.isEmpty{
        //            self.viewControllers?.remove(at: 1)
        //            tabBarItem3.tag = LSTabBarIndex.history.rawValue
        //        }
        
    }
    
    func selectTab(at index : Int)
    {
        self.tabBar(self.tabbar, didSelect:  tabBar.items![index])
    }
    
    func addTopLineInTabBar()
    {
        let customTabHeight:CGFloat = 4
        var tabHeight =  tabBar.frame.height - customTabHeight
        var bottomPadding : CGFloat = 0.0
        if UIDevice.deviceType == .iPhoneX {
            bottomPadding = 0.0
            tabHeight =  tabBar.frame.height - customTabHeight - bottomPadding
            // ...
        }
        
        let itemWidth  = tabBar.frame.width / CGFloat(tabBar.items!.count)
        if (self.tabBar.viewWithTag(101) == nil) {
            viewBottomLine = UIView()
            viewBottomLine.tag = 101
            viewBottomLine.frame = CGRect(x: 0, y: tabHeight, width: itemWidth, height: customTabHeight)
            viewBottomLine.backgroundColor = UIColor.appColor.appRedColor
            tabBar.addSubview(viewBottomLine)
        }
        
        self.blockTabBarVeiwDidSelect = {selectedTab in
            OperationQueue.main.addOperation {
                UIView.animate(withDuration: 0.25, animations: {
                    self.viewBottomLine.frame = CGRect(x: (CGFloat(Float(self.view.width/CGFloat(self.tabBar.items!.count)) * Float(selectedTab.rawValue))), y: tabHeight , width: self.view.width/CGFloat(self.tabBar.items!.count), height: customTabHeight)
                })
            }
        }
    }
    
    //MARK:-
    func hideTabbarWithAddButton(){
        self.tabBar.isHidden = true
        viewBottomLine.isHidden = true
    }
    
    func showTabbarWithAddButton(){
        self.tabBar.isHidden = false
        viewBottomLine.isHidden = false
    }
    
}


extension SPTabbarController : UITabBarControllerDelegate {
    
    //MARK:- TABBAR DELEGATE
    override func tabBar(_ tabBar: UITabBar, didSelect item: UITabBarItem) {
        
        if self.blockTabBarVeiwDidSelect != nil{
            self.blockTabBarVeiwDidSelect!(SPTabBarIndex(rawValue: item.tag)!)
        }
    }
    
    func tabBarController(_ tabBarController: UITabBarController, shouldSelect viewController: UIViewController) -> Bool{
        
        if self.selectedViewController != viewController{
            guard let fromView = selectedViewController?.view, let toView = viewController.view else {
                return false // Make sure you want this as false
            }
            
            /*
            if fromView != toView {
                UIView.transition(from: fromView, to: toView, duration: 0.3, options: [.transitionCrossDissolve], completion: nil)
            }
            */
        }
        return true
    }
}
