//
//  SPTableViewCell.swift
//  ServiceProvider
//
//  Created by agileimac-2 on 18/03/19.
//  Copyright © 2019 agileimac-2. All rights reserved.
//

import UIKit

class SPTableViewCell: AITableViewCell {
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        commonInit()
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
    private func commonInit() {
        self.selectionStyle = .none
        self.backgroundColor = UIColor.clear
    }
}
