//
//  SPView.swift
//  ServiceProvider
//
//  Created by agileimac-2 on 18/03/19.
//  Copyright © 2019 agileimac-2. All rights reserved.
//

import UIKit

class SPView: UIView {
    
    //MARK:- INIT
    
    init() {
        super.init(frame: .zero)
    }
    
    public override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    public required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    override open func awakeFromNib() {
        super.awakeFromNib()
        commonInit()
    }
    
    // MARK:-
    private func commonInit(){
        self.cornerRadius = 7
        self.layer.cornerRadius = 7
        self.shadowColor = UIColor.gray
        self.shadowOpacity = 0.5
        self.shadowOffset = CGSize(width: -1, height: 1)
        self.shadowRadius = 5
    }
}
