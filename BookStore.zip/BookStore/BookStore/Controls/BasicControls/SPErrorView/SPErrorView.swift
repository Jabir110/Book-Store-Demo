//
//  SPErrorView.swift
//  ServiceProvider
//
//  Created by agilemac-9 on 3/20/19.
//  Copyright © 2019 agileimac-2. All rights reserved.
//


import UIKit
import PureLayout

class SPErrorView: UIView {
	
	//MARK:- OUTLETS
	@IBOutlet private var viewContentView:UIView?
	@IBOutlet weak var lableText: SPLabel!
    @IBOutlet weak var btnRetry: UIButton!
	@IBOutlet weak var topConslableText: NSLayoutConstraint!
    @IBOutlet weak var widthContraintbtnRetry: NSLayoutConstraint!
	var timeToDisplayErrorView = 2
	
	//MARK:- PROPERTIES
	var dialogCloseCompletionHandler: ((_ completion:Bool) -> (Void))?
	
	
	// MARK:- INIT
	override init(frame: CGRect) {
		super.init(frame: frame)
		self.commonInit()
	}
    
    required init?(coder aDecoder: NSCoder) {
//        fatalError("init(coder:) has not been implemented")
        super.init(coder: aDecoder)
    }
	

	
	private func commonInit()	{
        
        for view in (Constants.appDelegate.window?.subviews)!{
            if(view is SPErrorView){
                view.removeFromSuperview()
            }
        }
		
		// LOADING NIB FILE
		Bundle.main.loadNibNamed("SPErrorView", owner: self, options: nil)
		Constants.appDelegate.window!.addSubview(self)
        self.autoPinEdgesToSuperviewEdges(with: UIEdgeInsets(top: 64,left: 0,bottom: 0,right: 0), excludingEdge: ALEdge.top)

		self.addSubview(self.viewContentView!);
		self.viewContentView!.autoPinEdgesToSuperviewEdges()

		// UI
        self.viewContentView?.backgroundColor = UIColor.appColor.appThemeColor_PersianGreen
		self.lableText.textColor = UIColor.appColor.appWhiteColor
		self.lableText.font = UIFont.appRegularFont(WithSize: 16.0)
		self.topConslableText.constant = 12
        self.widthContraintbtnRetry.constant = 60.0
        self.btnRetry.setTitleColor(UIColor.appColor.appBlackColor, for: .normal)
	}
	
	override func layoutSubviews() {
		super.layoutSubviews()
		
		// SHOWING DIALOGUE FROM HERE, BECAUSE HERE DIALOGUE WILL HAVE ITS PROPER HEIGHT BASED ON LABEL CONTENT
		self.showDialogue()
	}
	
	
	// MARK:- BUTTON EVENTS
	@IBAction func btnRetryPressed(_ sender: UIButton)	{
		self.hideDialogue(completion: false)
	}
    
    
	
	
	// MARK:- SHOW / HIDE DIALOGUE
    class func showErrorView(withMessage message:String, isNeedRetryButton: Bool = false, andCompletion completion:( (_ completion:Bool) -> Void)? = nil){
        let errorView = SPErrorView()
        if !isNeedRetryButton {
            errorView.widthContraintbtnRetry.constant = 0.0
            errorView.btnRetry.isHidden = true
        }
        errorView.showDialogue(withMessage: message.trimWhiteSpaceAndNewLine.capitalizingFirstLetter(), andCompletion: completion)
    }
    
    class func showErrorView(withMessage message:String, isNeedRetryButton: Bool = false, bgColor:UIColor, topBottomMargin:CGFloat, andCompletion completion: ((_ completion:Bool) -> Void)?){
        let errorView = SPErrorView()
        errorView.widthContraintbtnRetry.constant = 0.0
        errorView.btnRetry.isHidden = true
        errorView.showDialogue(withMessage: message, bgColor: bgColor, topBottomMargin: topBottomMargin, andCompletion: completion)
    }

	private func showDialogue(withMessage message:String, andCompletion completion: ((_ completion:Bool) -> Void)?){
		self.lableText.text = message
		self.dialogCloseCompletionHandler = completion
	}

	//
	private func showDialogue(withMessage message:String, bgColor:UIColor = UIColor.appColor.appThemeColor_PersianGreen, topBottomMargin:CGFloat, andCompletion completion: ((_ completion:Bool) -> Void)?){
		
        guard message.trimWhiteSpaceAndNewLine.count != 0 else {
            return
        }
        
		self.topConslableText.constant = topBottomMargin
		self.viewContentView!.backgroundColor = bgColor
		self.lableText.text = message
		self.dialogCloseCompletionHandler = completion
	}

	

    private func showDialogue(){
        
        Constants.appDelegate.window?.endEditing(true)
        //17-DEc-2018 :- Due to tester suggesstion developer remove prevent user interation
        //Constant.appDelegate.window?.isUserInteractionEnabled = false
        
        self.center = CGPoint(x: self.center.x, y: self.center.y + self.frame.size.height)
        UIView.animate(withDuration: 0.2, animations: { () -> Void in
           self.center = CGPoint(x: self.center.x, y: self.center.y - self.frame.size.height)
        })
		
		
        if self.widthContraintbtnRetry.constant == 0 {
            // HIDING DIALOG AFTER 2 SECONDS
            DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + TimeInterval(self.timeToDisplayErrorView)) {
                self.hideDialogue(completion: false)
            }
        }
	}
	
	private func hideDialogue(completion:Bool){
		
		UIView.animate(withDuration: 0.2, animations: { () -> Void in
            self.center = CGPoint(x: self.center.x, y: self.center.y + self.frame.size.height)
			self.alpha = 0
		}) { (booo:Bool) -> Void in
            //17-DEc-2018 :- Due to tester suggesstion developer remove prevent user interation
            //Constant.appDelegate.window?.isUserInteractionEnabled = true
			self.removeFromSuperview()
            if(self.dialogCloseCompletionHandler != nil){
                self.dialogCloseCompletionHandler!(completion)
            }
			
		}
	}
}
