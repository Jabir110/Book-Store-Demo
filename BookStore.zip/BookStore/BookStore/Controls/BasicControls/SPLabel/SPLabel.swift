//
//  SPLabel.swift
//  ServiceProvider
//
//  Created by agileimac-2 on 18/03/19.
//  Copyright © 2019 agileimac-2. All rights reserved.
//

import UIKit

//MARK:- REGULAR LABEL
//MARK:-
class SPLabel: AILabel {
    
    // INIT
    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }
    
    required init?(coder aDecoder: NSCoder)
    {
        super.init(coder: aDecoder)
    }
    
    override func awakeFromNib()
    {
        super.awakeFromNib()
        commonInit()
    }
    
    private func commonInit()
    {
        self.font = UIFont.appRegularFont(WithSize: self.font!.pointSize, shouldResize: true)
    }
}


//MARK:- SEMIBOLD LABEL
//MARK:-
class SPLabelSemiBold: AILabel {
    
    //MARK:- INIT
    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }
    
    required init?(coder aDecoder: NSCoder)
    {
        super.init(coder: aDecoder)
    }
    
    override func awakeFromNib()
    {
        super.awakeFromNib()
        commonInit()
    }
    
    private func commonInit()
    {
        self.font = UIFont.appSemiBoldFont(WithSize: self.font!.pointSize, shouldResize: true)
    }
}

//MARK:- BOLD LABEL
//MARK:-
class SPLabelBold: AILabel {
    
    //MARK:- INIT
    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }
    
    required init?(coder aDecoder: NSCoder)
    {
        super.init(coder: aDecoder)
    }
    
    override func awakeFromNib()
    {
        super.awakeFromNib()
        commonInit()
    }
    
    private func commonInit()
    {
        self.font = UIFont.appBoldFont(WithSize: self.font!.pointSize, shouldResize: true)
        
    }
}


//MARK:- ICON LABEL
//MARK:-
class SPLabelIcon : AILabel {
    //MARK:- INIT
    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        commonInit()
    }
    
    private func commonInit()
    {
        self.font = UIFont.appIconFont(WithSize: self.font.pointSize.proportionalFontSize())
    }
    
    func setImage(withCode code:String, withColor color:UIColor = UIColor.black,withSize size:CGFloat = 20.0)
    {
        self.attributedText = SPCustomFont.getIconNew(iconName: code, Size: size, Color:color)
    }
}
