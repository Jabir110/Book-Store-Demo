//
//  SPTextView.swift
//  ServiceProvider
//
//  Created by agileimac-2 on 18/03/19.
//  Copyright © 2019 agileimac-2. All rights reserved.
//

import UIKit

class SPTextView: AITextView {
    
    //MARK:- PROPERTIES
    var maxTextViewLimit = 100
    fileprivate var labelCounter : SPLabel?
    fileprivate let offsetTextContainer : CGFloat = 10.0
    internal var textViewTextDidChangeHandler : (()->Void)?
    var blockTextViewShouldChangeCharacter : ((_ textView: UITextView , _ string: String, _ range: NSRange) -> Bool)?
        
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    internal var currentCharacterCount : Int = 0 {
        didSet {
            //MARK: UPDATE COUNTER LABEL
            self.updateCounterLabel()
        }
    }
    internal var maximumLength : Int = 100 {
        didSet {
            //MARK: UPDATE COUNTER LABEL
            self.updateCounterLabel()
        }
    }
    
    internal var shouldShowCounter : Bool? {
        didSet {
            if self.shouldShowCounter! {
                // ADD COUNTER LABEL
                let deadlineTime = DispatchTime.now() + 0.1
                DispatchQueue.main.asyncAfter(deadline: deadlineTime) {
                    
                    self.addCountLabel()
                    
                    
                }
                
                
            }else {
                guard self.labelCounter != nil else {
                    return
                }
                
                // REMOVE COUNTER LABEL
                self.labelCounter?.isHidden = true
                self.labelCounter?.removeFromSuperview()
            }
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        //self.commonInit()
        
        self.delegate = self
        self.addToolBar()
    }
    
     func commonInit() {
        
//        super.commonInit()
        
        self.font = UIFont.appRegularFont(WithSize: self.font!.pointSize, shouldResize: true)
        self.placeholderColor = UIColor.appColor.appGrayColor
        //self.height = GET_PROPORTIONAL_HEIGHT(height: 100)
        //        self.font = UIFont.appFont_Regular(fontSize: self.font!.pointSize.proportionalFontSize())
        //        self.tintColor = APP_COLOR_BLUE
        //self.textContainerInset = UIEdgeInsets(top: 0, left:
//            -5, bottom: 0, right: 0)
        
//        self.updateConstraintsForPlaceholderLabel()
        
    }
    
    func addToolBar() {
        let toolBar = UIToolbar()
        toolBar.frame = CGRect(x: 0, y: 0, width: Constants.SCREEN_WIDTH, height: 44)
        toolBar.barTintColor = UIColor.gray
        toolBar.isTranslucent = true
        
        // TOOLBAR ITEMS
        let buttonDone : SPButton = SPButton.init(frame:.zero)
        buttonDone.setTitle("Done", for: .normal)
        
        buttonDone.setTitleColor(UIColor.white, for: .normal)
        buttonDone.addTarget(self, action:#selector(self.buttonNextPressed), for: .touchUpInside)
        buttonDone.sizeToFit()
        
        let buttonCancel : SPButton = SPButton.init(frame:.zero)
        buttonCancel.setTitle("Cancel", for: .normal)
        buttonCancel.setTitleColor(UIColor.white, for: .normal)
        buttonCancel.addTarget(self, action: #selector(self.buttonCancelPressed), for: .touchUpInside)
        buttonCancel.sizeToFit()
        
        let barButtonCancel = UIBarButtonItem(customView: buttonCancel)
        let barButtonNext = UIBarButtonItem(customView: buttonDone)
        let flexibleSpace = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        
        toolBar.items = [barButtonCancel,flexibleSpace, barButtonNext]
        self.inputAccessoryView = toolBar
    }
    
    @objc func buttonCancelPressed() {
        self.resignFirstResponder()
    }
    
    @objc func buttonNextPressed()
    {
        self.resignFirstResponder()
    }
    
    //MARK: COUNTER LABEL
    fileprivate func addCountLabel() {
        
        // ADD COUNTER LABEL TO TEXT VIEW SUPER VIEW
        self.labelCounter = SPLabel()
        self.labelCounter?.textColor = UIColor.gray
        self.labelCounter?.font = UIFont.appRegularFont(WithSize: 14)
        self.labelCounter?.numberOfLines = 0
        self.labelCounter?.textAlignment = .right
        self.updateCounterLabel()
        self.superview?.addSubview(self.labelCounter!)
        
        self.labelCounter?.autoPinEdge(.bottom, to: .bottom, of: self, withOffset: self.offsetTextContainer)
        self.labelCounter?.autoPinEdge(.trailing, to: .trailing, of: self, withOffset: -self.offsetTextContainer)
        
        self.labelCounter?.sizeToFit()
        
        self.layoutIfNeeded()
        self.textContainerInset = UIEdgeInsets(top: self.offsetTextContainer, left: self.offsetTextContainer, bottom: (self.labelCounter?.height)! + self.offsetTextContainer, right: self.offsetTextContainer)
        self.contentInset = UIEdgeInsets(top: 0, left: 0, bottom: self.offsetTextContainer + self.labelCounter!.height, right: 0)
    }
    
    //MARK: UPDATE COUNTER LABEL
    func updateCounterLabel(){
        self.labelCounter?.text = "\(self.text.textlength)/\(self.maximumLength)"
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
    }
    
    
    
    //MARK:- TEXTVIEW DELEGATE
    override func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        
        let newText = (textView.text as NSString).replacingCharacters(in: range, with: text)
        if newText.count > maxTextViewLimit || newText.containsEmoji
        {
            return false
        }
        self.labelCounter?.text = "\(newText.count)/\(self.maximumLength)"
        return super.textView(textView, shouldChangeTextIn: range, replacementText: text)
    }
    
    
    @available(iOS 10.0, *)
    func textView(_ textView: UITextView, shouldInteractWith URL: URL, in characterRange: NSRange, interaction: UITextItemInteraction) -> Bool
    {
        
        
        
        return super.textView(textView, shouldChangeTextIn: characterRange, replacementText: text)
    }
    
    
}
