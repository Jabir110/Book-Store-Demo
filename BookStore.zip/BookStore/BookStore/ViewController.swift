//
//  ViewController.swift
//  BookStore
//
//  Created by agilemac-9 on 8/8/19.
//  Copyright © 2019 Agileinfoways. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationBarHidden()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    func navigationBarHidden(){
        self.navigationController?.navigationBar.setBackgroundImage(UIImage(), for: .default)
        self.navigationController?.navigationBar.shadowImage = UIImage()
        self.navigationController?.navigationBar.isTranslucent = true
        self.navigationController?.view.backgroundColor = .clear
        
        self.tabBarController?.tabBar.backgroundImage = UIImage()
    }
    
    func tabBarBackgroundHidden(){
        
    }
}

