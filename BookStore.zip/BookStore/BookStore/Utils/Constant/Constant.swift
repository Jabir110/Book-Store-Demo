//
//  Constant.swift
//  BookStore
//
//  Created by agilemac-9 on 8/13/19.
//  Copyright © 2019 Agileinfoways. All rights reserved.
//

import Foundation
import UIKit

/// App Coman Constants
public struct Constants {
    
    static let  appDelegate                 = UIApplication.shared.delegate as! AppDelegate
    static let  platform                    = "ios"
    static let  udid                        = UIDevice.current.identifierForVendor!.uuidString
    static let  SCREEN_HEIGHT               = UIScreen.main.bounds.size.height
    static let  SCREEN_WIDTH                = UIScreen.main.bounds.size.width
    static var  AppName                     = Bundle.main.infoDictionary![kCFBundleNameKey as String] as! String // App Name
    static var  AppBundleVersion            = Bundle.main.infoDictionary?["CFBundleVersion"] as! String // App Bundle number
    static var  AppVersion                  = Bundle.main.infoDictionary!["CFBundleShortVersionString"] as AnyObject  // App Version
    static var  deviceModelName             = UIDevice.current.description    // Device Model Name
    static var  deviceVersionOS             = UIDevice.current.systemVersion  // Device Version Number
    static var  randomIdGenerationLength    = 6  // Device Version Number
    static var  deviceType                  = "1"  // 1 for iOS
}


// MARK:- _______________  APP DATE FORMATE _______________
struct AppDateFormates {
    static let abcDateformate                   = "dd MMM, "
    static let standardDateFormate              = "yyyy-MM-dd"
    static let birthDateFormate                 = "dd MMM yyyy"
    static let fullTimezoneDateFormateSend      = "yyy-MM-dd'T'HH:mm:ssz"
    static let orderDateFormate                 = "dd MMM YYYY, hh:mm a"
    static let orderListDateFormate             = "dd MMM YY hh:mm a"
    static let apiDateFormate                   = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"
    static let notificationDateFormate          = "dd MMM yy"
    static let chatDateFormate                  = "MMM dd, hh:mm"
}

// MARK:-  _______________  NETWORK ACTIVITY INDICATOR   _______________

public func showActivityIndicator(){
    DispatchQueue.main.async {
        UIApplication.shared.isNetworkActivityIndicatorVisible =  true
    }
}

public func hideActivityIndicator(){
    UIApplication.shared.isNetworkActivityIndicatorVisible =  false
}

// MARK:-  _______________  CUSTOM LOADER   _______________

public func showLoader(){
    OperationQueue.main.addOperation {
        //SVProgressHUD.setDefaultMaskType(.gradient)
        //SVProgressHUD.show()
    }
}

public func hideLoader(){
    OperationQueue.main.addOperation {
        //SVProgressHUD.dismiss()
    }
}

// MARK:- _______________ USER DEFAULTS _______________

public func setUserDefaultsFor(object:AnyObject, with key:String) {
    UserDefaults.standard.set(object, forKey: key)
    UserDefaults.standard.synchronize()
}

public func getUserDefaultsForKey(key:String) -> AnyObject? {
    return UserDefaults.standard.object(forKey: key) as AnyObject?
}

public func removeUserDefaultsFor(key:String) {
    UserDefaults.standard.removeObject(forKey: key)
    UserDefaults.standard.synchronize()
}

// MARK:- _______________ PROPORTIONAL SIZE _______________

func GET_PROPORTIONAL_WIDTH(width: CGFloat) -> CGFloat {
    return CGFloat((Constants.SCREEN_WIDTH * width)/750)
}
func GET_PROPORTIONAL_HEIGHT(height: CGFloat) -> CGFloat
{
    return CGFloat((Constants.SCREEN_HEIGHT * height)/1334)
}

func AlertInternetNotAvailable()
{
        UIAlertController.showAlert(withMessage: Messages.internetConnectionAlert) { (index) in
        }
    
    SPErrorView.showErrorView(withMessage: Messages.internetConnectionAlert)
}


/// Convert string from Dictionary
///
/// - Parameter dict: NSDictionary
/// - Returns: value in string
public func getStringFromDictionary(dict:Any) -> String{
    var strJson = ""
    do {
        let data = try JSONSerialization.data(withJSONObject: dict, options: JSONSerialization.WritingOptions.prettyPrinted)
        strJson = String(data: data, encoding: String.Encoding.utf8)!
    } catch let error as NSError {
        print("json error: \(error.localizedDescription)")
    }
    
    return strJson
}

// MARK:-  _______________ SET MODEL DATA IN USERDEFAULTS _______________
// MARK:

public func setModelDataInUserDefaults(key:String,value:Any){
    let data :Data = NSKeyedArchiver.archivedData(withRootObject: value)
    setUserDefaultsFor(object: data as AnyObject, with: key)
}

public func getModelDataFromUserDefaults(key:String) -> Any? {
    if let object = getUserDefaultsForKey(key: key) {
        return NSKeyedUnarchiver.unarchiveObject(with: object as! Data)
    }
    return nil
}
