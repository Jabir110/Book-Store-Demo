//
//  ConstantMessage.swift
//  BookStore
//
//  Created by agilemac-9 on 8/13/19.
//  Copyright © 2019 Agileinfoways. All rights reserved.
//

import Foundation

// MARK:-   _______________  MESSAGES   _______________

struct  Messages
{
    static let appName = Constants.AppName
    
    static let internetConnectionAlert = AILocalization.shared.messageInternetConnectionAlert
    static let somethingWentWrongAlertMessage           = AILocalization.shared.messageSomethingWentWrongAlertMessage
    static let logoutAlertMessage           = AILocalization.shared.messageLogoutAlertMessage
    static let messageCompulsoryLogoutAlertMessage    = AILocalization.shared.messageCompulsoryLogoutAlertMessage
}

// MARK:-   _______________  BUTTON TITLES  _______________

struct ButtonTitle
{
    static let titleYes = AILocalization.shared.buttonTitleYes
    static let titleNo = AILocalization.shared.buttonTitleNo
    static let titleCancel = AILocalization.shared.buttonTitleCancel
    static let titleRetry = AILocalization.shared.buttonTitleRetry
    static let titleOk = AILocalization.shared.buttonTitleOk
}
