//
//  HUFont.swift
//  HoodUber
//
//  Created by KavinSoni on 6/2/18.
//  Copyright © 2018 Agileinfoways. All rights reserved.
//

import UIKit

class SPCustomFont: NSObject {
    
    //MARK:- IMAGE GET
    //MARK:-

    enum SPFontName {
        
        case icon_add       // a
        case icon_arrow_back   // b
        case icon_arrow_forward       // c
        case icon_attach   // d
        case icon_call       // e
        case icon_cancel   // f
        case icon_chat       // g
        case icon_checkbox   // h
        case icon_clock       // i
        case icon_description   // j
        case icon_done   // k
        case icon_edit       // l
        case icon_event   // m
        case icon_favorite       // n
        case icon_favourite_border   // o
        case icon_filter       // p
        case icon_gps   // q
        case icon_home       // r
        case icon_information   // s
        case icon_mic       // t
        case icon_more_vert   // u
        case icon_more   // v
        case icon_navigation   // w
        case icon_notification       // x
        case icon_order   // y
        case icon_pause       // z
        case icon_play   // !
        case icon_radio_selected       // @
        case icon_radio_unselected   // $
        case icon_right_arrow       // %
        case icon_search   // ^
        case icon_send       // &
        case icon_skill   // *
        case icon_star_border   // (
        case icon_star_half       // )
        case icon_star   // {
        case icon_uncheckbox   // }
        case icon_photo_camera  // /
        
        func getHexCode() -> String {
            
            switch self {
                
            case .icon_add:
                return "a"
            case .icon_arrow_back:
                return "b"
            case .icon_arrow_forward:
                return "c"
            case .icon_attach:
                return "d"
            case .icon_call:
                return "e"
            case .icon_cancel:
                return "f"
            case .icon_chat:
                return "g"
            case .icon_checkbox:
                return "h"
            case .icon_clock:
                return "i"
            case .icon_description:
                return "j"
            case .icon_done:
                return "k"
            case .icon_edit:
                return "l"
            case .icon_event:
                return "m"
            case .icon_favorite:
                return "n"
            case .icon_favourite_border:
                return "o"
            case .icon_filter:
                return "p"
            case .icon_gps:
                return "q"
            case .icon_home:
                return "r"
            case .icon_information:
                return "s"
            case .icon_mic:
                return "t"
            case .icon_more_vert:
                return "u"
            case .icon_more:
                return "v"
            case .icon_navigation:
                return "w"
            case .icon_notification:
                return "x"
            case .icon_order:
                return "y"
            case .icon_pause:
                return "z"
            case .icon_play:
                return "!"
            case .icon_radio_selected:
                return "@"
            case .icon_radio_unselected:
                return "$"
            case .icon_right_arrow:
                return "%"
            case .icon_search:
                return "^"
            case .icon_send:
                return "&"
            case .icon_skill:
                return "*"
            case .icon_star_border:
                return "("
            case .icon_star_half:
                return ")"
            case .icon_star:
                return "{"
            case .icon_uncheckbox:
                return "}"
            case .icon_photo_camera:
                return "/"
            }
        }
    }
    
    //MARK:- TEXT GET
    //MARK:-
    class func getIconNew(iconName:String, Size size:CGFloat,Color color:UIColor) -> NSAttributedString {
        
        let objText = NSMutableAttributedString.init(string: "", attributes: [
            NSAttributedString.Key.font : UIFont.appIconFont(WithSize: size, shouldResize: false),
            NSAttributedString.Key.foregroundColor:color
            ])
        
        let attachment:NSTextAttachment = NSTextAttachment()
        attachment.image = iconName.getImage(ofColor: color)
        objText.append(NSAttributedString.init(attachment: attachment))
        return objText
    }

    //MARK:- IMAGE GET
    //MARK:-
    class func getImageIcon(iconName:String, Size size:CGFloat,Color color:UIColor) -> NSAttributedString {
        
        let objText = NSMutableAttributedString.init(string: iconName, attributes: [
            NSAttributedString.Key.font : UIFont.appIconFont(WithSize: size, shouldResize: false),
            NSAttributedString.Key.foregroundColor:color
            ])
        
        let attachment:NSTextAttachment = NSTextAttachment()
        attachment.image = iconName.getImage(ofColor: color)
        objText.append(NSAttributedString.init(attachment: attachment))
        return objText
    }
    
    public class func getImage(fromiconName iconName: String, size: CGFloat = 24.0, color: UIColor) -> UIImage? {
        
        if size == 0.0 { return nil }
        let symbol =  SPCustomFont.getImageIcon(iconName: iconName, Size: size, Color: color)
        let font = UIFont.appIconFont(WithSize: size, shouldResize: false)
        let chsize: CGSize = symbol.string.size(withAttributes: [.font: font])
        let imgsize = CGSize(width: size, height: size)
        UIGraphicsBeginImageContextWithOptions(imgsize, false, UIScreen.main.scale)
        let rect = CGRect(x: ((imgsize.width - chsize.width) / 2.0), y: (imgsize.height - chsize.height) / 2.0, width: chsize.width, height: chsize.height )
        let pStyle = NSMutableParagraphStyle()
        pStyle.alignment = .center
        pStyle.lineBreakMode = .byClipping
        let attrs = [NSAttributedString.Key.font: font, NSAttributedString.Key.paragraphStyle: pStyle, NSAttributedString.Key.foregroundColor: color] as [NSAttributedString.Key : Any]
        symbol.string.draw(in: rect, withAttributes: attrs)
        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return newImage
    }
}

extension String {
    
    func hexadecimal() -> Data? {
        var data = Data(capacity: self.count / 2)
        
        let regex = try! NSRegularExpression(pattern: "[0-9a-f]{1,2}", options: .caseInsensitive)
        regex.enumerateMatches(in: self, range: NSMakeRange(0, utf16.count)) { match, flags, stop in
            let byteString = (self as NSString).substring(with: match!.range)
            var num = UInt8(byteString, radix: 16)!
            data.append(&num, count: 1)
        }
        guard data.count > 0 else { return nil }
        return data
    }
    
    func getImage(ofColor: UIColor) -> UIImage {
        let font = UIFont.appIconFont(WithSize: 20, shouldResize: false)
        let chsize: CGSize = self.size(withAttributes: [.font: font])
        let imgsize = CGSize(width: 20, height: 20)
        UIGraphicsBeginImageContextWithOptions(imgsize, false, UIScreen.main.scale)
        let rect = CGRect(x: (imgsize.width - chsize.width) / 2.0, y: (imgsize.height - chsize.height) / 2.0, width: chsize.width, height: chsize.height)
        let pStyle = NSMutableParagraphStyle()
        pStyle.alignment = .center
        pStyle.lineBreakMode = .byClipping
        let attrs = [NSAttributedString.Key.font: font, NSAttributedString.Key.paragraphStyle: pStyle,NSAttributedString.Key.foregroundColor: ofColor] as [NSAttributedString.Key : Any]
        self.draw(in: rect, withAttributes: attrs)
        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return newImage ?? UIImage()
    }

    var getImage: UIImage {
        let font = UIFont.appIconFont(WithSize: 20, shouldResize: false)
        let chsize: CGSize = self.size(withAttributes: [.font: font])
        let imgsize = CGSize(width: 20, height: 20)
        UIGraphicsBeginImageContextWithOptions(imgsize, false, UIScreen.main.scale)
        let rect = CGRect(x: (imgsize.width - chsize.width) / 2.0, y: (imgsize.height - chsize.height) / 2.0, width: chsize.width, height: chsize.height)
        let pStyle = NSMutableParagraphStyle()
        pStyle.alignment = .center
        pStyle.lineBreakMode = .byClipping
        let attrs = [NSAttributedString.Key.font: font, NSAttributedString.Key.paragraphStyle: pStyle,NSAttributedString.Key.foregroundColor: UIColor.white] as [NSAttributedString.Key : Any]
        self.draw(in: rect, withAttributes: attrs)
        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return newImage ?? UIImage()
    }
}
