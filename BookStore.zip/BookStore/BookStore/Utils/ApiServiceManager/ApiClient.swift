//
//  ApiManager.swift
//  BookStore
//
//  Created by agilemac-9 on 8/9/19.
//  Copyright © 2019 Agileinfoways. All rights reserved.
//

import Foundation
import Alamofire

enum EnumUploadImagesType : Int
{
    case documentsKey
    case requesterImagesKey
    case providerImagesKey
    
    var key: String
    {
        switch self
        {
        case .documentsKey:
            return "documents"
        case .requesterImagesKey:
            return "requester_images"
        case .providerImagesKey:
            return "provider_images"
        }
    }
}

let ServiceManager = SPServiceManager.shared

class SPServiceManager: NSObject
{
    // MARK: - SHARED MANAGER
    static let shared = SPServiceManager()
    
    enum SPAPIResponseCode:Int {
        case SUCCESS = 200
        case CREATED_SUCCESS = 201
        case BAD_REQUEST = 400
        case MISSING_ACCESS_TOKEN = 401
        case EXPIRED_ACCESS_TOKEN = 402
        case INVALID_ACCESS_TOKEN = 403
        case USER_BLOCK = 423
    }
    
    //MARK:- ******** COMMON POST METHOD *********
    
    private func callGETApiWithNetCheck(url : String, headersRequired : Bool, params : [String : Any]?,isLoader:Bool, completionHandler : @escaping (String?,NSDictionary?,Bool) -> Void)
    {
        callGET_POSTApiWithNetCheck(isGet: true, url: url, headersRequired: headersRequired, params: params,isLoader:isLoader, completionHandler: completionHandler)
    }
    
    private func callPOSTApiWithNetCheck(url : String, headersRequired : Bool, params : [String : Any]?,isLoader:Bool, completionHandler : @escaping (String?,NSDictionary?,Bool) -> Void){
        callGET_POSTApiWithNetCheck(isGet: false, url: url, headersRequired: headersRequired, params: params,isLoader:isLoader, completionHandler: completionHandler)
    }
    
    private func callGET_POSTApiWithNetCheck(isGet:Bool, url : String, headersRequired : Bool, params : [String : Any]?,isLoader:Bool, completionHandler : @escaping (String?,NSDictionary?,Bool) -> Void){
        
        if !SPReachabilityManager.shared.isInternetAvailableForAllNetworks() {
            hideLoader()
            AlertInternetNotAvailable()
            return
        }
        
        if isLoader {
            showLoader()
        }
        
        var headers:[String:String] = [:]
        
        if headersRequired {
            headers[HeaderKeys.contentType] = "application/x-www-form-urlencoded"
            headers[HeaderKeys.authToken] = "Bearer " + SharedUser.accessToken
            headers[HeaderKeys.userId] = SharedUser.userId
            headers[HeaderKeys.languageCode] = AILocalization.getCurruntDeviceLanguage().languageNameForApi
            headers[HeaderKeys.isServiceProvider] = SharedUser.isRequestForServiceProvider ? "true" : "false"
        }
        
        print("/****************** New API Called ******************/")
        print("/* API URL : \(url)")
        print("/* API Params : \(getStringFromDictionary(dict: params ?? [:]))")
        print("/* API Headers : \(getStringFromDictionary(dict: headers))")
        print("/*******************************************************/")
        
        showActivityIndicator()
        
        Alamofire.request(url, method: isGet ? .get : .post, parameters: params, encoding: URLEncoding.default, headers: headers).responseJSON { (response) in
            
            if isLoader {
                hideLoader()
            }
            
            hideActivityIndicator()
            
            switch response.result {
                
            case .success(let JSON):
                
                print("JSON Response: \(JSON)")
                
                if let dictJson = JSON as? NSDictionary {
                    
                    let message = dictJson.object_forKeyWithValidationForClass_String(aKey: ResponseKeys.messageKey)
                    guard let statusCode = response.response?.statusCode else {
                        completionHandler(message,dictJson,false)
                        return
                    }
                    
                    switch SPAPIResponseCode.init(rawValue: statusCode)! {
                        
                    case .CREATED_SUCCESS:
                        completionHandler(message,nil,true)
                    case .SUCCESS:
                        completionHandler(message,dictJson,true)
                    case .BAD_REQUEST:
                        completionHandler(message,nil,false)
                    case .MISSING_ACCESS_TOKEN:
                        
                        self.logoutAlertAfterSessionExpired()
                        break
                    case .EXPIRED_ACCESS_TOKEN:
                        // actule call api for access token refress
                        // but right now we display message and redirect to login screen
                        self.logoutAlertAfterSessionExpired()
                        break
                    case .INVALID_ACCESS_TOKEN:
                        // display message and redirect to login screen
                        self.logoutAlertAfterSessionExpired()
                        break
                        
                    case .USER_BLOCK:
                        // display message and redirect to login screen
                        self.logoutAlertAfterSessionExpired()
                        break
                    }
                }
                else {
                    let error : String = (response.result.error?.localizedDescription)! as String
                    completionHandler(error,nil,false)
                }
                
            case .failure( _):
                
                let error : String = (response.result.error?.localizedDescription)! as String
                completionHandler(error,nil,false)
            }
        }
    }
    
    private func callGET_POSTApiForOrderWithNetCheck(isGet:Bool, url : String, headersRequired : Bool, params : [String : Any]?,isLoader:Bool, completionHandler : @escaping (String?,NSDictionary?,Bool,Bool) -> Void){
        
        if !SPReachabilityManager.shared.isInternetAvailableForAllNetworks() {
            AlertInternetNotAvailable()
            return
        }
        
        if isLoader {
            showLoader()
        }
        
        var headers:[String:String] = [:]
        
        if headersRequired {
            headers[HeaderKeys.contentType] = "application/x-www-form-urlencoded"
            headers[HeaderKeys.authToken] = "Bearer " + SharedUser.accessToken
            headers[HeaderKeys.userId] = SharedUser.userId
            headers[HeaderKeys.languageCode] = AILocalization.getCurruntDeviceLanguage().languageNameForApi
            headers[HeaderKeys.isServiceProvider] = SharedUser.isRequestForServiceProvider ? "true" : "false"
        }
        
        print("/****************** New API Called ******************/")
        print("/* API URL : \(url)")
        print("/* API Params : \(getStringFromDictionary(dict: params ?? [:]))")
        print("/* API Headers : \(getStringFromDictionary(dict: headers))")
        print("/*******************************************************/")
        
        showActivityIndicator()

        Alamofire.request(url, method: isGet ? .get : .post, parameters: params, encoding: URLEncoding.default, headers: headers).responseJSON { (response) in
            
            if isLoader {
                hideLoader()
            }
            
            hideActivityIndicator()
            
            switch response.result {
                
            case .success(let JSON):
                
                print("JSON Response: \(JSON)")
                
                if let dictJson = JSON as? NSDictionary
                {
                    let message = dictJson.object_forKeyWithValidationForClass_String(aKey: ResponseKeys.messageKey)
                    
                    guard let statusCode = response.response?.statusCode else {
                        completionHandler(message,dictJson,false,false)
                        return
                    }
                    
                    switch SPAPIResponseCode.init(rawValue: statusCode)! {
                        
                    case .CREATED_SUCCESS:
                        completionHandler(message,nil,true,false)
                    case .SUCCESS:
                        completionHandler(message,dictJson,true,false)
                    case .BAD_REQUEST:
                        completionHandler(message,nil,false,true)
                    case .MISSING_ACCESS_TOKEN:
                        
                        self.logoutAlertAfterSessionExpired()
                        break
                    case .EXPIRED_ACCESS_TOKEN:
                        self.logoutAlertAfterSessionExpired()
                        break
                    case .INVALID_ACCESS_TOKEN:
                        // display message and redirect to login screen
                        self.logoutAlertAfterSessionExpired()
                        break
                        
                    case .USER_BLOCK:
                        // display message and redirect to login screen
                        self.logoutAlertAfterSessionExpired()
                        break
                    }
                }
                else {
                    let error : String = (response.result.error?.localizedDescription)! as String
                    completionHandler(error,nil,false,false)
                }
                
            case .failure( _):
                
                let error : String = (response.result.error?.localizedDescription)! as String
                completionHandler(error,nil,false,false)
            }
        }
    }
    
    private func callPUTApiWithNetCheck(url : String, headersRequired : Bool, params : [String : Any]?,isLoader:Bool, completionHandler : @escaping (String?,NSDictionary?,Bool) -> Void){
        
        if !SPReachabilityManager.shared.isInternetAvailableForAllNetworks() {
            AlertInternetNotAvailable()
            return
        }
        
        if isLoader {
            showLoader()
        }
        
        var headers:[String:String] = [:]
        
        if headersRequired {
            headers[HeaderKeys.contentType] = "application/x-www-form-urlencoded"
            headers[HeaderKeys.authToken] = "Bearer " + SharedUser.accessToken
            headers[HeaderKeys.userId] = SharedUser.userId
            headers[HeaderKeys.languageCode] = AILocalization.getCurruntDeviceLanguage().languageNameForApi
            headers[HeaderKeys.isServiceProvider] = SharedUser.isRequestForServiceProvider ? "true" : "false"
        }
        
        print("/****************** New API Called ******************/")
        print("/* API URL : \(url)")
        print("/* API Params : \(getStringFromDictionary(dict: params ?? [:]))")
        print("/* API Headers : \(getStringFromDictionary(dict: headers))")
        print("/*******************************************************/")
        
        showActivityIndicator()
        
        Alamofire.request(url, method: .put, parameters: params, encoding: URLEncoding.default, headers: headers).responseJSON { (response) in
            
            if isLoader {
                hideLoader()
            }
            
            hideActivityIndicator()
            
            switch response.result {
                
            case .success(let JSON):
                
                print("JSON Response: \(JSON)")
                
                if let dictJson = JSON as? NSDictionary
                {
                    //                    let statusCode = dictJson.object_forKeyWithValidationForClass_Int(aKey: ResponseKeys.statusKey)
                    let message = dictJson.object_forKeyWithValidationForClass_String(aKey: ResponseKeys.messageKey)
                    
                    guard let statusCode = response.response?.statusCode else
                    {
                        completionHandler(message,dictJson,false)
                        return
                    }
                    
                    switch SPAPIResponseCode.init(rawValue: statusCode)! {
                        
                    case .CREATED_SUCCESS:
                        completionHandler(message,nil,false)
                    case .SUCCESS:
                        completionHandler(message,dictJson,true)
                    case .BAD_REQUEST:
                        completionHandler(message,nil,false)
                    case .MISSING_ACCESS_TOKEN:
                        self.logoutAlertAfterSessionExpired(message: message)
                        break
                        
                    case .EXPIRED_ACCESS_TOKEN:
                        // actule call api for access token refress
                        // but right now we display message and redirect to login screen
                        self.logoutAlertAfterSessionExpired(message: message)
                        break
                    case .INVALID_ACCESS_TOKEN:
                        // display message and redirect to login screen
                        self.logoutAlertAfterSessionExpired(message: message)
                        break
                        
                    case .USER_BLOCK:
                        // display message and redirect to login screen
                        self.logoutAlertAfterSessionExpired(message: message)
                        break
                    }
                }
                else
                {
                    
                    let error : String = (response.result.error?.localizedDescription)! as String
                    
                    completionHandler(error,nil,false)
                }
                
            case .failure( _):
                
                let error : String = (response.result.error?.localizedDescription)! as String
                
                completionHandler(error,nil,false)
            }
        }
    }
    
    //MARK:- ******** COMMON MULTIPART METHOD *********
    
    private func callUPLOADApiWithNetCheck(url : String,requestMethod:HTTPMethod = .post, document:[AnyObject]?, headersRequired : Bool, params : [String : Any]?,uploadKey:EnumUploadImagesType = .documentsKey,isLoader:Bool, completionHandler : @escaping (String?,NSDictionary?,Bool) -> Void){
        
        if !SPReachabilityManager.shared.isInternetAvailableForAllNetworks() {
            AlertInternetNotAvailable()
            completionHandler(nil,nil,false)
            return
        }
        
        if isLoader {
            showLoader()
        }
        
        var headers:[String:String] = [:]
        if headersRequired {
            headers[HeaderKeys.contentType] = "application/x-www-form-urlencoded"
            headers[HeaderKeys.authToken] = SharedUser.accessToken
            headers[HeaderKeys.userId] = SharedUser.userId
            headers[HeaderKeys.languageCode] = AILocalization.getCurruntDeviceLanguage().languageNameForApi
            headers[HeaderKeys.isServiceProvider] = SharedUser.isRequestForServiceProvider ? "true" : "false"
        }
        
        print("/****************** New API Called ******************/")
        print("/* API URL : \(url)")
        print("/* API Params : \(getStringFromDictionary(dict: params ?? [:]))")
        print("/* API Headers : \(getStringFromDictionary(dict: headers))")
        print("/*******************************************************/")

        showActivityIndicator()
        
        Alamofire.upload(multipartFormData:{ multipartFormData in
            
            if let params = params
            {
                for eachKey in params.keys
                {
                    print("UPLOAD KEYS:\(eachKey) : \(String(describing: params[eachKey]))")
                    
                    if let value = params[eachKey] as? String
                    {
                        multipartFormData.append(value.data(using: .utf8)!, withName: eachKey)
                    }
                    else  if let arrayString = params[eachKey] as? [String]
                    {
                        if let jsonArr = try? JSONEncoder().encode(arrayString)
                        {
                            multipartFormData.append(jsonArr, withName: eachKey)
                        }
                        
                        //    multipartFormData.append(getStringFromDictionary(dict: arrayString).data(using: .utf8)!, withName: eachKey)
                        
                    }else if let value = params[eachKey]
                    {
                        let strValue = "\(value)"
                        
                        multipartFormData.append(strValue.data(using: .utf8)!, withName: eachKey)
                    }
                }
            }
            
            if document != nil
            {
                for object in document!
                {
                    /*
                    if let imgObject = object as? SPMedia
                    {
                        if let mbData = imgObject.image!.compressData(maxFileSize: 10)
                        {
                            multipartFormData.append(mbData, withName: uploadKey.key , fileName: "\(randomStringGenerate()).\(Data.fileExtension(for: mbData))" , mimeType: Data.mimeType(for: mbData))
                        }
                    }
                    
                    if let imgObject = object as? FileModel
                    {
                        if let imageData = imgObject.documentData
                        {
                            multipartFormData.append(imageData, withName: uploadKey.key , fileName: imgObject.documentType == .Image ? "\(randomStringGenerate()).\(Data.fileExtension(for: imageData))" : "\(randomStringGenerate()).\(imgObject.documentName.fileExtension())" , mimeType: Data.mimeType(for: imageData))
                        }
                    }*/
                }
            }
        },
                         usingThreshold:UInt64.init(),
                         to:url,
                         method:requestMethod,
                         headers:headers,
                         encodingCompletion: { encodingResult in
                            
                            if isLoader
                            {
                                showLoader()
                            }
                            
                            showActivityIndicator()
                            
                            
                            switch encodingResult
                            {
                            case .success(let upload, _, _):
                                
                                upload.responseString(completionHandler: { (response) in
                                    print(response)
                                })
                                
                                upload.responseJSON { (response) in
                                    
                                    if isLoader
                                    {
                                        hideLoader()
                                    }
                                    
                                    hideActivityIndicator()
                                    
                                    switch response.result
                                    {
                                    case .success(let JSON):
                                        
                                        print("JSON Response: \(JSON)")
                                        
                                        if let dictJson = JSON as? NSDictionary
                                        {
                                            //let statusCode = dictJson.object_forKeyWithValidationForClass_Int(aKey: ResponseKeys.statusKey)
                                            let message = dictJson.object_forKeyWithValidationForClass_String(aKey: ResponseKeys.messageKey)
                                            
                                            guard let statusCode = response.response?.statusCode else
                                            {
                                                completionHandler(message,dictJson,false)
                                                return
                                            }
                                            
                                            switch SPAPIResponseCode.init(rawValue: statusCode)! {
                                                
                                            case .CREATED_SUCCESS:
                                                completionHandler(message,dictJson,true)
                                            case .SUCCESS:
                                                completionHandler(message,dictJson,true)
                                            case .BAD_REQUEST:
                                                completionHandler(message,nil,false)
                                            case .MISSING_ACCESS_TOKEN:
                                                self.logoutAlertAfterSessionExpired()
                                                break
                                                
                                            case .EXPIRED_ACCESS_TOKEN:
                                                // actule call api for access token refress
                                                // but right now we display message and redirect to login screen
                                                self.logoutAlertAfterSessionExpired(message: message)
                                                break
                                            case .INVALID_ACCESS_TOKEN:
                                                // display message and redirect to login screen
                                                self.logoutAlertAfterSessionExpired(message: message)
                                                break
                                                
                                            case .USER_BLOCK:
                                                // display message and redirect to login screen
                                                self.logoutAlertAfterSessionExpired(message: message)
                                                break
                                            }
                                            
                                            
                                        }
                                        else
                                        {
                                            let error : String = (response.result.error?.localizedDescription)! as String
                                            
                                            completionHandler(error,nil,false)
                                        }
                                        
                                    case .failure( _):
                                        
                                        let error : String = (response.result.error?.localizedDescription)! as String
                                        
                                        completionHandler(error,nil,false)
                                    }
                                }
                                
                            case .failure(let encodingError):
                                print("ERR: UPLOAD: \(encodingError.localizedDescription)")
                                
                                let error : String = (encodingError.localizedDescription) as String
                                
                                completionHandler(error,nil,false)
                            }
        })
    }
    
    //File For Chat
    private func callUPLOADApiWithFileUrlNetCheck(url : String,requestMethod:HTTPMethod = .post, document:AnyObject?, headersRequired : Bool, params : [String : Any]?,isLoader:Bool, completionHandler : @escaping (String?,NSDictionary?,Bool) -> Void){
        
        if !SPReachabilityManager.shared.isInternetAvailableForAllNetworks()
        {
            
            AlertInternetNotAvailable()
            completionHandler(nil,nil,false)
            return
        }
        
        if isLoader
        {
            showLoader()
        }
        
        var headers:[String:String] = [:]
        if headersRequired
        {
            headers[HeaderKeys.contentType] = "application/x-www-form-urlencoded"
            headers[HeaderKeys.authToken] = SharedUser.accessToken
            headers[HeaderKeys.userId] = SharedUser.userId
            headers[HeaderKeys.languageCode] = AILocalization.getCurruntDeviceLanguage().languageNameForApi
            headers[HeaderKeys.isServiceProvider] = SharedUser.isRequestForServiceProvider ? "true" : "false"
        }
        
        print("/****************** New API Called ******************/")
        print("/* API URL : \(url)")
        print("/* API Params : \(getStringFromDictionary(dict: params ?? [:]))")
        print("/* API Headers : \(getStringFromDictionary(dict: headers))")
        print("/*******************************************************/")

        showActivityIndicator()
        
        Alamofire.upload(multipartFormData:{ multipartFormData in
            
            if let params = params
            {
                for eachKey in params.keys
                {
                    print("UPLOAD KEYS:\(eachKey) : \(String(describing: params[eachKey]))")
                    
                    if let value = params[eachKey] as? String
                    {
                        multipartFormData.append(value.data(using: .utf8)!, withName: eachKey)
                    }
                    else  if let arrayString = params[eachKey] as? [String]
                    {
                        if let jsonArr = try? JSONEncoder().encode(arrayString)
                        {
                            multipartFormData.append(jsonArr, withName: eachKey)
                        }
                        
                        //    multipartFormData.append(getStringFromDictionary(dict: arrayString).data(using: .utf8)!, withName: eachKey)
                        
                    }else if let value = params[eachKey]
                    {
                        let strValue = "\(value)"
                        
                        multipartFormData.append(strValue.data(using: .utf8)!, withName: eachKey)
                    }
                    
                }
            }
            
            if document != nil
            {
                /*
                if let fileObject = document as? CHATFileUpload
                {
                    print("=========FILE UPLOAD CALL=========")
                    print("FILE URL: \(fileObject.fileLocalPath!)")
                    print("FILE NAME: \(fileObject.fileName)")
                    print("FILE MINE TYPE: \(fileObject.fileMimeType)")
                    print("REQUEST KEY: \(RequestKeys.documentsKey)")
                    print("==================================")
                    
                    multipartFormData.append(fileObject.fileLocalPath!, withName: RequestKeys.documentsKey, fileName: fileObject.fileName, mimeType: fileObject.fileMimeType)
                }
    */
            }
        },
                         usingThreshold:UInt64.init(),
                         to:url,
                         method:requestMethod,
                         headers:headers,
                         encodingCompletion: { encodingResult in
                            
                            if isLoader
                            {
                                showLoader()
                            }
                            
                            showActivityIndicator()
                            
                            
                            switch encodingResult
                            {
                            case .success(let upload, _, _):
                                
                                upload.responseString(completionHandler: { (response) in
                                    print(response)
                                })
                                
                                upload.responseJSON { (response) in
                                    
                                    if isLoader
                                    {
                                        hideLoader()
                                    }
                                    
                                    hideActivityIndicator()
                                    
                                    switch response.result
                                    {
                                    case .success(let JSON):
                                        
                                        print("JSON Response: \(JSON)")
                                        
                                        if let dictJson = JSON as? NSDictionary
                                        {
                                            //let statusCode = dictJson.object_forKeyWithValidationForClass_Int(aKey: ResponseKeys.statusKey)
                                            let message = dictJson.object_forKeyWithValidationForClass_String(aKey: ResponseKeys.messageKey)
                                            
                                            guard let statusCode = response.response?.statusCode else
                                            {
                                                completionHandler(message,dictJson,false)
                                                return
                                            }
                                            
                                            switch SPAPIResponseCode.init(rawValue: statusCode)! {
                                                
                                            case .CREATED_SUCCESS:
                                                completionHandler(message,dictJson,true)
                                            case .SUCCESS:
                                                completionHandler(message,dictJson,true)
                                            case .BAD_REQUEST:
                                                completionHandler(message,nil,false)
                                            case .MISSING_ACCESS_TOKEN:
                                                completionHandler(message,nil,false)
                                                
                                            case .EXPIRED_ACCESS_TOKEN:
                                                // actule call api for access token refress
                                                // but right now we display message and redirect to login screen
                                                self.logoutAlertAfterSessionExpired(message: message)
                                                break
                                            case .INVALID_ACCESS_TOKEN:
                                                // display message and redirect to login screen
                                                self.logoutAlertAfterSessionExpired(message: message)
                                                break
                                                
                                            case .USER_BLOCK:
                                                // display message and redirect to login screen
                                                self.logoutAlertAfterSessionExpired(message: message)
                                                break
                                            }
                                            
                                            
                                        }
                                        else
                                        {
                                            let error : String = (response.result.error?.localizedDescription)! as String
                                            
                                            completionHandler(error,nil,false)
                                        }
                                        
                                    case .failure( _):
                                        
                                        let error : String = (response.result.error?.localizedDescription)! as String
                                        
                                        completionHandler(error,nil,false)
                                    }
                                }
                                
                            case .failure(let encodingError):
                                print("ERR: UPLOAD: \(encodingError.localizedDescription)")
                                
                                let error : String = (encodingError.localizedDescription) as String
                                
                                completionHandler(error,nil,false)
                            }
        })
    }
    
    func cancellAllPendingRequests(){
        
        let sessionManager = Alamofire.SessionManager.default;
        
        sessionManager.session.getTasksWithCompletionHandler { dataTasks, uploadTasks, downloadTasks in
            
            print("\n\n")
            
            dataTasks.forEach({ (task) in
                print("1 id : \(task.taskIdentifier) __ \(String(describing: task.currentRequest)) __ \(String(describing: task.originalRequest))")
            })
            
            dataTasks.forEach({ (task) in
                print("2 id : \(task.taskIdentifier) __ \(String(describing: task.currentRequest)) __ \(String(describing: task.originalRequest))")
            })
            
            dataTasks.forEach({ (task) in
                print("3 id : \(task.taskIdentifier) __ \(String(describing: task.currentRequest)) __ \(String(describing: task.originalRequest))")
            })
            
            
            dataTasks.forEach { $0.cancel() }
            uploadTasks.forEach { $0.cancel() }
            downloadTasks.forEach { $0.cancel() }
        }
    }
    
    
    func logoutAlertAfterSessionExpired(message:String = Messages.messageCompulsoryLogoutAlertMessage) {
        
        UIAlertController.showAlert(withMessage: message) { (index) in
            
            //Setup Default Language
            //appDelegate.setUpViewAsPerLocalizeLanguage(value: .english)
            
            //Stop Location Update
            //LocationTracker.shared.stopLocationTracking()
            //LocationTracker.shared.locationStatus = .Stop
            
            //User Reset and Root change
            SharedUser.reset()
            //appDelegate.setUpRootController()
        }
    }
}
