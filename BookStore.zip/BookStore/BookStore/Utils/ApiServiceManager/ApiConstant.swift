//
//  APIKeys.swift
//  BookStore
//
//  Created by agilemac-9 on 8/9/19.
//  Copyright © 2019 Agileinfoways. All rights reserved.
//

import Foundation

struct APIConstant {
    
    //static let twitterConsumerKey = "YourKey"
    //static let twitterConsumerSecret = "YourKey"
    //static let googleClientID = "YourKey"
    //static let googlePlacesAPIKey = "YourKey"

    static let baseURL = "http://202.131.117.92:4041" // Local Server
    //static let baseURL = "https://dealmeal2018.com" // Live Server
    static let apiVersion = "v2"
}

//MARK:- _______________ USERDEFAULT KEYS  _______________
struct UserDefaultsKeys {
    static let login = "KEY_IS_USER_LOGGED_IN"
    static let appLanguage = "KEY_APP_LANGUAGE"
}

//MARK:-
struct ApiName {
    static let demoApiName         = "demo"
}

//MARK:-
struct ApiURL {
    static let demoApiURL           = APIConstant.baseURL + ApiName.demoApiName
}

//MARK:-
struct HeaderKeys {
    static var contentType = "Content-Type"
    static var authToken = "Authorization"
    static var languageCode = "language_code"
    static var userId = "user_id"
    static var isServiceProvider = "is_service_provider"
}

// MARK:-   _______________  APP KEYS   _______________
struct AppKeys {
    static var currentUser = "CurrentUser"
}

//MARK:-
struct RequestKeys {
    static let idKey = "id"
    static let userIdKey = "_id"
    static let userIdFullKey = "userid"
    static let emailKey = "email"
    static let passwordKey = "password"
    static let imageDataKey = "profilePicture"
    static let limitKey = "limit"
    static let skipKey = "skip"
    static let offsetKey = "offset"
    static let documentsKey = "documents"
    static let deviceTypeKey = "device_type"
    static let pushTokenKey = "push_token"
    
    static let countryIdKey = "country_id"
    static let stateIdKey = "state_id"
    
    static let searchStringKey = "search_string"
    
    static let latitudeKey = "lat"
    static let longitudeKey = "lng"
    
    static let profileIdKey = "profile_id"
    
    static let isOnlineKey = "is_online"
    static let likeKey = "like"
    
    static let providerIdKey = "provider_id"
    static let favouriteStatusKey = "favourite_status"
    
    static let addressKey = "address"
    static let commentsKey = "comments"
    static let createdAtKey = "created_at"
    static let updatedAtKey = "updated_at"
    static let radiusKey = "radius"
    static let jobAmountKey = "job_amount"
    static let bidAmountKey    = "bid_amount"
    static let descriptionKey = "description"
    static let jobDateKey = "job_date"
    static let requesterImagesKey = "requester_images"
    static let orderRecomendedTechKey = "order_recomended_tech"
    static let orderSkillsKey = "order_skills"
    
    static let userKey = "user_id"
    static let accountIdKey = "account_id"
    static let accountHolderKey = "account_holder"
    static let accountNumberKey = "account_number"
    static let bankNameKey = "bank_name"
    static let routingNumberKey = "routing_number"
    
    static let toUserIdKey = "to_user_id"
    static let fromUseridKey = "from_user_id"
    static let ratingsKey = "ratings"
    static let commentKey = "comment"
    static let chatImageKey = "chatImage"
    static let orderIdKey = "order_id"
    static let orderDisplayIdKey = "orderDisplayID"
    static let orderTypeKey = "order_type"
    static let isRequesterKey = "is_requester"
    static let orderStatusKey = "order_status"
    static let paymentStatusKey = "payment_status"
    static let providerImagesKey = "provider_images"
    static let requestorImagesKey = "requestor_images"
    static let serviceRequestorKey = "service_requestor"
    static let serviceProviderKey = "service_provider"
    static let orderAcceptedKey     = "order_accepted"
    static let isOrderAcceptedKey     = "is_order_accepted"
    static let isOrderCancelForProviderKey     = "is_order_cancel_for_provider"
}

//MARK:-
struct ResponseKeys{
    static let deviceIdKey = "deviceId"
    static let deviceTypeKey = "device_type"
    
    static let statusKey = "status"
    static let messageKey = "message"
    static let dataKey = "data"
    static let listKey = "list"
    static let documentsKey = "documents"
    static let totalRecordsKey = "total_records"
    static let totalReviewsKey = "total_reviews"
    
    static let userIdKey = "_id"
    static let fullNameKey = "full_name"
    static let nickNameKey = "nick_name"
    static let userNameKey = "user_name"
    static let emailKey = "email"
    static let passwordKey = "password"
    static let phoneNumberKey = "mobile_number"
    static let accessTokenKey = "access_token"
    static let birthDateKey = "birth_date"
    
    static let cityIdKey = "city_id"
    static let countryIdKey = "country_id"
    static let genderKey = "gender"
    static let isActiveKey = "isActive"
    static let isLikedKey = "is_liked"
    static let isFavKey = "is_favourite"
    static let pushTokenKey = "push_token"
    static let requestedForServiceProviderKey = "requested_for_service_provider"
    static let stateIdKey = "state_id"
    static let nationalitiesKey = "nationalities"
    static let profileImageKey = "profile_picture"
    static let isOnlineKey = "is_online"
    static let titleKey = "title"
    static let nameKey = "name"
    static let isSelectedKey = "isselected"
    static let categoryIdKey = "category_id"
    static let categoryKey = "category"
    static let oldPasswordKey = "old_password"
    static let newPasswordKey = "new_password"
    static let averageRatingKey = "average_rating"
    static let userTypeKey = "userType"
    static let cityKey = "city"
    static let countryKey = "country"
    static let stateKey = "state"
    static let skillsKey = "skills"
    static let aboutKey = "about"
    static let isPictureRemovedKey = "is_picture_removed"
    
    static let locationKey = "location"
    static let maxDistanceKey = "max_distance"
    static let distanceKey = "distance"
    static let avgRatingKey = "average_rating"
    static let ageKey = "age"
    static let nationalityKey = "nationality"
    static let imageURLKey = "image_url"
    static let ratingsKey = "ratings"
    static let orderLocationKey = "orderLocation"
    static let radiusKey = "radius"
    static let jobAmountKey = "job_amount"
    static let bidAmountKey    = "bid_amount"
    static let descriptionKey = "description"
    static let jobDateKey = "job_date"
    static let addressKey = "address"
    static let orderStatusKey = "order_status"
    static let isServiceProviderKey = "is_service_provider"
    static let providerLocationKey = "provider_location"
    
    static let bidCountKey = "bid_count"
    static let bidKey = "bid"
    
    static let orderTotalLikesKey = "order_total_likes"
    static let orderTotalCommentsKey = "order_total_comments"
    
    static let commentsKey = "comment"
    static let toUserIdKey = "to_user_id"
    static let fromUserIdKey = "from_user_id"
    static let accountsKey = "accounts"
    
    static let totalOrdersKey = "total_orders"
    static let totalOrdersDoneKey = "total_orders_done"
}
