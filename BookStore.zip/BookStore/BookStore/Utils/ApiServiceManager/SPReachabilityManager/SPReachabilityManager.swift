//
//  SPReachabilityManager.swift
//  ServiceProvider
//
//  Created by agileimac-2 on 18/03/19.
//  Copyright © 2019 agileimac-2. All rights reserved.
//

import UIKit
import Reachability

class SPReachabilityManager: NSObject
{
    
    private let reachability = Reachability()!
    private var isFirstTimeSetupDone:Bool = false
    private var callCounter:Int = 0
    
    // MARK: - SHARED MANAGER
    static let shared: SPReachabilityManager = SPReachabilityManager()
    
    
    //MARK:- ALL NETWORK CHECK
    func isInternetAvailableForAllNetworks() -> Bool {
        if(!self.isFirstTimeSetupDone){
            self.isFirstTimeSetupDone = true
            doSetupReachability()
        }
        return reachability.connection != .none || reachability.connection == .wifi || reachability.connection == .cellular
    }
    
    
    //MARK:- SETUP
    private func doSetupReachability() {
        
        reachability.whenReachable = { [weak self]reachability in
            DispatchQueue.main.async {
                self?.postIntenetReachabilityDidChangeNotification(isInternetAvailable: true)
            }
        }
        reachability.whenUnreachable = { [weak self]reachability in
            DispatchQueue.main.async {
                self?.postIntenetReachabilityDidChangeNotification(isInternetAvailable: false)
            }
        }
        do{
            try reachability.startNotifier()
        }catch{
        }
    }
    
    deinit {
        reachability.stopNotifier()
        NotificationCenter.default.removeObserver(self, name: Notification.Name.reachabilityChanged, object: nil)
    }
    
    
    
    //MARK:- NOTIFICATION
    private func postIntenetReachabilityDidChangeNotification(isInternetAvailable isAvailable:Bool){
        //        print("\n\n")
        //        print("NET REACHABILITY CHANGED : \(isAvailable)")
        
        DispatchQueue.main.async {
            
            if(isAvailable){
                // TO AVOID INITIAL ALERT
                if(self.callCounter != 0){
                    //                    let dialog = AIDialogueSnackAlert()
                    //                    dialog.showDialogue(withMessage: "You are now ONLINE", bgColor: APP_COLOR_GREEN, topBottomMargin: 12) { (completion) in
                    //                    }
                }
            }else{
                //                let dialog = AIDialogueSnackAlert()
                //                dialog.showDialogue(withMessage: "You are now OFFLINE", bgColor: APP_COLOR_RED, topBottomMargin: 12) { (completion) in
                //                }
            }
            self.callCounter += 1
            
            NotificationCenter.default.post(NSNotification(name: Notification.Name.reachabilityChanged, object: nil) as Notification)
            
        }
        
    }
}
