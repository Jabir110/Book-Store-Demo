//
//  SPTextValidation.swift
//  ServiceProvider
//
//  Created by agileimac-2 on 18/03/19.
//  Copyright © 2019 agileimac-2. All rights reserved.
//

import Foundation
import UIKit

//MARK:- VALIDATION CONSTANTS

let MINIMUM_CHAR_NAME = 2
let MAXIMUM_CHAR_NAME = 50

let MINIMUM_CHAR_EMAIL = 2
let MAXIMUM_CHAR_EMAIL = 60

let MINIMUM_CHAR_CITY = 2
let MAXIMUM_CHAR_CITY = 50

let MINIMUM_CHAR_PASSWORD = 6
let MAXIMUM_CHAR_PASSWORD = 16

let MINIMUM_CHAR_PHONE_NUMBER = 8
let MAXIMUM_CHAR_PHONE_NUMBER = 16

let MINIMUM_CHAR_ACCOUNT_NUMBER = 9
let MAXIMUM_CHAR_ACCOUNT_NUMBER = 17

let MINIMUM_CHAR_ROUTING_NUMBER = 9
let MAXIMUM_CHAR_ROUTING_NUMBER = 9

let MINIMUM_CHAR_COUNTRY = 2
let MAXIMUM_CHAR_COUNTRY = 50

let MINIMUM_CHAR_NATIONALITY = 2
let MAXIMUM_CHAR_NATIONALITY = 500


let textValidation = TextValidation.shared

public enum EITextFieldValidationType : Int
{
    case EIType_UserName
    case EIType_NickName
    case EIType_Email
    case EIType_Password
    case EIType_SignUpPassword
    case EIType_OldPassword
    case EIType_NewPassword
    case EIType_ConfirmPassword
    case EIType_Phone
    case EIType_BirthDate
    case EIType_Country
    case EIType_FullName
    case EIType_City
    case EIType_State
    case EIType_Nationality
    case EIType_Job
    case EIType_AccHolderName
    case EIType_AccountNumber
    case EIType_BankName
    case EIType_RoutingNumber
}

public enum TextValidationType : Int {
    case LengthValidation
    case BlankValidation
}


class TextValidation: NSObject {
    
    
    static let shared = TextValidation()
    
    
    // MARK: ________________________ NORMALE VALIDATION FUNCTION________________________
    
    
    func isValidate(_ textFields : [SPTextField]) -> Bool {
        var validate : Bool = false
        for textField in textFields {
            
            let validationType = textField.validationType
            
            let finalString = textField.text!.trimmingCharacters(in: CharacterSet.whitespaces)
            textField.text = finalString
            
            
            if checkString(finalString) {
                self.textValidation(validationType!, textValidationType: .BlankValidation)
                validate = false
                break;
            }else{
                // for perticular textfiled validation
                
                
                if validationType == .EIType_Email {
                    if !self.isValidEmail(finalString) {
                        self.textValidation(validationType!, textValidationType: .LengthValidation)
                        validate = false
                        break;
                    }
                }
                
            }
            
            var minLength : Int
            minLength = textField.config.minLength!
            
            var maxLength : Int
            maxLength = textField.config.maxLength!
            
            var curruntLength : Int
            curruntLength = (finalString.count)
            
            if maxLength>0 {
                if curruntLength >= minLength &&  curruntLength <=  maxLength {
                    validate = true
                }
                else{
                    self.textValidation(validationType!, textValidationType: .LengthValidation)
                    validate = false
                    break;
                }
            }else{
                if curruntLength >= minLength {
                    validate = true
                }
                else{
                    self.textValidation(validationType!, textValidationType: .LengthValidation)
                    validate = false
                    break;
                }
            }
            
            guard validate == true else {
                break;
            }
        }
        
        
        return validate
    }
    
    fileprivate func textValidation(_ validationType : EITextFieldValidationType, textValidationType : TextValidationType) {
        
        // BLANK TEXT VALIDATION
        
        var message : String = String()
        
        switch validationType {
        case .EIType_UserName:
            
            message = (textValidationType == .BlankValidation ?
                validationMessages.message_Username_Blank :
                validationMessages.message_Username_Length_NotValid)
            
        case .EIType_NickName:
            
            message = (textValidationType == .BlankValidation ?
                validationMessages.message_Nickname_Blank :
                validationMessages.message_Nickname_Length_NotValid)
            
        case .EIType_Email:
            
            message = (textValidationType == .BlankValidation ?
                validationMessages.message_Email_Blank :
                validationMessages.message_Email_NotValid)
            
        case .EIType_OldPassword:
            
            message = (textValidationType == .BlankValidation ?
                validationMessages.message_OldPassword_Blank :
                validationMessages.message_OldPassword_NotValid)
            
        case .EIType_Password:
            
            message = (textValidationType == .BlankValidation ?
                validationMessages.message_Password_Blank :
                validationMessages.message_Password_NotValid)
            
        case .EIType_SignUpPassword:
            
            message = (textValidationType == .BlankValidation ?
                validationMessages.message_SignUpPassword_Blank :
                validationMessages.message_SignUpPassword_NotValid)
            
        case .EIType_ConfirmPassword:
            
            message = (textValidationType == .BlankValidation ? validationMessages.message_ConfirmPassword_Blank : validationMessages.message_ConfirmPassword_NotValid)
        
        case .EIType_NewPassword:
            message = (textValidationType == .BlankValidation ?
                validationMessages.message_New_Password_Blank :
                validationMessages.message_New_Password_NotValid)
            
        case .EIType_Phone:
            
            message = (textValidationType == .BlankValidation ?
                validationMessages.message_Phone_Blank :
                validationMessages.message_Phone_Length_NotValid)
            
        case .EIType_BirthDate:
            
            message = (textValidationType == .BlankValidation ?
                validationMessages.message_Birthday_Blank :
                validationMessages.message_Birthday_Blank)
        
        case .EIType_Country:
            
            message = (textValidationType == .BlankValidation ?
                validationMessages.message_Country_Blank :
                validationMessages.message_Country_NotValid)
            
        case .EIType_State:
            
            message = (textValidationType == .BlankValidation ?
                validationMessages.message_State_Blank :
                validationMessages.message_State_NotValid)
            
        case .EIType_FullName:
            message = (textValidationType == .BlankValidation ?
                validationMessages.message_FullName_Blank :
                validationMessages.message_FullName_NotValid)
       
        case .EIType_City:
            message = (textValidationType == .BlankValidation ?
                validationMessages.message_City_Blank :
                validationMessages.message_City_NotValid)
        
        case .EIType_Nationality:
            message = (textValidationType == .BlankValidation ?
                validationMessages.message_Nationality_Blank :
                validationMessages.message_Nationality_NotValid)
            
        case .EIType_AccHolderName:
            message = (textValidationType == .BlankValidation ?
                validationMessages.message_AccountHolderName_Blank :
                validationMessages.message_AccountHolderName_NotValid)
        
        case .EIType_AccountNumber:
            message = (textValidationType == .BlankValidation ?
                validationMessages.message_AccountNumber_Blank :
                validationMessages.message_AccountNumber_NotValid)
            
        case .EIType_BankName:
            message = (textValidationType == .BlankValidation ?
                validationMessages.message_BankName_Blank :
                validationMessages.message_BankName_NotValid)
            
        case .EIType_RoutingNumber:
            message = (textValidationType == .BlankValidation ?
                validationMessages.message_RoutingNumber_Blank :
                validationMessages.message_RoutingNumber_NotValid)
            
        case .EIType_Job:
            message = (textValidationType == .BlankValidation ?
                validationMessages.message_Job_Blank :
                validationMessages.message_Job_NotValid)
        }
        
        self.displayAlert(message)
        
    }
    
    
    func validConfirmPassword(password:String,confirmPassword:String)  -> Bool{
        
        //  TEXT LENGTH VALIDATION
        
        if password == confirmPassword{
            return true
        }else{
            self.displayAlert(validationMessages.message_PasswordNotMatch)
            return false
        }
    }
    
    func validConfirmNewPassword(password:String,confirmPassword:String)  -> Bool{
        
        //  TEXT LENGTH VALIDATION
        
        if password == confirmPassword{
            return true
        }else{
            self.displayAlert(validationMessages.message_PasswordNotMatch)
            return false
        }
    }
    
    fileprivate func displayAlert(_ message:String) {
        
        
//        let alert = UIAlertController(title: Constants.AppName, message: message, preferredStyle: .alert)
//        alert.addAction(UIAlertAction(title: "Okay", style: .cancel, handler: { (action) in
//            appDelegate.window?.rootViewController?.dismiss(animated: true, completion: nil)
//        }))
//        appDelegate.window?.rootViewController?.present(alert, animated: true, completion: nil)
        
        SPErrorView.showErrorView(withMessage: message) { [weak self](_) in
            guard let _ = self else { return }
        }

    }
    
    
    // MARK:-
    // MARK:-
    
    fileprivate func isValidEmail(_ testStr:String) -> Bool {
        
        let emailRegEx = "[A-Z0-9a-z]+([._%+-]{1}[A-Z0-9a-z]+)*@[A-Za-z0-9]+\\.([A-Za-z])*([A-Za-z0-9]+\\.[A-Za-z]{2,4})*"
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailTest.evaluate(with: testStr)
    }
    
    fileprivate func checkString(_ string:String) -> Bool {
        
        if string.isEmpty || string == "" {
            return true
        }
        else{
            return false
        }
        
    }
    
    // MARK: ________________ OTHER VALIDATION FUNCTION _________________
    // MARK:-
    
    func isFillTextFiled(_ text: String ,validationType : EITextFieldValidationType) -> Bool {
        
        let finalString = text.trimmingCharacters(in: CharacterSet.whitespaces)
        
        if checkString(finalString) {
            self.textValidation(validationType, textValidationType: .BlankValidation)
            return false
        }else{
            return true
        }
        
    }
}
