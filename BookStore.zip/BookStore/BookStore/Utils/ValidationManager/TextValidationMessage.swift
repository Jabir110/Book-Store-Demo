//
//  TextValidationMessage.swift
//  BookStore
//
//  Created by agilemac-9 on 8/13/19.
//  Copyright © 2019 Agileinfoways. All rights reserved.
//

import Foundation

struct validationMessages {
    
    static var message_Email_Blank              = AILocalization.shared.message_Email_Blank
    static var message_Email_NotValid           = AILocalization.shared.message_Email_NotValid
    static var message_Password_Blank           = AILocalization.shared.message_Password_Blank
    static var message_Password_NotValid        = AILocalization.shared.message_Password_NotValid
    
    static var message_Username_Blank               = AILocalization.shared.message_Username_Blank
    static var message_Username_Length_NotValid     = AILocalization.shared.message_Username_Length_NotValid
    static var message_Nickname_Blank               = AILocalization.shared.message_Nickname_Blank
    static var message_Nickname_Length_NotValid     = AILocalization.shared.message_Nickname_Length_NotValid
    static var message_FullName_Blank                 = AILocalization.shared.message_FullName_Blank
    static var message_FullName_NotValid              = AILocalization.shared.message_FullName_NotValid
    static var message_SignUpPassword_Blank               = AILocalization.shared.message_SignUpPassword_Blank
    static var message_SignUpPassword_NotValid            = AILocalization.shared.message_SignUpPassword_NotValid
    
    static var message_ConfirmPassword_Blank        = AILocalization.shared.message_ConfirmPassword_Blank
    static var message_ConfirmPassword_NotValid     = AILocalization.shared.message_ConfirmPassword_NotValid
    static var message_PasswordNotMatch             = AILocalization.shared.message_PasswordNotMatch
    
    static var message_OldPassword_Blank            = AILocalization.shared.message_OldPassword_Blank
    static var message_OldPassword_NotValid         = AILocalization.shared.message_OldPassword_NotValid
    
    static var message_New_Password_Blank           = AILocalization.shared.message_New_Password_Blank
    static var message_New_Password_NotValid        = AILocalization.shared.message_New_Password_NotValid
    
    static var message_Birthday_Blank               = AILocalization.shared.message_Birthday_Blank
    
    static var message_Phone_Blank                  = AILocalization.shared.message_Phone_Blank
    static var message_Phone_Length_NotValid        = AILocalization.shared.message_Phone_Length_NotValid
    static var message_Phone_Zero_NotValid          = AILocalization.shared.message_Phone_Zero_NotValid
    
    static var message_Country_Blank                = AILocalization.shared.message_Country_Blank
    static var message_Country_NotValid             = AILocalization.shared.message_Country_NotValid
    
    static var message_State_Blank                = AILocalization.shared.message_State_Blank
    static var message_State_NotValid             = AILocalization.shared.message_State_NotValid
    
    static var message_City_Blank                 = AILocalization.shared.message_City_Blank
    static var message_City_NotValid              = AILocalization.shared.message_City_NotValid
    
    static var message_Nationality_Blank                 = AILocalization.shared.message_Nationality_Blank
    static var message_Nationality_NotValid              = AILocalization.shared.message_Nationality_NotValid
    
    static var message_TermsAndCondition_unChecked               = AILocalization.shared.message_TermsAndCondition_unChecked
    
    static var message_AccountHolderName_Blank = AILocalization.shared.message_AccountHolderName_Blank
    
    static var message_AccountHolderName_NotValid = AILocalization.shared.message_AccountHolderName_NotValid
    
    static var message_AccountNumber_Blank = AILocalization.shared.message_AccountNumber_Blank
    
    static var message_AccountNumber_NotValid = AILocalization.shared.message_AccountNumber_NotValid
    
    static var message_BankName_Blank = AILocalization.shared.message_BankName_Blank
    
    static var message_BankName_NotValid = AILocalization.shared.message_BankName_NotValid
    
    static var message_RoutingNumber_Blank = AILocalization.shared.message_RoutingNumber_Blank
    static var message_RoutingNumber_NotValid = AILocalization.shared.message_RoutingNumber_NotValid
    
    static var message_Skills_Blank                 = AILocalization.shared.message_Skills_Blank
    static var message_Category_Blank                 = AILocalization.shared.message_Category_Blank
    
    static var message_Document_Blank                 = AILocalization.shared.message_Document_Blank
    
    static var message_Job_Blank = AILocalization.shared.message_Job_Blank
    static var message_Job_NotValid = AILocalization.shared.message_Job_NotValid
    
    static var message_JobAmount_Blank = AILocalization.shared.message_JobAmount_Blank
    static var message_JobRequirement_Blank = AILocalization.shared.message_JobRequirement_Blank
    
    static var message_Distance_Blank = AILocalization.shared.message_Distance_Blank
    
    static var message_Amount_NotValid = AILocalization.shared.message_Amount_NotValid
    static var message_Amount_Validation = AILocalization.shared.message_Amount_Validation
    static var message_Distance_Validation = AILocalization.shared.message_Distance_Validation
    static var message_ReportComment_Blank = AILocalization.shared.message_ReportComment_Blank
    static var message_Review_Blank = AILocalization.shared.message_Review_Blank
    static var message_Location_Blank = AILocalization.shared.message_Location_Blank
}
