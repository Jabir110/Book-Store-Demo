//
//  SPUserModel.swift
//  ServiceProvider
//
//  Created by agileimac-2 on 18/03/19.
//  Copyright © 2019 agileimac-2. All rights reserved.
//

import UIKit

//MARK:- ENUM USER TYPE
enum EnumServiceUserType : Int{
    
    case
    ServiceProvider,
    Servicerequest
    
    var title : String{
        switch self {
        case .ServiceProvider:
            return AILocalization.shared.placeholderLabelServiceProvider
        case .Servicerequest:
            return AILocalization.shared.placeholderLabelServiceRequester
        }
    }
    
    var id : Int{
        switch self {
        case .Servicerequest:
            return 1
        case .ServiceProvider:
            return 0
        }
    }
}


let SharedUser = SPUserModel.shared


class SPUserModel: NSObject,NSCoding
{
    
    //MARK:- SHARED
    static let shared = SPUserModel()
    
    //MARK:- PROPERTIES
    
    var isLoaded:Bool = false
    
    var accessToken:String = ""
    var pushToken:String = "1321341234235"
    var deviceId:String = Constants.udid
    var deviceType:String = Constants.platform
    
    var userId:String = ""
    var fullName:String = ""
    var nickName:String = ""
    var userName:String = ""
    var email:String = ""
    var phoneNumber:String = ""
    var password:String = ""
    var profileImage:String = ""
    var birthDate = Date()
    var gender : String = ""
    var isActive : Bool = true
    var isOnline : Bool = true
    var isFavourite : Bool = false
    var isRequestForServiceProvider : Bool = false
    var isServiceProvider : Bool = false
    var userType : EnumServiceUserType = .ServiceProvider
    var averageRatings : Int = 0
    
    //var city : SearchSelectionModel? = nil
    //var state : SearchSelectionModel? = nil
    //var country : SearchSelectionModel? = nil
    //var category : SearchSelectionModel? = nil
    //var nationalities : [SearchSelectionModel] = []
    //var skills : [SearchSelectionModel] = []
    
    var about:String = ""
    var totalOrders:Int = 0
    var totalOrderDone:Int = 0
    
    //MARK:- INIT
    override init()
    {
        super.init()
    }
    
    init(dict:NSDictionary,isForStore:Bool = true)
    {
        self.userId = dict.object_forKeyWithValidationForClass_String(aKey: ResponseKeys.userIdKey)
        //self.accessToken = dict.object_forKeyWithValidationForClass_String(aKey: ResponseKeys.accessTokenKey)
        
        for obj in dict.object_forKeyWithValidationForClass_NSArray(aKey: ResponseKeys.accessTokenKey) {
            self.accessToken = obj as! String
        }
        
        self.pushToken = Constants.appDelegate.newFcmToken
        
        self.fullName = dict.object_forKeyWithValidationForClass_String(aKey: ResponseKeys.fullNameKey)
        self.nickName = dict.object_forKeyWithValidationForClass_String(aKey: ResponseKeys.nickNameKey)
        self.userName = dict.object_forKeyWithValidationForClass_String(aKey: ResponseKeys.userNameKey)
        self.email = dict.object_forKeyWithValidationForClass_String(aKey: ResponseKeys.emailKey)
        self.phoneNumber = dict.object_forKeyWithValidationForClass_String(aKey: ResponseKeys.phoneNumberKey)
        self.password = dict.object_forKeyWithValidationForClass_String(aKey: ResponseKeys.passwordKey)
        self.profileImage = dict.object_forKeyWithValidationForClass_String(aKey: ResponseKeys.profileImageKey)
        self.birthDate = dict.object_forKeyWithValidationForClass_String(aKey: ResponseKeys.birthDateKey).getDate(AppDateFormates.standardDateFormate)
        self.gender = dict.object_forKeyWithValidationForClass_String(aKey: ResponseKeys.genderKey)
        self.isActive = dict.object_forKeyWithValidationForClass_Bool(aKey: ResponseKeys.isActiveKey)
        self.isOnline = dict.object_forKeyWithValidationForClass_Bool(aKey: ResponseKeys.isOnlineKey)
        self.isRequestForServiceProvider = dict.object_forKeyWithValidationForClass_Bool(aKey: ResponseKeys.requestedForServiceProviderKey)
        self.isServiceProvider = dict.object_forKeyWithValidationForClass_Bool(aKey: ResponseKeys.isServiceProviderKey)
        self.averageRatings = dict.object_forKeyWithValidationForClass_Int(aKey: ResponseKeys.averageRatingKey)
        self.userType = self.isServiceProvider ? .ServiceProvider : .Servicerequest
        
        //For Profile related data , below var are not store in shared user
        if !isForStore
        {
            //self.city = SearchSelectionModel.init(dict: dict.object_forKeyWithValidationForClass_NSDictionary(aKey: ResponseKeys.cityKey))
            //self.state = SearchSelectionModel.init(dict: dict.object_forKeyWithValidationForClass_NSDictionary(aKey: ResponseKeys.stateKey))
            //self.country = SearchSelectionModel.init(dict: dict.object_forKeyWithValidationForClass_NSDictionary(aKey: ResponseKeys.countryKey))
            //self.nationalities = SearchSelectionModel.loadNationalityModelArray(forArray: dict.object_forKeyWithValidationForClass_NSArray(aKey: ResponseKeys.nationalitiesKey))
           // self.skills = SearchSelectionModel.loadNationalityModelArray(forArray: dict.object_forKeyWithValidationForClass_NSArray(aKey: ResponseKeys.skillsKey))
            //self.category = SearchSelectionModel.init(dict: dict.object_forKeyWithValidationForClass_NSDictionary(aKey: ResponseKeys.categoryKey))
            self.about = dict.object_forKeyWithValidationForClass_String(aKey: ResponseKeys.aboutKey)
            self.isFavourite = dict.object_forKeyWithValidationForClass_Bool(aKey: ResponseKeys.isFavKey)
            
            self.totalOrders = dict.object_forKeyWithValidationForClass_Int(aKey: ResponseKeys.totalOrdersKey)
            self.totalOrderDone = dict.object_forKeyWithValidationForClass_Int(aKey: ResponseKeys.totalOrdersDoneKey)
        }
    }
    
    // MARK: - ENCODE OBJECT
    func encode(with aCoder: NSCoder)
    {
        aCoder.encode(self.userId, forKey: ResponseKeys.userIdKey)
        aCoder.encode(self.accessToken , forKey: ResponseKeys.accessTokenKey)
        aCoder.encode(self.pushToken , forKey: ResponseKeys.pushTokenKey)
        aCoder.encode(self.fullName , forKey: ResponseKeys.fullNameKey)
        aCoder.encode(self.nickName , forKey: ResponseKeys.nickNameKey)
        
        aCoder.encode(self.userName , forKey: ResponseKeys.userNameKey)
        aCoder.encode(self.email , forKey: ResponseKeys.emailKey)
        
        aCoder.encode(self.phoneNumber , forKey: ResponseKeys.phoneNumberKey)
        aCoder.encode(self.password , forKey: ResponseKeys.passwordKey)
        aCoder.encode(self.profileImage , forKey: ResponseKeys.profileImageKey)
        
        aCoder.encode(self.birthDate, forKey: ResponseKeys.birthDateKey)
        aCoder.encode(self.gender , forKey: ResponseKeys.genderKey)
        aCoder.encode(self.isActive as Any, forKey: ResponseKeys.isActiveKey)
        aCoder.encode(self.isOnline as Any, forKey: ResponseKeys.isOnlineKey)
        aCoder.encode(self.isRequestForServiceProvider as Any, forKey: ResponseKeys.requestedForServiceProviderKey)
        aCoder.encode(self.isServiceProvider as Any, forKey: ResponseKeys.isServiceProviderKey)
        //        aCoder.encode(self.cityId , forKey: ResponseKeys.cityIdKey)
        //        aCoder.encode(self.stateId , forKey: ResponseKeys.stateIdKey)
        //        aCoder.encode(self.countryId , forKey: ResponseKeys.countryIdKey)
        
    }
    
    required init?(coder aDecoder: NSCoder)
    {
        
        if let tmpId = aDecoder.decodeObject(forKey: ResponseKeys.userIdKey){
            self.userId      = tmpId as! String
        }
        if let tmpfullName = aDecoder.decodeObject(forKey: ResponseKeys.fullNameKey){
            self.fullName      = tmpfullName as! String
        }
        if let tmpNickName = aDecoder.decodeObject(forKey: ResponseKeys.nickNameKey){
            self.nickName      = tmpNickName as! String
        }
        if let tmpUserName = aDecoder.decodeObject(forKey: ResponseKeys.userNameKey){
            self.userName      = tmpUserName as! String
        }
        if let tmpEmail = aDecoder.decodeObject(forKey: ResponseKeys.emailKey){
            self.email      = tmpEmail as! String
        }
        if let tmpPhone = aDecoder.decodeObject(forKey: ResponseKeys.phoneNumberKey){
            self.phoneNumber      = tmpPhone as! String
        }
        if let tmpAccesstoken = aDecoder.decodeObject(forKey: ResponseKeys.accessTokenKey){
            self.accessToken      = tmpAccesstoken as! String
        }
        if let tmpPushtoken = aDecoder.decodeObject(forKey: ResponseKeys.pushTokenKey){
            self.pushToken      = tmpPushtoken as! String
        }
        if let tmpProfilePic = aDecoder.decodeObject(forKey: ResponseKeys.profileImageKey){
            self.profileImage      = tmpProfilePic as! String
        }
        if let tmpBirthDate = aDecoder.decodeObject(forKey: ResponseKeys.birthDateKey){
            self.birthDate      = tmpBirthDate as! Date
        }
        
        if let tmpgender = aDecoder.decodeObject(forKey: ResponseKeys.genderKey){
            self.gender      = tmpgender as! String
        }
        if let tmpIsActive = aDecoder.decodeObject(forKey: ResponseKeys.isActiveKey){
            self.isActive      = tmpIsActive as! Bool
        }
        if let tmpIsOnline = aDecoder.decodeObject(forKey: ResponseKeys.isOnlineKey){
            self.isOnline      = tmpIsOnline as! Bool
        }
        if let tmpRequestForProvider = aDecoder.decodeObject(forKey: ResponseKeys.requestedForServiceProviderKey){
            self.isRequestForServiceProvider      = tmpRequestForProvider as! Bool
            
            self.userType = self.isRequestForServiceProvider ? .ServiceProvider : .Servicerequest
        }
        if let tmpIsServiceProvider = aDecoder.decodeObject(forKey: ResponseKeys.isServiceProviderKey){
            self.isServiceProvider = tmpIsServiceProvider as! Bool
        }
        
        //        if let tmpCityId = aDecoder.decodeObject(forKey: ResponseKeys.cityIdKey){
        //            self.cityId      = tmpCityId as! String
        //        }
        //        if let tmpStateId = aDecoder.decodeObject(forKey: ResponseKeys.stateIdKey){
        //            self.stateId      = tmpStateId as! String
        //        }
        //        if let tmpCountryId = aDecoder.decodeObject(forKey: ResponseKeys.countryIdKey){
        //            self.countryId      = tmpCountryId as! String
        //        }
    }
    
    //MARK: - CHECK LOGIN STATUS
    
    var isUserLoggedIn:Bool {
        get
        {
            return (getUserDefaultsForKey(key: AppKeys.currentUser) != nil)  ? true : false
        }
    }
    
    // MARK: - SAVE
    func saveUserWith(storedUser:SPUserModel)
    {
        self.isLoaded = true
        self.userId = storedUser.userId
        self.accessToken = storedUser.accessToken
        self.pushToken = storedUser.pushToken
        self.fullName = storedUser.fullName
        self.nickName = storedUser.nickName
        self.userName = storedUser.userName
        self.email = storedUser.email
        self.phoneNumber = storedUser.phoneNumber
        self.password = storedUser.password
        self.profileImage = storedUser.profileImage
        self.birthDate = storedUser.birthDate
        self.gender = storedUser.gender
        self.isActive = storedUser.isActive
        self.isOnline = storedUser.isOnline
        self.isRequestForServiceProvider = storedUser.isRequestForServiceProvider
        self.isServiceProvider = storedUser.isServiceProvider
        self.userType = storedUser.userType
        
        //        self.cityId = storedUser.cityId
        //        self.stateId = storedUser.stateId
        //        self.countryId = storedUser.countryId
        
        setModelDataInUserDefaults(key: AppKeys.currentUser, value: self)
    }
    
    //MARK:- LOAD
    
    func loadUserIfNeeded()
    {
        if(SharedUser.isUserLoggedIn)
        {
            if(!SharedUser.isLoaded)
            {
                if let fetchUser = getModelDataFromUserDefaults(key: AppKeys.currentUser)
                {
                    if fetchUser is SPUserModel
                    {
                        let storedUser = fetchUser as! SPUserModel
                        
                        SharedUser.isLoaded = true
                        SharedUser.userId = storedUser.userId
                        SharedUser.fullName = storedUser.fullName
                        SharedUser.nickName = storedUser.nickName
                        SharedUser.userName = storedUser.userName
                        SharedUser.email = storedUser.email
                        SharedUser.phoneNumber = storedUser.phoneNumber
                        SharedUser.accessToken = storedUser.accessToken
                        SharedUser.pushToken = storedUser.pushToken
                        SharedUser.profileImage = storedUser.profileImage
                        SharedUser.birthDate = storedUser.birthDate
                        SharedUser.gender = storedUser.gender
                        SharedUser.isActive = storedUser.isActive
                        SharedUser.isOnline = storedUser.isOnline
                        SharedUser.isRequestForServiceProvider = storedUser.isRequestForServiceProvider
                        SharedUser.isServiceProvider = storedUser.isServiceProvider
                        SharedUser.userType = storedUser.userType
                        
                        //                        SharedUser.cityId = storedUser.cityId
                        //                        SharedUser.stateId = storedUser.stateId
                        //                        SharedUser.countryId = storedUser.countryId
                    }
                }
            }
        }
    }
    
    // MARK:- LOGOUT
    func reset() -> Void
    {
        self.isLoaded = false
        self.userId = ""
        self.fullName = ""
        self.nickName = ""
        self.userName = ""
        self.email = ""
        self.birthDate = Date()
        self.phoneNumber = ""
        self.accessToken = ""
        self.pushToken = ""
        self.profileImage = ""
        self.gender = ""
        self.isActive = true
        self.isOnline = false
        self.isRequestForServiceProvider  = false
        self.isServiceProvider = false
        self.userType  = .ServiceProvider
        
        //        self.cityId = ""
        //        self.stateId = ""
        //        self.countryId = ""
        
        removeUserDefaultsFor(key: AppKeys.currentUser)
        
    }
}
