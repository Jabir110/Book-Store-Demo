//
//  Extension_Date.swift
//  Elysiot
//
//  Created by JashuGadhe on 10/3/18.
//  Copyright © 2018 Hetal. All rights reserved.
//

import Foundation

struct appDateFormetValues {
    
//    static var formatGettingFrombackend:String = "yyyy-MM-dd HH:mm:ss"
    static var formatGettingFrombackend:String = "MMM dd, HH:mm"
}

extension Date
{

    func getDisplayTimeOnly() -> String{
        /************************************************************
         get string in  dd MMM yyyy
         ************************************************************/
        
        let dateFormator = DateFormatter()
        dateFormator.timeZone = TimeZone.current
        dateFormator.dateFormat = AppDateFormates.standardDateFormate
        dateFormator.amSymbol = "AM"
        dateFormator.pmSymbol = "PM"
        if((dateFormator.string(from: self))).boolValue{
            return (dateFormator.string(from: self))
        }
        
        return ""
    }
    
    func getDateDifferanceWith(formate:String ,dateComponent:Calendar.Component,fromDate:Date,value:Int)->String
    {
        let priviousYear = Calendar.current.date(byAdding: dateComponent, value: value, to: fromDate)
        let dateFormator = DateFormatter()
        dateFormator.timeZone = TimeZone.current
        dateFormator.dateFormat = formate
        
        if((dateFormator.string(from: priviousYear!))).boolValue
        {
            return (dateFormator.string(from: priviousYear!))
        }
        
        return ""
    }
    func dayNumberOfWeek() -> Int? {
        return Calendar.current.dateComponents([.weekday], from: self).weekday
    }
    /*
     func getBeforOneYearDate()->String
     {
     let priviousYear = Calendar.current.date(byAdding: .year, value: -1, to: Date())
     let dateFormator = DateFormatter()
     dateFormator.timeZone = TimeZone.current
     dateFormator.dateFormat = AppDateFormates.startEndDateFormate
     
     if((dateFormator.string(from: priviousYear!))).boolValue
     {
     return (dateFormator.string(from: priviousYear!))
     }
     
     return ""
     }
     
     func getAfterOneYearDate()->String
     {
     let priviousYear = Calendar.current.date(byAdding: .year, value: 1, to: Date())
     let dateFormator = DateFormatter()
     dateFormator.timeZone = TimeZone.current
     dateFormator.dateFormat = AppDateFormates.startEndDateFormate
     
     if((dateFormator.string(from: priviousYear!))).boolValue
     {
     return (dateFormator.string(from: priviousYear!))
     }
     
     return ""
     }
     */
    
    static func getDates(forLastNDays nDays: Int,formate:String,currentDate:Date) -> [String] {
        let cal = NSCalendar.current
        // start with today
        var date = cal.startOfDay(for: currentDate)
        
        var arrDates = [String]()
        
        for _ in 1 ... nDays {
            // move back in time by one day:
            date = cal.date(byAdding: Calendar.Component.day, value: -1, to: date)!
            
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = formate
            let dateString = dateFormatter.string(from: date)
            arrDates.append(dateString)
        }
        //print(arrDates)
        return arrDates
    }
    
    // Convert local time to UTC (or GMT)
    func toGlobalTime() -> Date {
        let timezone = TimeZone.current
        let seconds = -TimeInterval(timezone.secondsFromGMT(for: self))
        return Date(timeInterval: seconds, since: self)
    }
    // Convert UTC (or GMT) to local time
    func toLocalTime() -> Date {
        let timezone = TimeZone.current
        let seconds = TimeInterval(timezone.secondsFromGMT(for: self))
        return Date(timeInterval: seconds, since: self)
    }
    
    func uTCToLocalDate(inputformate:String,outputformate:String) -> Date
    {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = inputformate
        dateFormatter.timeZone = TimeZone(abbreviation: "UTC")
        
        let dt = dateFormatter.string(from: self)
        dateFormatter.calendar = NSCalendar.current
        dateFormatter.timeZone = TimeZone.current
        dateFormatter.dateFormat = outputformate
        
        return dateFormatter.date(from: dt) ?? Date()
    }
    
    func app_stringFromDate(dateFormate: String) -> String{
        let dateFormatter:DateFormatter = DateFormatter()
        dateFormatter.dateFormat = dateFormate
        let strdt = dateFormatter.string(from: self as Date)
        if let dtDate = dateFormatter.date(from: strdt){
            return dateFormatter.string(from: dtDate)
        }
        return "--"
    }
    
    
    func getDateStringFromDate(_ format: String) -> String
    {
        let dateformatter = DateFormatter()
        //dateformatter.locale = Locale.init(identifier: "en_GB")
        // dateformatter.timeZone = TimeZone(abbreviation: "UTC")
        //TimeZone.current
        dateformatter.timeZone = TimeZone.current //TimeZone(identifier: "UTC")
        if TARGET_OS_SIMULATOR == 1
        {
            dateformatter.timeZone = TimeZone(identifier: "UTC")
        }
        
        dateformatter.dateFormat = format
        return dateformatter.string(from: self)
    }
        
    var isLastDayOfMonth: Bool {
        return tomorrow.month != month
    }
    
//    func startOfMonth() -> Date
//    {
//        return Calendar.current.date(from: Calendar.current.dateComponents([.year, .month], from: Calendar.current.startOfDay(for: self)))!
//    }
//
//    func endOfMonth() -> Date
//    {
//        return Calendar.current.date(byAdding: DateComponents(month: 1, day: -1), to: self.startOfMonth())!
//    }
    
    func startOfMonth() -> Date {
        let components = Calendar.current.dateComponents([.year, .month], from: self)
        return Calendar.current.date(from: components)!
    }
    
    func endOfMonth() -> Date {
        let components:NSDateComponents = Calendar.current.dateComponents([.year, .month], from: self) as NSDateComponents
        components.month += 1
        components.day = 1
        components.day -= 1
        return Calendar.current.date(from: components as DateComponents)!
    }
    
    var startOfWeek: Date? {
        let gregorian = Calendar(identifier: .gregorian)
        guard let sunday = gregorian.date(from: gregorian.dateComponents([.yearForWeekOfYear, .weekOfYear], from: self)) else { return nil }
        return gregorian.date(byAdding: .day, value: 1, to: sunday)
    }
    
    var endOfWeek: Date? {
        let gregorian = Calendar(identifier: .gregorian)
        guard let sunday = gregorian.date(from: gregorian.dateComponents([.yearForWeekOfYear, .weekOfYear], from: self)) else { return nil }
        return gregorian.date(byAdding: .day, value: 7, to: sunday)
    }
    
    var weekdayName: String {
        let formatter = DateFormatter(); formatter.dateFormat = "EEEEE"
        return formatter.string(from: self as Date)
    }
    
    func pastWeekDays(_ startDate: Date) -> [Date] {
        var startDate = startDate
        let calendar = Calendar.current
        var aryDates : [Date] = []
        let fmt = DateFormatter()
        fmt.dateFormat = "yyyy-MM-dd"
        
        while startDate <= Date() {
            startDate = calendar.date(byAdding: .day, value: 1, to: startDate)!
            aryDates.append(startDate)
            
        }
        return aryDates
    }
    
    func getDateWith(Seconds second:Int) -> Date {
        var dateComponent = Calendar.current.dateComponents([Calendar.Component.day,Calendar.Component.month,Calendar.Component.year,Calendar.Component.hour,Calendar.Component.minute,Calendar.Component.second,.timeZone], from: self)
        dateComponent.second = 0
        return Calendar.current.date(from: dateComponent)!
    }
    
    func findNext(DayDate day: String) -> Date {
        
        var calendar = NSCalendar.current
//        calendar.locale = NSLocale(localeIdentifier: "en_US_POSIX") as Locale
        calendar.locale = Locale.current
        
        guard let indexOfDay = calendar.weekdaySymbols.index(of: day) else {
            assertionFailure("Failed to identify day")
            return self
        }
        
        let weekDay = indexOfDay + 1
        
        let components = calendar.component(.weekday, from: self)
        
        if components == weekDay {
            return self
        }
        
        var matchingComponents = DateComponents()
        matchingComponents.weekday = weekDay // Monday
        
        let comingMonday = calendar.nextDate(after: self, matching: matchingComponents, matchingPolicy: Calendar.MatchingPolicy.nextTime)  //calendar.nextDate(After
        
        if let nextDate = comingMonday{
            return nextDate.dateWithTimeFromDate(secondDate: self)
        }else{
            assertionFailure("Failed to find next day")
            return self
        }
    }
    
    func dateWithTimeFromDate(secondDate:Date) -> Date{
        
        let secondDateComponent:DateComponents = NSCalendar.current.dateComponents([.hour,.minute], from: secondDate)
        var selfDateComponent:DateComponents = NSCalendar.current.dateComponents([.day,.month,.year,.hour,.minute,.timeZone], from: self)
        
        selfDateComponent.hour = secondDateComponent.hour
        selfDateComponent.minute  = secondDateComponent.minute
        
        return NSCalendar.current.date(from: selfDateComponent)!
    }
    
    func isToday() -> Bool {
        let dateComponents = Calendar.current.dateComponents([.day,.month,.year,.hour,.minute], from: self)
        let currentDateComponents = self.getCurrentDateComponents()
        
        if dateComponents.day == currentDateComponents.day && dateComponents.month == currentDateComponents.month && currentDateComponents.year == dateComponents.year{
            return true
        }else{
            return false
        }
    }
    
    func isTimeGretherThanCurrentTime() -> Bool {
        let dateComponents = Calendar.current.dateComponents([.day,.month,.year,.hour,.minute], from: self)
        let currentDateComponents = self.getCurrentDateComponents()
        
        if currentDateComponents.hour! > dateComponents.hour!{
            return true
        }else if currentDateComponents.hour == dateComponents.hour{
            if currentDateComponents.minute! >= dateComponents.minute!{
                return true
            }else{
                return false
            }
        }else{
            return false
        }
    }
    
    func getCurrentDateComponents() -> DateComponents {
        return Calendar.current.dateComponents([.day,.month,.year,.hour,.minute], from: Date())
    }
    
    func isBetweeen(date startDate: Date, andDate endDate: Date) -> Bool
    {
        return startDate.compare(self) == self.compare(endDate)
    }
    
    var millisecondsSince1970:Int {
        return Int((self.timeIntervalSince1970 * 1000.0).rounded())
    }
    
    init(milliseconds:Int) {
        self = Date(timeIntervalSince1970: TimeInterval(milliseconds) / 1000)
    }
    
    func convertDateToDisplayDateFormetChat() -> String{
        let dateformet = DateFormatter()
        dateformet.timeZone = TimeZone.current
        dateformet.dateFormat = appDateFormetValues.formatGettingFrombackend
        let str:String! = dateformet.string(from: self)
        if(str != nil){
            return str
        }
        return ""
    }

    var timeStamp: UInt64 {
        return UInt64((self.timeIntervalSince1970 + 62_135_596_800) * 10_000_000)
    }
    
    func convertDateToiso8601String() -> String {
        let dateFormatter = DateFormatter()
        let enUSPosixLocale = Locale(identifier: "en_US_POSIX")
        dateFormatter.locale = enUSPosixLocale
        dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"
        dateFormatter.calendar = Calendar(identifier: .gregorian)
        let iso8601String = dateFormatter.string(from: self as Date)
        return iso8601String
    }
    
    func convertDateToUTCiso8601String() -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.timeZone = TimeZone(abbreviation: "UTC")
        dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"
        dateFormatter.calendar = Calendar(identifier: .gregorian)
        let iso8601String = dateFormatter.string(from: self as Date)
        return iso8601String
    }
    
    func getStringFromDateWithFormat(_ format:String) -> String {
        let dateFormatter:DateFormatter = DateFormatter()
        dateFormatter.dateFormat = format
        let strDate = dateFormatter.string(from: self)
        return strDate
    }
    
    func timeAgoSinceDate() -> String {
        
        // From Time
        let fromDate = self
        
        // To Time
        let toDate = Date()
        
        /*
        // Estimation
        // Year
        if let interval = Calendar.current.dateComponents([.year], from: fromDate, to: toDate).year, interval > 0  {
            
            return interval == 1 ? "\(interval)" + " " + "year ago" : "\(interval)" + " " + "years ago"
        }
        
        // Month
        if let interval = Calendar.current.dateComponents([.month], from: fromDate, to: toDate).month, interval > 0  {
            
            return interval == 1 ? "\(interval)" + " " + "month ago" : "\(interval)" + " " + "months ago"
        }
        
        // Day
        if let interval = Calendar.current.dateComponents([.day], from: fromDate, to: toDate).day, interval > 0  {
            
            return interval == 1 ? "\(interval)" + " " + "day ago" : "\(interval)" + " " + "days ago"
        }
        */
        
        if let interval = Calendar.current.dateComponents([.day], from: fromDate, to: toDate).day, interval > 0  {
            
            return interval == 1 ? "Yesterday" : fromDate.app_stringFromDate(dateFormate: AppDateFormates.notificationDateFormate)
        }
        
        // Hours
        if let interval = Calendar.current.dateComponents([.hour], from: fromDate, to: toDate).hour, interval > 0 {
            
            return interval == 1 ? "\(interval)" + " " + "hour ago" : "\(interval)" + " " + "hours ago"
        }
        
        // Minute
        if let interval = Calendar.current.dateComponents([.minute], from: fromDate, to: toDate).minute, interval > 0 {
            
            return interval == 1 ? "\(interval)" + " " + "min ago" : "\(interval)" + " " + "min ago"
        }
        
        return "Now"
    }
 
}
extension NSDate {
    func hour() -> Int
    {
        //Get Hour
        let calendar = Calendar.current
        let unitFlags = Set<Calendar.Component>([.hour])

        let components = calendar.dateComponents(unitFlags, from: self as Date)
        let hour = components.hour
        
        //Return Hour
        return hour!
    }
    
    func minute() -> Int
    {
        //Get Minute
        let calendar = Calendar.current
        let unitFlags = Set<Calendar.Component>([.minute])

        let components = calendar.dateComponents(unitFlags, from: self as Date)
        let minute = components.minute
        
        //Return Minute
        return minute!
    }
    
    func toShortTimeString() -> String
    {
        //Get Short Time String
        let formatter = DateFormatter()
        formatter.timeStyle = .short
        
        let timeString = formatter.string(from: self as Date)
        
        //Return Short Time String
        return timeString
    }
   
}

extension String {
    
    func getDateFromString(_ format: String) -> Date
    {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = format
        return dateFormatter.date(from: self) ?? Date()
    }
    
    func getDate(_ format: String) -> Date
    {
        let dateFormatter = DateFormatter()
        
        //TimeZone.current
        dateFormatter.timeZone = TimeZone.current //TimeZone(identifier: "UTC")
        
        if TARGET_OS_SIMULATOR == 1
        {
            dateFormatter.timeZone = TimeZone(identifier: "UTC")
        }
        
        dateFormatter.dateFormat = format
        return dateFormatter.date(from: self) ?? Date()
    }
    
    func getDateString(_ inFormat: String, outFormat: String) -> String
    {
        let date = self.getDate(inFormat)
        
        if let dateString = date.getDateStringFromDate(outFormat) as String?
        {
            return dateString
        }
        else
        {
            return ""
        }
        //        }
        //        else {
        //            return ""
        //        }
    }
    
    func getPreviousDay(_ formate: String) -> Date? {
        let calendar = Calendar.current
        if let backDate = calendar.date(byAdding: .day, value: -1, to: self.getDate(formate)) {
            return backDate
        }
        else {
            return Date()
        }
    }
    
    func getNextDay(_ formate: String) -> Date?
    {
        let calendar = Calendar.current
        if let backDate = calendar.date(byAdding: .day, value: 1, to: self.getDate(formate)) {
            return backDate
        }
        else {
            return Date()
        }
    }
    
    func getDateComponent(_ formate: String) -> DateComponents?
    {
        let formatter = DateFormatter()
        formatter.dateFormat = formate
        if let date = formatter.date(from: self) {
            let calendar = Calendar.current
            if let components = calendar.dateComponents([.year, .month , .day], from: date) as DateComponents? {
                return components
            }
            else {
                return nil
            }
        }
        else {
            return nil
        }
    }
}
extension Date {
    /// Returns the amount of years from another date
    func years(from date: Date) -> Int {
        return Calendar.current.dateComponents([.year], from: date, to: self).year ?? 0
    }
    /// Returns the amount of months from another date
    func months(from date: Date) -> Int {
        return Calendar.current.dateComponents([.month], from: date, to: self).month ?? 0
    }
    /// Returns the amount of weeks from another date
    func weeks(from date: Date) -> Int {
        return Calendar.current.dateComponents([.weekOfMonth], from: date, to: self).weekOfMonth ?? 0
    }
    /// Returns the amount of days from another date
    func days(from date: Date) -> Int {
        return Calendar.current.dateComponents([.day], from: date, to: self).day ?? 0
    }
    /// Returns the amount of hours from another date
    func hours(from date: Date) -> Int {
        return Calendar.current.dateComponents([.hour], from: date, to: self).hour ?? 0
    }
    /// Returns the amount of minutes from another date
    func minutes(from date: Date) -> Int {
        return Calendar.current.dateComponents([.minute], from: date, to: self).minute ?? 0
    }
    /// Returns the amount of seconds from another date
    func seconds(from date: Date) -> Int {
        return Calendar.current.dateComponents([.second], from: date, to: self).second ?? 0
    }
    /// Returns the a custom time interval description from another date
    func offset(from date: Date) -> String {
        if years(from: date)   > 0 { return "\(years(from: date))y"   }
        if months(from: date)  > 0 { return "\(months(from: date))M"  }
        if weeks(from: date)   > 0 { return "\(weeks(from: date))w"   }
        if days(from: date)    > 0 { return "\(days(from: date))d"    }
        if hours(from: date)   > 0 { return "\(hours(from: date))h"   }
        if minutes(from: date) > 0 { return "\(minutes(from: date))m" }
        if seconds(from: date) > 0 { return "\(seconds(from: date))s" }
        return ""
    }
}
