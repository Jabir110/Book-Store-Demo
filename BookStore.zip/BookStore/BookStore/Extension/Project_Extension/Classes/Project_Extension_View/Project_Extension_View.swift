//
//  Extension_View.swift
//  Elysiot
//
//  Created by JashuGadhe on 10/3/18.
//  Copyright © 2018 Hetal. All rights reserved.
//

import Foundation
import UIKit

extension UIView {
    
    func fixInView(_ container: UIView!) -> Void{
        self.translatesAutoresizingMaskIntoConstraints = false;
        self.frame = container.frame;
        container.addSubview(self);
        NSLayoutConstraint(item: self, attribute: .leading, relatedBy: .equal, toItem: container, attribute: .leading, multiplier: 1.0, constant: 0).isActive = true
        NSLayoutConstraint(item: self, attribute: .trailing, relatedBy: .equal, toItem: container, attribute: .trailing, multiplier: 1.0, constant: 0).isActive = true
        NSLayoutConstraint(item: self, attribute: .top, relatedBy: .equal, toItem: container, attribute: .top, multiplier: 1.0, constant: 0).isActive = true
        NSLayoutConstraint(item: self, attribute: .bottom, relatedBy: .equal, toItem: container, attribute: .bottom, multiplier: 1.0, constant: 0).isActive = true
    }
    
    func fixInNavigationView(_ container: UIView!) -> Void{
        self.translatesAutoresizingMaskIntoConstraints = false;
        self.frame = container.frame;
        container.addSubview(self);
        NSLayoutConstraint(item: self, attribute: .leading, relatedBy: .equal, toItem: container, attribute: .leading, multiplier: 1.0, constant: 0).isActive = true
        NSLayoutConstraint(item: self, attribute: .trailing, relatedBy: .equal, toItem: container, attribute: .trailing, multiplier: 1.0, constant: 0).isActive = true
        NSLayoutConstraint(item: self, attribute: .top, relatedBy: .equal, toItem: container, attribute: .top, multiplier: 1.0, constant: 0).isActive = true
        NSLayoutConstraint(item: self, attribute: .bottom, relatedBy: .equal, toItem: container, attribute: .bottom, multiplier: 1.0, constant: 0).isActive = true
    }
    
    //MARK: BORDER
    func addBorder(color: UIColor = UIColor.lightGray, width: CGFloat = 1.0) {
        self.layer.borderColor = color.cgColor
        self.layer.borderWidth = width
    }
    
    
    func removeBorder(){
        self.layer.borderWidth = 0.0
        self.layer.masksToBounds = true
    }
    
    //MARK: CORNER RADIUS
    func applyCorner(_ radius: CGFloat? = nil)
    {
        self.layoutIfNeeded()
        if let validradius = radius {
            self.layer.cornerRadius = validradius
        } else {
            let newradius = min(self.height, self.width)
            self.applyCorner(newradius / 2)
        }
        self.layer.masksToBounds = true
    }
    
    //MARK: SHADOW
    
    func addLeftBottomShadowWithCorner(shadowColor color:UIColor = UIColor.black,
                                       shadowOffset offset:CGSize = CGSize(width: -3.0, height: 3.0),
                                       shadowOpacity opacity : Float = 0.3,
                                       shadowRadius radius : CGFloat = 3.0,
                                       cornerRadius :CGFloat = 10.0){
        self.clipsToBounds = false
        self.layer.shadowColor = color.cgColor
        self.layer.shadowOffset = offset
        self.layer.shadowOpacity = opacity
        self.layer.shadowRadius = radius
        self.layer.cornerRadius = cornerRadius
    }
    
    func addBottomShadow(shadowColor color:UIColor = UIColor.black,
                         shadowOffset offset:CGSize = CGSize(width: 0.0, height: 5.0),
                         shadowOpacity opacity : Float = 0.1,
                         shadowRadius radius : CGFloat = 1.0,
                         cornerRadius :CGFloat = 10.0)
    {
        self.clipsToBounds = false
        self.layer.shadowColor = color.cgColor
        self.layer.shadowOffset = offset
        self.layer.shadowOpacity = opacity
        self.layer.shadowRadius = radius
       // self.layer.cornerRadius = cornerRadius
        //self.roundCorners([.bottomLeft,.topLeft], radius: 10.0)
    }
    
    func addShadowWithCorner(shadowColor color:UIColor = UIColor.black,
                             shadowOffset offset:CGSize = CGSize(width: 3.0, height: 3.0),
                             shadowOpacity opacity : Float = 0.3,
                             shadowRadius radius : CGFloat = 3.0,
                             cornerRadius :CGFloat = 10.0)
    {
        self.clipsToBounds = true
        self.layer.shadowColor = color.cgColor
        self.layer.shadowOffset = offset
        self.layer.shadowOpacity = opacity
        self.layer.shadowRadius = radius
        self.layer.cornerRadius = cornerRadius
    }
    
    func addShadow(_ color: UIColor = UIColor.gray, _ opacity: Float = 0.5, _ radius: CGFloat = 1.0)
    {
        self.layer.shadowColor = color.cgColor
        self.layer.shadowOpacity = opacity
        self.layer.shadowOffset = CGSize(width: 0.0, height: 2.0)
        self.layer.shadowRadius = radius
        self.clipsToBounds = false
    }
    
    func addDefaultShadow(withColor color: UIColor = UIColor.gray, shadowOffset offset:CGSize = CGSize(width: 1, height: 1), opacity op: Float = 0.5)
    {
        self.layer.shadowColor = color.cgColor
        self.layer.shadowOffset = offset
        self.layer.shadowOpacity = op
        self.layer.masksToBounds = false
        self.clipsToBounds = false
    }
    
    func setCardView(view : UIView, shadowColor: UIColor? = UIColor.lightGray){
        self.layer.cornerRadius = 2
        self.layer.masksToBounds = false
        self.layer.shadowColor = shadowColor?.cgColor
        self.layer.shadowOpacity = 1.0
        self.layer.shadowOffset = CGSize.zero
        self.layer.shadowRadius = 1
        
    }
    
    func setCircleView(view : UIView, backgroundColor: UIColor, borderColor: UIColor, borderWidth: CGFloat){
        view.backgroundColor = backgroundColor
        view.layer.cornerRadius = (min(self.height, self.width))/2
        view.layer.borderColor  =  borderColor.cgColor
        view.layer.borderWidth = borderWidth
        view.layer.masksToBounds = true
    }
    
    //MARK: REMOVE CONSTRAINTS
    func removeConstraints() {
        
        let constraints = self.superview?.constraints.filter{
            $0.firstItem as? UIView == self || $0.secondItem as? UIView == self
            } ?? []
        
        self.superview?.removeConstraints(constraints)
        self.removeConstraints(self.constraints)
    }
    
    //MARK: FIRST RESPONDER
    func findFirstResponder() -> AnyObject {
        if self.isFirstResponder {
            return self
        }
        else {
            for subview in self.subviews {
                if subview.isFirstResponder {
                    return subview
                }
            }
        }
        return NSNull()
    }
    
    //MARK: FETCH VIEW WITH TAG
    func getView(tag aTag:Int) -> AnyObject? {
        if(self.tag == aTag){
            return self
        }
        
        let aSuperView = self.superview
        
        for aSubView in aSuperView!.subviews
        {
            if(aSubView.tag == aTag)
            {
//                if aSubView.isKind(of: CMSPickerTextField.self)
//                {
//                    let tt = aSubView as! CMSPickerTextField
//                    print(tt.placeholder)
//                }
                return aSubView
            }
        }
        return nil
    }
    
    //MARK: GET VIEW FROM SUBVIEW
    func getViewFromSubview(tag aTag:Int) -> AnyObject? {
        if(self.tag == aTag){
            return self
        }
        
        for aSubView in self.subviews {
            if(aSubView.tag == aTag){
                return aSubView
            }
        }
        return nil
    }
    /*
    //MARK: ADD BOTTOM SEPARATOR
    func addBottomSeparator(withColor color : UIColor = UIColor.lightGray) {
        let viewBottomLine = UIView()
        
        viewBottomLine.backgroundColor = color
        self.addSubview(viewBottomLine)
        
        //adding Contraints to Bottomview
        viewBottomLine.autoPinEdgesToSuperviewEdges(with: UIEdgeInsetsMake(0, 0, 0, 0), excludingEdge: .top)
        viewBottomLine.autoSetDimension(.height, toSize: 1.0)
    }
    
    //MARK: ADD TOP SEPARATOR
    func addTopSeparator(withColor color : UIColor = UIColor.gray) {
        let viewTopLine = UIView()
        
        viewTopLine.backgroundColor = color.withAlphaComponent(0.5)
        self.addSubview(viewTopLine)
        
        //adding Contraints to Bottomview
        viewTopLine.autoPinEdgesToSuperviewEdges(with: UIEdgeInsetsMake(0, 0, 0, 0), excludingEdge: .bottom)
        viewTopLine.addDefaultShadow()
        viewTopLine.autoSetDimension(.height, toSize: 1.0)
    }
    */
    
    func addRipplerEffect(withColor color : UIColor = UIColor.lightGray) {
        //        let rippleLayer = MDRippleLayer(superView: self)
        //        rippleLayer.effectColor = color.withAlphaComponent(0.1)
        //        rippleLayer.effectSpeed = 2000
        //        rippleLayer.rippleScaleRatio = 1
    }
    
    
}

extension UIStackView
{
    
    func setBackground(color: UIColor)
    {
        let subview = UIView(frame: bounds)
        subview.backgroundColor = color
        subview.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        insertSubview(subview, at: 0)
    }
    
}
