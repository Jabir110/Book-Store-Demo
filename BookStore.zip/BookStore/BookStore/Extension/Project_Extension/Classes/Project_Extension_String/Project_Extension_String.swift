//
//  Extension_String.swift
//  Elysiot
//
//  Created by JashuGadhe on 10/2/18.
//  Copyright © 2018 Hetal. All rights reserved.
//

import Foundation
import UIKit


/*
extension AuthErrorCode
{
    var errorMessage: String
    {
        switch self {
        case .emailAlreadyInUse:
            return "The email is already in use with another account"
        case .userNotFound:
            return "Account not found for the specified user. Please check and try again"
        case .userDisabled:
            return "Your account has been disabled. Please contact support."
        case .invalidEmail, .invalidSender, .invalidRecipientEmail:
            return "Please enter a valid email"
        case .networkError:
            return "Network error. Please try again."
        case .weakPassword:
            return "Your password is too weak. The password must be 6 characters long or more."
        case .wrongPassword:
            return "Your password is incorrect. Please try again or use 'Forgot password' to reset your password"
        default:
            return "Unknown error occurred"
        }
    }
}
*/

public extension Collection where Iterator.Element == [String:Any]
{
//    func toJSONString(options: JSONSerialization.WritingOptions = .prettyPrinted) -> String {
//        if let arr = self as? [[String:Any]],
//            let dat = try? JSONSerialization.data(withJSONObject: arr, options: options),
//            let str = String(data: dat, encoding: String.Encoding.utf8) {
//            return str
//        }
//        return "[]"
//    }

}

public extension Dictionary {
    
    func convertObjectToJSon()->String
    {
        if let theJSONData = try? JSONSerialization.data(
            withJSONObject: self,
            options: []) {
            return String(data: theJSONData,
                          encoding: .ascii) ?? ""
        }
        return ""
    }
}


public extension String {
    
    func fileName() -> String {
        return NSURL(fileURLWithPath: self).deletingPathExtension?.lastPathComponent ?? ""
    }
    
    func fileExtension() -> String {
        return NSURL(fileURLWithPath: self).pathExtension ?? ""
    }
    
    func isAllCharacterSameWith(char:String)->Bool
    {
        let fullString = self.replacingOccurrences(of: char, with: "")
        return fullString.textlength <= 0
    }
        
    public func PhoneNumberFormate(str : NSMutableString) -> String{
        str.insert("(", at: 0)
        str.insert(")", at: 4)
        str.insert("-", at: 8)
        return str as String
    }
    
    //MARK:- Append AM-PM if dose convert to 24 hours to 12 hours
    func convertTo12Hours() -> String{
        var temp = self
        var strArr = self.split{$0 == ":"}.map(String.init)
        let hour = Int(strArr[0])!
        let min = strArr[1]
        if(hour >= 12){
            // If hours greater then 12 PM
            if hour - 12 < 10 && hour != 12 {
                temp = "0\(hour - 12):\(min) PM"
            }else if hour == 12{
                //If 12 PM in 24 hours that is 12:00
               temp = "\(hour):\(min) PM"
            }else{
                 temp = "\(hour - 12):\(min) PM"
            }
           
        }
        else{
            // If hours less then 12 PM
            
            if hour < 10 && hour != 0{
                temp = "0\(hour):\(min) AM" // "0\(temp) AM"
            }else if hour == 0{
                //If 12 AM in 24 hours that is 00:00
                temp = "\(hour + 12):\(min) AM"
            }else{
                temp = "\(temp) AM"
            }
        }
        return temp
    }
    //MARK:- Remove AM-PM if dose convert to 12 hours to 24 hours
    func convertTo24Hours() -> String{
        var time = self
        let dateArray = self.split{$0 == " "}.map(String.init)
        let timeArray = dateArray.first!.split{$0 == ":"}.map(String.init)

        if dateArray.last == "PM"{
            let hour = Int(timeArray.first!)!
            let min = timeArray.last!
            if hour ==  12{
                time = "\(hour):\(min)"
            }else{
                let hours = hour + 12
                time = "\(hours):\(min)"
            }
        }else{
            if Int(timeArray.first!)! == 12{
                let hours = Int(timeArray.first!)! - 12
                let min = timeArray.last!
                time = "0\(hours):\(min)"
            }else{
                 time = dateArray.first!
            }
        }
        return time
    }
    //MARK:- Check AM PM contains
    public func check12HoursTimeFormate()-> Bool{
        if self.contains("AM") || self.contains("PM"){
            return  true
        }else{
            return false
        }
    }

}

extension URL
{
    var typeIdentifier: String?
    {
        return (try? resourceValues(forKeys: [.typeIdentifierKey]))?.typeIdentifier
    }
    
    var localizedName: String?
    {
        return (try? resourceValues(forKeys: [.localizedNameKey]))?.localizedName
    }
}

extension NSMutableAttributedString {
    
    func setColorForText(textForAttribute: String, withColor color: UIColor , range: NSRange) {
        //let range: NSRange = self.mutableString.range(of: textForAttribute, options: .caseInsensitive)
        self.addAttribute(NSAttributedString.Key.foregroundColor, value: color, range: range)
    }
}

extension String {
    
    var floatVAlue: Float
    {
        return (self as NSString).floatValue
    }
    
//    func setColorForString(_ color: UIColor, range: NSRange) -> NSMutableAttributedString {
//        var mutableString = NSMutableAttributedString()
//        mutableString = NSMutableAttributedString(string: self, attributes: [NSAttributedString.Key.font : UIFont.appRegularFont(WithSize: 16)])
//        mutableString.addAttribute(NSAttributedString.Key.foregroundColor, value: color, range: range)
//        return mutableString
//    }
    
    var shortenedVersionNumberString: String {
        let unnecessaryVersionSuffix = ".0"
        var shortenedVersionNumber: String = self
        while shortenedVersionNumber.hasSuffix(unnecessaryVersionSuffix) {
            shortenedVersionNumber = (shortenedVersionNumber as? NSString)?.substring(to: (shortenedVersionNumber.characters.count ) - (unnecessaryVersionSuffix.characters.count )) ?? ""
        }
        return shortenedVersionNumber
    }
    
    var doubleValue: Double {
        get {
            return (self as NSString).doubleValue
        }
    }
    
    var convertToPhoneNumberForServer: String {
        get {
            if String(self[0] as Character) == "0" {
                return "+91" + (self as NSString).substring(from: 1)
            }
            else {
                return "+91" + self
            }
        }
    }
    
    var convertToPhoneNumberForLocal: String {
        get {
            if self.hasPrefix("+91") {
                let strPhoneNumber = self.replace(target: "+91", withString: "")
                if strPhoneNumber.textlength == 9 {
                    return strPhoneNumber
                    //return "0" + strPhoneNumber
                }
                else {
                    return strPhoneNumber
                }
            }
            return self
        }
    }
    
    
    
    func convertTo(dateWithFormatinUTC str: String) -> Date {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = str
        dateFormatter.timeZone = NSTimeZone(name: "UTC") as TimeZone! //"UTC" //"Europe/Berlin" - "CET"
        if let dateFromString = dateFormatter.date(from: self) {
            return dateFromString
        }
        return Date()
    }
    
    var trimWhiteSpaceAndNewLine : String {
        get {
            return self.trimmingCharacters(in: .whitespacesAndNewlines)
        }
    }
    
    func isValidPostalcode() -> Bool {
        let emailRegex = "[0-9]{3,5}"
        return NSPredicate(format: "SELF MATCHES %@", emailRegex).evaluate(with: self)
    }
    
    func isValidURL(_ needTOCheckDomainValidation: Bool = false) -> Bool {
        let regEx = "((https|http)://)((\\w|-)+)(([.]|[/])((\\w|-)+))+"
        let predicate = NSPredicate(format:"SELF MATCHES %@", argumentArray:[regEx])
        return predicate.evaluate(with: self)
        
        /*
         if needTOCheckDomainValidation {
         if let validateUrl = URL(string: self), let _ = validateUrl.scheme, let host = validateUrl.host {
         // the scheme contains "http/https", the host contains "google.com"
         if let config = BRServiceManager.shared.config {
         return host.contains(config.reaDomain)
         }
         else {
         return host.contains("realestate.com.au")
         }
         }
         else {
         return false
         }
         }
         else {
         return predicate.evaluate(with: self)
         }
         */
    }
    
    func isValidPhone() -> Bool{
        do {
            let detector = try NSDataDetector(types: NSTextCheckingResult.CheckingType.phoneNumber.rawValue)
            let matches = detector.matches(in: self, options: [], range: NSMakeRange(0, self.count))
            if let res = matches.first {
                return res.resultType == .phoneNumber && res.range.location == 0 && res.range.length == self.count && self.count == 10 && self.replacingOccurrences(of: "0", with: "").count != 0
            } else {
                return false
            }
        } catch {
            return false
        }
    }
    
    func replace(target: String, withString: String) -> String
    {
        return self.replacingOccurrences(of: target, with: withString, options: NSString.CompareOptions.literal, range: nil)
    }
    
    
    var encodeunicode : String {
        get {
            let data = self.data(using: String.Encoding.nonLossyASCII)
            return NSString(data: data!, encoding: String.Encoding.utf8.rawValue)! as String
        }
    }
    
    var decodeunicode : String {
        get {
            let data = self.data(using: String.Encoding.utf8)
            if let value = NSString(data: data!, encoding: String.Encoding.nonLossyASCII.rawValue) {
                return value as String
            } else {
                return ""
            }
        }
    }
    
    func isLastCharcterAWhiteSpace() -> Bool{
        
        if(self.characters.count == 0){
            return false
        }
        
        var result:Bool = false
        if(self.characters.count == 1){
            result = self[0] == " "
        }else{
            result = self[self.characters.count-1] == " "
        }
        
        return result
    }
    

        
    /// Convert to URL
    var isLocalPath: Bool {
        return !((self.lowercased() as NSString).hasPrefix("http://") || (self.lowercased() as NSString).hasPrefix("https://"))
    }
    
    var getUrl: URL? {
        
        if (self.lowercased() as NSString).hasPrefix("http://") || (self.lowercased() as NSString).hasPrefix("https://") {
            if let strurl = (self as NSString).addingPercentEncoding(withAllowedCharacters: NSCharacterSet.urlQueryAllowed) {
                return URL(string: strurl)
            }
            return nil
        }
        else {
            return URL(fileURLWithPath: self)
        }
    }
    
    /// Get TextLength
    var textlength: Int {
        get {
            return (self as NSString).length
        }
    }
    
    var parseJSONString: AnyObject? {
        get {
            let data = self.data(using: String.Encoding.utf8, allowLossyConversion: false)
            if let jsonData = data {
                return try! JSONSerialization.jsonObject(with: jsonData, options: JSONSerialization.ReadingOptions.mutableContainers) as AnyObject?
            } else {
                return nil
            }
        }
    }
    
    func isValidMarks(obtainMarks:Int)-> Bool
    {
        return self.intValue <= obtainMarks
    }
    
    var isEmpty: Bool {
        return (self as NSString).trimmingCharacters(in: NSCharacterSet.whitespacesAndNewlines) == ""
    }
    
    var isContainEmailCharacterOnly: Bool {
        if self.textlength == 1 {
            let characterset = NSCharacterSet(charactersIn: "@_.abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890-")
            let range = (self as NSString).rangeOfCharacter(from: characterset as CharacterSet)
            return (range.location != NSNotFound)
        }
        else {
            var status: Bool = true
            for chr in self.characters {
                let tmpstr: String = String.init(chr)
                let characterset = NSCharacterSet(charactersIn: "@_.abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890-")
                let range = (tmpstr as NSString).rangeOfCharacter(from: characterset as CharacterSet)
                status = (range.location != NSNotFound)
                if !status {
                    break
                }
            }
            return status
        }
    }
    
    var containsOnlyNameLetters: Bool {
        get {
            for chr in self.characters {
                if (!(chr >= "a" && chr <= "z") && !(chr >= "A" && chr <= "Z") && !(chr == " ") && !(chr == "'") && !(chr == "&") && !(chr == "-")) {
                    return false
                }
            }
            return true
        }
    }
    
    var containsOnlyLetters: Bool {
        get {
            for chr in self.characters {
                if (!(chr >= "a" && chr <= "z") && !(chr >= "A" && chr <= "Z")) {
                    return false
                }
            }
            return true
        }
    }
    
    var containsOnlyLettersAndSpace: Bool {
        get {
            for chr in self.characters {
                if (!(chr >= "a" && chr <= "z") && !(chr >= "A" && chr <= "Z") && !(chr == " ")) {
                    return false
                }
            }
            return true
        }
    }
    
    var containsOnlyDigits: Bool {
        get {
            for chr in self.characters {
                if (!(chr >= "0" && chr <= "9")) {
                    return false
                }
            }
            return true
        }
    }
    
    var containsOnlyDigitsAndSpace: Bool {
        get {
            for chr in self.characters {
                if (!(chr >= "0" && chr <= "9") && !(chr == " ")) {
                    return false
                }
            }
            return true
        }
    }
    
    
    static func formatTimefromSeconds(totalSeconds: Int) -> String
    {
        let seconds = totalSeconds % 60
        let minutes = (totalSeconds / 60) % 60
        let hours = totalSeconds / 3600
        if hours < 1 {
            return String(format: "%02d:%02d", minutes, seconds)
        }
        return String(format: "%02d:%02d:%02d", hours, minutes, seconds)
    }
    
    static func dictToJsonString(params: NSDictionary) -> String
    {
        do {
            let jsonData = try JSONSerialization.data(withJSONObject: params, options: .prettyPrinted)
            let jsonString = NSString.init(data: jsonData, encoding: String.Encoding.utf8.rawValue)
            return jsonString! as String
        }
        catch {
            return "Not a valid json object"
        }
    }
    
    static func arrToJsonString(params: NSArray) -> String
    {
        do {
            let jsonData = try JSONSerialization.data(withJSONObject: params, options: .prettyPrinted)
            let jsonString = NSString.init(data: jsonData, encoding: String.Encoding.utf8.rawValue)
            return jsonString! as String
        }
        catch {
            return "Not a valid json object"
        }
    }
    
    func strchareacterAt(index: Int) -> String {
        if (self.textlength - 1) < index {
            return ""
        }
        
        return (self as NSString).substring(with: NSMakeRange(index , 1))
    }
    
    
    
    func sizeFor(font:UIFont, offset: CGFloat = 0) -> CGSize
    {
        let size = (self as NSString).boundingRect(with: CGSize(width: CGFloat.greatestFiniteMagnitude, height:CGFloat.greatestFiniteMagnitude), options: .usesLineFragmentOrigin, attributes: [NSAttributedString.Key.font: font], context: nil).size
        return CGSize(width: (size.width + (2 * offset)), height: (size.height + (2 * offset)))
    }
    
    
    func widthFor(font:UIFont, height:CGFloat) -> CGFloat
    {
        let size = (self as NSString).boundingRect(with: CGSize(width: CGFloat.greatestFiniteMagnitude, height:height), options: .usesLineFragmentOrigin, attributes: [NSAttributedString.Key.font: font], context: nil).size
        return size.height
    }
    
    func heightFor(font:UIFont, width:CGFloat) -> CGFloat
    {
        let size = (self as NSString).boundingRect(with: CGSize(width: width, height:CGFloat.greatestFiniteMagnitude), options: .usesLineFragmentOrigin, attributes: [NSAttributedString.Key.font: font], context: nil).size
        return size.height
    }
    
    func height(withConstrainedWidth width: CGFloat, font: UIFont) -> CGFloat {
        let constraintRect = CGSize(width: width, height: .greatestFiniteMagnitude)
        let boundingBox = self.boundingRect(with: constraintRect, options: .usesLineFragmentOrigin, attributes: [NSAttributedString.Key.font: font], context: nil)
        return ceil(boundingBox.height)
    }
    
    func width(withConstraintedHeight height: CGFloat, font: UIFont) -> CGFloat {
        let constraintRect = CGSize(width: .greatestFiniteMagnitude, height: height)
        let boundingBox = self.boundingRect(with: constraintRect, options: .usesLineFragmentOrigin, attributes: [NSAttributedString.Key.font: font], context: nil)
        
        return ceil(boundingBox.width)
    }
    
    func size(OfFont font: UIFont) -> CGSize
    {
        return (self as NSString).size(withAttributes: [NSAttributedString.Key.font: font])
    }
    
    func stringToFloatValue() -> Float
    {
        return (self as NSString).floatValue
    }
    func stringToIntValue() -> Int
    {
        return Int((self as NSString).intValue)
    }
    func metersToMileFromString() -> String {
        let meters = self.stringToFloatValue()
        let distanceMeters = Measurement(value: Double(meters), unit: UnitLength.meters)
        let distanceMiles = distanceMeters.converted(to: UnitLength.miles)
        let miles = distanceMeters.converted(to: UnitLength.miles).value
        return String(format: "%.1f", miles)
    }
    
    func secondToMin() -> String {
        let meters = self.stringToFloatValue()
        let distanceMeters = Measurement(value: Double(meters), unit: UnitLength.meters)
        let distanceMiles = distanceMeters.converted(to: UnitLength.miles)
        let miles = distanceMeters.converted(to: UnitLength.miles).value
        return String(format: "%.1f", miles)
    }
    func hoursMinutesSecondsFrom(compliation:((_ hours :Int,_ minute:Int, _ second:Int)->())) {
        let totalSecond : Int = self.stringToIntValue()
        let hours = totalSecond / 3600
        let minute = (totalSecond % 3600) / 60
        let seconds = (totalSecond % 3600) % 60
        //        var strTime = ""
        //        if hours > 0{
        //            strTime = String.init(format: "%02d : ", hours)
        //        }
        compliation(hours,minute,seconds)
    }
    
}

extension String {
    var htmlToAttributedString: NSAttributedString? {
        guard let data = data(using: .utf8) else { return NSAttributedString() }
        do {
            return try NSAttributedString(data: data, options: [.documentType: NSAttributedString.DocumentType.html, .characterEncoding:String.Encoding.utf8.rawValue], documentAttributes: nil)
        } catch {
            return NSAttributedString()
        }
    }
    var htmlToString: String {
        return htmlToAttributedString?.string ?? ""
    }
}

extension Double {
    var stringValue: String {
        if self == Double(Int(self)) {
            return "\(Int(self))"
        }
        return "\(self)"
    }
    var stringIgnoreIntValue: String {
        return "\(self)"
    }
    
    var stringValueWith2Fraction: String {
        return String.init(format: "%0.2f", self)
    }
}
