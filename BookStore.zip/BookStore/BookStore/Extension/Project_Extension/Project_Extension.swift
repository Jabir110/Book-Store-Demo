//
//  Project_Extension.swift
//  BookStore
//
//  Created by agilemac-9 on 8/19/19.
//  Copyright © 2019 Agileinfoways. All rights reserved.
//

import Foundation
import UIKit
import SDWebImage

extension UIColor {
    
    struct appColor {

        static var appThemeColor_PersianGreen   = UIColor.init(red: 0, green: 183, blue: 164)
        static var appBlackColor                = UIColor.init(red: 1, green: 1, blue: 1)
        static var appDarkGrayColor             = UIColor.init(red: 64, green: 64, blue: 64)
        static var appGrayColor                 = UIColor.init(red: 162, green: 162, blue: 162)
        static var appNewGrayColor              = UIColor.init(red: 200, green: 200, blue: 200)
        static var appLightGrayColor            = UIColor.init(red: 232, green: 232, blue: 232)
        static var appRedColor                  = UIColor.init(red: 231, green: 76, blue: 60)
        static var appDarkRedColor              = UIColor.init(red: 203, green: 74, blue: 61)
        static var appGreenColor                = UIColor.init(red: 50, green: 205, blue: 50)
        static var appLightGreenColor           = UIColor.init(red: 89, green: 231, blue: 122)
        static var appDarkGreenColor            = UIColor.init(red: 2, green: 124, blue: 112)
        static var appSkyBlueColor              = UIColor.init(red: 27, green: 167, blue: 209)
        static var appDarkBlueColor             = UIColor.init(red: 90, green: 114, blue: 245)
        static var appBorderColor               = UIColor.init(red: 208, green: 208, blue: 208)
        static var appLightYellowColor          = UIColor.init(red: 207, green: 181, blue: 59)
        static var appOrangeColor               = UIColor.init(red: 209, green: 104, blue: 27)
        static var appWhiteColor                = UIColor.init(red: 255, green: 255, blue: 255)
        static var appLightChatColor            = UIColor.init(red: 241, green: 246, blue: 251)
        static var appLightChatTextColor        = UIColor.init(red: 76, green: 82, blue: 100)
    }
    
    //MARK: RGB
    convenience init(red: Int, green: Int, blue: Int) {
        assert(red >= 0 && red <= 255, "Invalid red component")
        assert(green >= 0 && green <= 255, "Invalid green component")
        assert(blue >= 0 && blue <= 255, "Invalid blue component")
        self.init(red: CGFloat(red) / 255.0, green: CGFloat(green) / 255.0, blue: CGFloat(blue) / 255.0, alpha: 1.0)
    }
}

//MARK:-

extension UIFont {
    
    struct AppFontType {
        static var Icon_Font_Eng                = "eng_font"
        static var Icon_Font_Arabic             = "arabic_font"
        static var NunitoSans_Regular           = "NunitoSans-Regular"
        static var NunitoSans_Bold              = "NunitoSans-Bold"
        static var NunitoSans_SemiBold          = "NunitoSans-SemiBold"
    }
    
    /// NunitoSans Regular
    class func appRegularFont(WithSize size:CGFloat, shouldResize:Bool = true) -> UIFont {
        return UIFont(name: AppFontType.NunitoSans_Regular, size: shouldResize ? size.proportionalFontSize() : size)!
        //return UIFont.systemFont(ofSize: shouldResize ? size.proportionalFontSize() : size)
    }
    
    /// NunitoSans Bold
    class func appBoldFont(WithSize size:CGFloat, shouldResize:Bool = true) -> UIFont {
        return UIFont(name: AppFontType.NunitoSans_Bold, size: shouldResize ? size.proportionalFontSize() : size)!
        //return UIFont.systemFont(ofSize: shouldResize ? size.proportionalFontSize() : size)
    }
    
    /// NunitoSans SemiBold
    class func appSemiBoldFont(WithSize size:CGFloat, shouldResize:Bool = true) -> UIFont {
        return UIFont(name: AppFontType.NunitoSans_SemiBold, size: shouldResize ? size.proportionalFontSize() : size)!
        //return UIFont.systemFont(ofSize: shouldResize ? size.proportionalFontSize() : size)
    }

    /// IconFont
    class func appIconFont(WithSize size:CGFloat, shouldResize:Bool = true) -> UIFont {
        return UIFont(name: AILocalization.getCurruntDeviceLanguage() == .arabic ? AppFontType.Icon_Font_Arabic : AppFontType.Icon_Font_Eng, size: shouldResize ? size.proportionalFontSize() : size)!
    }
}

//MARK:-

extension UIImageView {
    
    func loadImage(strUrl url: String, placeHolderImage pImage: UIImage?, isCallDueToFailure: Bool = false, loaderStyle style:UIActivityIndicatorView.Style, oncompletion completion:((Bool, UIImage?) -> Swift.Void)? = nil) {
        self.contentMode = .scaleAspectFill
        
        guard url.length > 0  else {
            self.image = pImage
            return
        }
        
        self.sd_setShowActivityIndicatorView(true)
        self.sd_setIndicatorStyle(style)
        self.sd_setImage(with: url.getUrl, placeholderImage: pImage, options: .retryFailed, completed: { (image, err, chacheType, urlCalled) in
            if let error = err as NSError? {
                print("ERROR!: \(error)")
            }
            completion?((err == nil), image)
        })
    }
}
