//
//  Extension_UINavigationController.swift
//  BookStore
//
//  Created by agilemac-9 on 8/19/19.
//  Copyright © 2019 Agileinfoways. All rights reserved.
//

import Foundation
import UIKit

extension UINavigationController {
    
    /// Given the kind of a (UIViewController subclass),
    /// removes any matching instances from self's
    /// viewControllers array.
    
    func removeAnyViewControllers(ofKind kind: AnyClass) {
        self.viewControllers = self.viewControllers.filter { !$0.isKind(of: kind)}
    }
    
    func returnViewControllers(ofKind kind: AnyClass) -> UIViewController {
        for allVC in self.viewControllers{
            if allVC.isKind(of: kind){
                return allVC
            }
        }
        return UIViewController.init()
    }
    
    /// Given the kind of a (UIViewController subclass),
    /// returns true if self's viewControllers array contains at
    /// least one matching instance.
    
    func containsViewController(ofKind kind: AnyClass) -> Bool {
        return self.viewControllers.contains(where: { $0.isKind(of: kind) })
    }
    
    func currentViewControllerInStack(viewController: Swift.AnyClass)->Bool {
        for element in viewControllers as Array {
            if element.isKind(of: viewController) {
                return true
            }
        }
        return false
    }
    
    func popToViewController(viewController: Swift.AnyClass) {
        for element in viewControllers as Array {
            if element.isKind(of: viewController) {
                self.popToViewController(element, animated: true)
                break
            }
        }
    }
}

extension UIViewController {
    
    /// Given the kind of a (UIViewController subclass),
    /// removes any matching instances from self's
    /// viewControllers array.
    
    func returnChildViewControllers(ofKind kind: AnyClass) -> UIViewController {
        for allVC in self.children{
            if allVC.isKind(of: kind){
                return allVC
            }
        }
        return UIViewController.init()
    }
    
    /// Given the kind of a (UIViewController subclass),
    /// returns true if self's viewControllers array contains at
    /// least one matching instance.
    
    func containsChildViewController(ofKind kind: AnyClass) -> Bool {
        return self.children.contains(where: { $0.isKind(of: kind) })
    }
}
