//
//
//  Created by Agile Infoways.
//  Copyright © 2017 Agile. All rights reserved.
//

import UIKit

public extension UISearchBar {
    
    /// Return UITextField from SearchBar
    public var textField: UITextField? {
        return value(forKey: "searchField") as? UITextField
    }
    
    /// Set custom search icon
    ///
    /// - Parameter image: UIImage name
    public func setSearchIcon(image: UIImage) {
        setImage(image, for: .search, state: .normal)
    }
    
    /// Set custom clear icon
    ///
    /// - Parameter image: UIImage name
    public func setClearIcon(image: UIImage) {
        setImage(image, for: .clear, state: .normal)
    }
    
    
    
    /// Channge Text Font.
    ///
    /// - Parameter textFont: pass text font.
    public func change(textFont : UIFont?) {
        for view : UIView in (self.subviews[0]).subviews {
            if let textField = view as? UITextField {
                textField.font = textFont
            }
        }
    }
    
    
    /// Set PlaceholderAndTextColor.
    ///
    /// - Parameters:
    ///   - placeholderColor: placeholderColor
    ///   - textColor: textColor.
    public func setPlaceholderAndTextColorTo(placeholderColor: UIColor,textColor: UIColor){
        let textFieldInsideSearchBar = self.value(forKey: "searchField") as? UITextField
        textFieldInsideSearchBar?.textColor = textColor
        let textFieldInsideSearchBarLabel = textFieldInsideSearchBar!.value(forKey: "placeholderLabel") as? UILabel
        textFieldInsideSearchBarLabel?.textColor = placeholderColor
    }
    
    
    /// Aet MagnifyingGlass Color.
    ///
    /// - Parameter color: UIColor.
    public func setMagnifyingGlassColorTo(color: UIColor){
        let textFieldInsideSearchBar = self.value(forKey: "searchField") as? UITextField
        let glassIconView = textFieldInsideSearchBar?.leftView as? UIImageView
        glassIconView?.image = glassIconView?.image?.withRenderingMode(.alwaysTemplate)
        glassIconView?.tintColor = color
    }
    
    
    /// Set ClearButton Color.
    ///
    /// - Parameter color: UIColor.
    public func setClearButtonColorTo(color: UIColor){
        // Clear Button
        let textFieldInsideSearchBar = self.value(forKey: "searchField") as? UITextField
        let crossIconView = textFieldInsideSearchBar?.value(forKey: "clearButton") as? UIButton
        crossIconView?.setImage(crossIconView?.currentImage?.withRenderingMode(.alwaysTemplate), for: .normal)
        crossIconView?.tintColor = color
    }
    
    
    /// Set Cancel button Font.
    ///
    /// - Parameter font: UIFont.
    public func setCancelFont(font : UIFont){
        let button  = (self.subviews[0].subviews[2] as! UIButton)
        button.titleLabel?.font = font
    }
    
    
}
