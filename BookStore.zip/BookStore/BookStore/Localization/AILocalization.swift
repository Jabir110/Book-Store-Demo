//
//  AILocalization.swift
//  CASL
//
//  Created by agilemac-31 on 10/10/18.
//  Copyright © 2018 agilemac-31. All rights reserved.
//

import Foundation

//MARK:- ***************************************
//MARK:  ENUM LANGUAGE TYPE
//MARK: ***************************************
//MARK:-

enum AILanguage: String {
    
    case english = "en"
    case arabic = "ar"
    
    var languageName: String {
        var name: String = ""
        switch self {
        case .english:
            name = "English"
        case .arabic:
            name = "Arabic"
        }
        return name
    }
    
    var languageNameForApi: String {
        var name: String = ""
        switch self {
        case .english:
            name = "en"
        case .arabic:
            name = "ar"
        }
        return name
    }
    
}

let Localization: AILocalization = AILocalization.shared

@objc class AILocalization: NSObject {
    
    static let shared = AILocalization()
    
    
    @objc func fetchCurrentLanguageIsEnglish()->Bool
    {
        return AILocalization.getCurruntDeviceLanguage() == .english ? true : false
    }
    
    //MARK:- ***************************************
    //MARK:  INIT TITLE STRINGS
    //MARK: ***************************************
    //MARK:-
    
    
    //MARK: Screen Titles
    var screenTitleLogin = ""
    var screenTitleSignUp = ""
    var screenTitleForgotPassword = ""
    var screenTitleFilter: String = ""
    var screenTitleNationality: String = ""
    var screenTitleNotification: String = ""
    var screenTitleChat: String = ""
    var screenTitleReview: String = ""
    var screenTitleUserListDelivery: String = ""
    var screenTitlePost: String = ""
    var screenTitleComments: String = ""
    var screenTitleReportForUser: String = ""
    var screenTitleReportForOrder : String = ""
    var screenTitleProfile: String = ""
    var screenTitleSkills: String = ""
    var screenTitleOrder: String = ""
    var screenTitlePostOrder: String = ""
    var screenTitleOrderDetails: String = ""
    var screenTitleSettings: String = ""
    var screenTitleUpdateBank: String = ""
    var screenTitleWithdraw: String = ""
    var screenTitleWalletSummary: String = ""
    var screenTitleChangePassword: String = ""
    var screenTitleUploadDocs: String = ""
    var screenTitleWithdrawHistory: String = ""
    var screenTitleWithAddReview = ""
    var screenTitleHome = ""
    var screenTitleRequestForServiceProvider = ""
    var screenTitleLangauge = ""
    var screenTitleEditProfile = ""
    var screenTitleCategoryList = ""
    
    var screenTitleCategory = ""
    var screenTitleCity = ""
    var screenTitleState = ""
    var screenTitleCountry = ""

    //MARK: Button Titles
    var buttonTitleSignUp = ""
    var buttonTitleLogin = ""
    var buttonTitleForgot = ""

    var buttonTitleResetPassword = ""
    var buttonTitleApply = ""
    var buttonTitleSubmit = ""
    var buttonTitleAccept = ""
    var buttonTitleReject = ""
    var buttonTitleRequestForPayment = ""
    var buttonTitleRequested = ""
    var buttonTitleReceived = ""
    var buttonTitlePay = ""
    var buttonTitlePaidAmount = ""
    var buttonTitleRequestSend = ""
    var buttonTitleSendRequest = ""
    var buttonTitleUpdateBankDeatils = ""
    var buttonTitleAddBankDetails = ""
    var buttonTitleWithdraw = ""
    var buttonTitleUploadDocs = ""
    var buttonTitleAlreadyMember = ""
    var buttonTitleAdd = ""
    var buttonTitleOnTheWay = ""
    var buttonTitleWorking = ""
    var buttonTitleChatting = ""
    var buttonTitleCall = ""
    var buttonTitleReport = ""
    var buttonTitleFeedback = ""
    var buttonTitleRequeste = ""
    var buttonTitleYes = ""
    var buttonTitleNo = ""
    var buttonTitleCancel = ""
    var buttonTitleRetry = ""
    var buttonTitleOk = ""
    var buttonTitleUpdate = ""
    var buttonTitleSave = ""
    var buttonTitleAmountRequested = ""
    var buttonTitleAmountReceived = ""
    var buttonTitleServiceRequester = ""
    var buttonTitleYourBidAmount = ""
    var buttonTitleViewAllComment = ""

    var buttonTitleInformation = ""
    var buttonTitleAlbum = ""
    var buttonTitleReview = ""

    var buttonTitleAddCategories = ""
    var buttonTitleAddSkills = ""
    var buttonTitleAddNationality = ""
    var buttonTitleAddCity = ""
    var buttonTitleAddState = ""
    var buttonTitleAddCountry = ""
    
    var buttonTitleCurrent = ""
    var buttonTitleUpcoming = ""
    var buttonTitleDone = ""
    var buttonTitleCanceled = ""


    //MARK: Textfiled Placeholder Titles
    
    var txtFieldPlaceholderLocationOfTheServiceProvider = ""
    var txtFieldPlaceholderSkills = ""
    var txtFieldPlaceholderYourLocaiton = ""
    var txtFieldPlaceholderWriteTheRequirement = ""
    var txtFieldPlaceholderRequestersImage = ""
    var txtFieldPlaceholderDistance = ""
    var txtFieldPlaceholderJobAmount = ""
    var txtFieldPlaceholderJobCost = ""
    var txtFieldPlaceholderTotalTaskDone = ""
    var txtFieldPlaceholderOrder = ""
    var txtFieldPlaceholderAbout = ""
    var txtFieldPlaceholderAccountHolderName = ""
    var txtFieldPlaceholderAccountNumber = ""
    var txtFieldPlaceholderBankName = ""
    var txtFieldPlaceholderRoutingNumber = ""
    var txtFieldPlaceholderCurrentPassword = ""
    var txtFieldPlaceholderNewPassword = ""
    var txtFieldPlaceholderConfirmPassword = ""
    var txtFieldPlaceholderDocuments = ""
    var txtFieldPlaceholderEmail = ""
    var txtFieldPlaceholderPassword = ""
    var txtFieldPlaceholderFullName = ""
    var txtFieldPlaceholderUserName = ""
    var txtFieldPlaceholderNickName = ""
    var txtFieldPlaceholderMobileNumber = ""
    var txtFieldPlaceholderNationality = ""
    var txtFieldPlaceholderCountry = ""
    var txtFieldPlaceholderCity = ""
    var txtFieldPlaceholderState = ""
    var txtFieldPlaceholderBirthDate = ""
    var txtFieldPlaceholderJob = ""

    
    //MARK: Other Placeholder Labels
    var placeholderRequestForServiceProvider = ""
    var placeholderIdCardUpload = ""
    var placeholderTermsAndConditions = ""
    var placeholderEnteremailResetPassword = ""
    var placeholderRattings = ""
    var placeholderComments = ""
    var placeholderLabelOrderId = ""
    var placeholderLabelOrderIdSmall = ""
    
    var placeholderLabelTag = ""
    var placeholderLabelDate = ""
    var placeholderLabelServiceRequest = ""
    var placeholderLabelServiceProvider = ""
    var placeholderLabelServiceRequester = ""
    var placeholderLabelCreatedDate = ""
    var placeholderLabelJobDate = ""
    var placeholderLabelJobAmount = ""
    var placeholderLabelYourBidAmount = ""
    var placeholderLabelRequesterImage = ""
    var placeholderLabelProviderImage = ""
    var placeholderLabelBidAmount = ""
    var placeholderLabelEnterBidAmount = ""
    var placeholderLabelOnline = ""
    var placeholderLabelPaymentOptions = ""
    var placeholderLabelRequestForServiceProviderRole = ""
    var placeholderLabelBuyPackage = ""
    var placeholderLabelReviews = ""
    var placeholderLabelBuyResults = ""
    var placeholderLabelMap = ""
    var placeholderLabelKm = ""
    var placeholderLabelAlbum = ""
    var placeholderLabelGender = ""
    var placeholderLabelSkills = ""
    var placeholderLabelSkillsCaps = ""

    var placeholderLabelMale = ""
    var placeholderLabelFemale = ""
    var placeholderLabelBoth = ""

    var placeholderLabelAbout = ""
    var placeholderLabelDistance = ""
    var placeholderLabelComments = ""
    var placeholderLabelRattings = ""
    var placeholderLabelTotalTaskDone = ""
    var placeholderLabelOrder = ""
    var placeholderLabelWithdrawAmount = ""
    var placeholderLabelTotalEarningsToBeWithdraw = ""
    var placeholderLabelListOfEarnings = ""
    var placeholderLabelDocuments = ""

    var placeholderLabelSendRequestMessage = ""
    var placeholderLabelApprovedRequestMessage = ""
    var placeholderLabelAlreadySentRequestMessage = ""
    
    var placeholderLabelCategory = ""
    var placeholderLabelRadius = ""
    var placeholderLabelAge = ""

    var placeholderLabelMin = ""
    var placeholderLabelMax = ""
    
    var placeholderLabelProfile = ""
    var placeholderLabelUploadDocs = ""

    var placeholderLabelChangePassword = ""
    var placeholderLabelWalletSummary = ""
    var placeholderLabelUpdateBank = ""
    var placeholderLabelLanguage = ""
    var placeholderLabelLogout = ""
    
    var placeholderNoDataFoundBlank = ""
    var placeholderNoUserFoundBlank = ""

    
    var placeholderLabelWithdraw = ""
    var placeholderLabelWithdrawHistory = ""

    //MARK: Messages
    var messageInternetConnectionAlert = ""
    var messageSomethingWentWrongAlertMessage = ""
    var messageLogoutAlertMessage = ""
    var messageCompulsoryLogoutAlertMessage = ""
    
    //MARK: Validation Messages
    
    var message_Email_Blank = ""
    var message_Email_NotValid = ""
    var message_Password_Blank = ""
    var message_Password_NotValid = ""
    var message_Username_Blank = ""
    var message_Username_Length_NotValid = ""
    var message_Nickname_Blank = ""
    var message_Nickname_Length_NotValid = ""
    var message_FullName_Blank = ""
    var message_FullName_NotValid = ""
    var message_SignUpPassword_Blank = ""
    var message_SignUpPassword_NotValid = ""
    var message_ConfirmPassword_Blank = ""
    var message_ConfirmPassword_NotValid = ""
    var message_PasswordNotMatch = ""
    var message_OldPassword_Blank = ""
    var message_OldPassword_NotValid = ""
    var message_New_Password_Blank = ""
    var message_New_Password_NotValid = ""
    var message_Birthday_Blank = ""
    var message_Phone_Blank = ""
    var message_Phone_Length_NotValid = ""
    var message_Phone_Zero_NotValid = ""
    var message_Country_Blank = ""
    var message_Country_NotValid = ""
    var message_City_Blank = ""
    var message_City_NotValid = ""
    var message_State_Blank = ""
    var message_State_NotValid = ""
    var message_Nationality_Blank = ""
    var message_Nationality_NotValid = ""
    var message_TermsAndCondition_unChecked = ""
    var message_AccountHolderName_Blank = ""
    var message_AccountHolderName_NotValid = ""
    var message_AccountNumber_Blank = ""
    var message_AccountNumber_NotValid = ""
    var message_BankName_Blank = ""
    var message_BankName_NotValid = ""
    var message_RoutingNumber_Blank = ""
    var message_RoutingNumber_NotValid = ""
    var message_Skills_Blank = ""
    var message_Category_Blank = ""
    var message_Document_Blank = ""
    var message_Job_NotValid = ""
    var message_Job_Blank = ""
    var message_JobAmount_Blank = ""
    var message_JobRequirement_Blank = ""
    var message_Distance_Blank = ""
    var message_Amount_NotValid = ""
    var message_Amount_Validation = ""
    var message_Distance_Validation = ""
    var message_ReportComment_Blank = ""
    var message_Review_Blank = ""
    var message_Location_Blank = ""
    
    var currency = ""
    
    //MARK: init
    override init()
    {
        super.init()
        self.updateStringOnLanguageChange()
    }
    
    
    //MARK:- ***************************************
    //MARK:  TITLE STRINGS AS PER LANGUAGE
    //MARK: ***************************************
    //MARK:-
    
    func updateStringOnLanguageChange() {
        
        //MARK: Screen Titles
        
        screenTitleLogin = "screenTitleLogin".localized()
        screenTitleSignUp = "screenTitleSignUp".localized()
        screenTitleForgotPassword = "screenTitleForgotPassword".localized()
        screenTitleFilter = "screenTitleFilter".localized()
        screenTitleNationality = "screenTitleNationality".localized()
        screenTitleNotification = "screenTitleNotification".localized()
        screenTitleChat = "screenTitleChat".localized()
        screenTitleReview = "screenTitleReview".localized()
        screenTitleOrder = "screenTitleOrder".localized()
        screenTitlePostOrder = "screenTitlePostOrder".localized()
        screenTitleOrderDetails = "screenTitleOrderDetails".localized()
        screenTitleUserListDelivery = "screenTitleUserListDelivery".localized()
        screenTitlePost = "screenTitlePost".localized()
        screenTitleComments = "screenTitleComments".localized()
        screenTitleReportForUser = "screenTitleReportForUser".localized()
        screenTitleReportForOrder = "screenTitleReportForOrder".localized()
        screenTitleProfile = "screenTitleProfile".localized()
        screenTitleSkills = "screenTitleSkills".localized()
        screenTitleSettings = "screenTitleSettings".localized()
        screenTitleUpdateBank = "screenTitleUpdateBank".localized()
        screenTitleWithdraw = "screenTitleWithdraw".localized()
        screenTitleWalletSummary = "screenTitleWalletSummary".localized()
        screenTitleChangePassword = "screenTitleChangePassword".localized()
        screenTitleUploadDocs = "screenTitleUploadDocs".localized()
        screenTitleWithdrawHistory = "screenTitleWithdrawHistory".localized()
        screenTitleWithAddReview = "screenTitleWithAddReview".localized()
        screenTitleHome = "screenTitleHome".localized()
        screenTitleRequestForServiceProvider = "screenTitleRequestForServiceProvider".localized()
        screenTitleLangauge = "screenTitleLangauge".localized()
        screenTitleEditProfile = "screenTitleEditProfile".localized()
        screenTitleCategoryList = "screenTitleCategoryList".localized()

        screenTitleCategory = "screenTitleCategory".localized()
        screenTitleCity = "screenTitleCity".localized()
        screenTitleState = "screenTitleState".localized()
        screenTitleCountry = "screenTitleCountry".localized()

        //MARK: Button Titles
        
        buttonTitleLogin = "buttonTitleLogin".localized()
        buttonTitleSignUp = "buttonTitleSignUp".localized()
        buttonTitleForgot = "buttonTitleForgot".localized()
        buttonTitleResetPassword = "buttonTitleResetPassword".localized()
        buttonTitleApply = "buttonTitleApply".localized()
        buttonTitleSubmit = "buttonTitleSubmit".localized()
        buttonTitleAccept = "buttonTitleAccept".localized()
        buttonTitleReject = "buttonTitleReject".localized()
        buttonTitleRequestForPayment = "buttonTitleRequestForPayment".localized()
        buttonTitleRequested = "buttonTitleRequested".localized()
        buttonTitleReceived = "buttonTitleReceived".localized()
        buttonTitlePay = "buttonTitlePay".localized()
        buttonTitlePaidAmount = "buttonTitlePaidAmount".localized()
        buttonTitleRequestSend = "buttonTitleRequestSend".localized()
        buttonTitleSendRequest = "buttonTitleSendRequest".localized()
        buttonTitleUpdateBankDeatils = "buttonTitleUpdateBankDeatils".localized()
        buttonTitleAddBankDetails = "buttonTitleAddBankDetails".localized()
        buttonTitleWithdraw = "buttonTitleWithdraw".localized()
        buttonTitleUploadDocs = "buttonTitleUploadDocs".localized()
        buttonTitleAlreadyMember = "buttonTitleAlreadyMember".localized()
        buttonTitleAdd = "buttonTitleAdd".localized()
        buttonTitleOnTheWay = "buttonTitleOnTheWay".localized()
        buttonTitleWorking = "buttonTitleWorking".localized()
        buttonTitleChatting = "buttonTitleChatting".localized()
        buttonTitleCall = "buttonTitleCall".localized()
        buttonTitleReport = "buttonTitleReport".localized()
        buttonTitleFeedback = "buttonTitleFeedback".localized()
        buttonTitleRequeste = "buttonTitleRequeste".localized()
        buttonTitleYes = "buttonTitleYes".localized()
        buttonTitleNo = "buttonTitleNo".localized()
        buttonTitleCancel = "buttonTitleCancel".localized()
        buttonTitleRetry = "buttonTitleRetry".localized()
        buttonTitleOk = "buttonTitleOk".localized()
        buttonTitleUpdate = "buttonTitleUpdate".localized()
        buttonTitleSave = "buttonTitleSave".localized()
        buttonTitleAmountRequested = "buttonTitleAmountRequested".localized()
        buttonTitleAmountReceived = "buttonTitleAmountReceived".localized()
        buttonTitleServiceRequester = "buttonTitleServiceRequester".localized()
        buttonTitleYourBidAmount = "buttonTitleYourBidAmount".localized()
        buttonTitleViewAllComment = "buttonTitleViewAllComment".localized()

        buttonTitleInformation = "buttonTitleInformation".localized()
        buttonTitleAlbum = "buttonTitleAlbum".localized()
        buttonTitleReview = "buttonTitleReview".localized()

        buttonTitleAddCategories = "buttonTitleAddCategories".localized()
        buttonTitleAddSkills = "buttonTitleAddSkills".localized()
        buttonTitleAddNationality = "buttonTitleAddNationality".localized()
        buttonTitleAddCity = "buttonTitleAddCity".localized()
        buttonTitleAddState = "buttonTitleAddState".localized()
        buttonTitleAddCountry = "buttonTitleAddCountry".localized()        

        buttonTitleCurrent = "buttonTitleCurrent".localized()
        buttonTitleUpcoming = "buttonTitleUpcoming".localized()
        buttonTitleDone = "buttonTitleDone".localized()
        buttonTitleCanceled = "buttonTitleCanceled".localized()

        //MARK: Textfiled Placeholder Titles
        
        txtFieldPlaceholderEmail = "txtFieldPlaceholderEmail".localized()
        txtFieldPlaceholderPassword = "txtFieldPlaceholderPassword".localized()
        txtFieldPlaceholderFullName = "txtFieldPlaceholderFullName".localized()
        txtFieldPlaceholderUserName = "txtFieldPlaceholderUserName".localized()
        txtFieldPlaceholderNickName = "txtFieldPlaceholderNickName".localized()
        txtFieldPlaceholderMobileNumber = "txtFieldPlaceholderMobileNumber".localized()
        txtFieldPlaceholderNationality = "txtFieldPlaceholderNationality".localized()
        txtFieldPlaceholderCountry = "txtFieldPlaceholderCountry".localized()
        txtFieldPlaceholderCity = "txtFieldPlaceholderCity".localized()
        txtFieldPlaceholderState = "txtFieldPlaceholderState".localized()
        txtFieldPlaceholderBirthDate = "txtFieldPlaceholderBirthDate".localized()
        txtFieldPlaceholderLocationOfTheServiceProvider = "txtFieldPlaceholderLocationOfTheServiceProvider".localized()
        txtFieldPlaceholderSkills = "txtFieldPlaceholderSkills".localized()
       
        txtFieldPlaceholderYourLocaiton = "txtFieldPlaceholderYourLocaiton".localized()
        txtFieldPlaceholderWriteTheRequirement = "txtFieldPlaceholderWriteTheRequirement".localized()
        txtFieldPlaceholderRequestersImage = "txtFieldPlaceholderRequestersImage".localized()
        txtFieldPlaceholderDistance = "txtFieldPlaceholderDistance".localized()
        txtFieldPlaceholderJobAmount = "txtFieldPlaceholderJobAmount".localized()
        txtFieldPlaceholderJobCost = "txtFieldPlaceholderJobCost".localized()
        txtFieldPlaceholderTotalTaskDone = "txtFieldPlaceholderTotalTaskDone".localized()
        txtFieldPlaceholderOrder = "txtFieldPlaceholderOrder".localized()
        txtFieldPlaceholderAbout = "txtFieldPlaceholderAbout".localized()
        txtFieldPlaceholderAccountHolderName = "txtFieldPlaceholderAccountHolderName".localized()
        txtFieldPlaceholderAccountNumber = "txtFieldPlaceholderAccountNumber".localized()
        txtFieldPlaceholderBankName = "txtFieldPlaceholderBankName".localized()
        txtFieldPlaceholderRoutingNumber = "txtFieldPlaceholderRoutingNumber".localized()
        txtFieldPlaceholderCurrentPassword = "txtFieldPlaceholderCurrentPassword".localized()
        txtFieldPlaceholderNewPassword = "txtFieldPlaceholderNewPassword".localized()
        txtFieldPlaceholderConfirmPassword = "txtFieldPlaceholderConfirmPassword".localized()
        txtFieldPlaceholderDocuments = "txtFieldPlaceholderDocuments".localized()
        txtFieldPlaceholderJob = "txtFieldPlaceholderJob".localized()

        //MARK: Other Placeholder Labels
        placeholderRequestForServiceProvider = "placeholderRequestForServiceProvider".localized()
        placeholderIdCardUpload = "placeholderIdCardUpload".localized()
        placeholderTermsAndConditions = "placeholderTermsAndConditions".localized()
        placeholderEnteremailResetPassword = "placeholderEnteremailResetPassword".localized()
        placeholderRattings = "placeholderRattings".localized()
        placeholderComments = "placeholderComments".localized()
        placeholderLabelOrderId = "placeholderLabelOrderId".localized()
        placeholderLabelOrderIdSmall = "placeholderLabelOrderIdSmall".localized()
        placeholderLabelTag = "placeholderLabelTag".localized()
        placeholderLabelDate = "placeholderLabelDate".localized()
        placeholderLabelServiceRequest = "placeholderLabelServiceRequest".localized()
        placeholderLabelServiceProvider = "placeholderLabelServiceProvider".localized()
        
        placeholderLabelServiceRequester = "placeholderLabelServiceRequester".localized()
        placeholderLabelCreatedDate = "placeholderLabelCreatedDate".localized()
        placeholderLabelJobDate = "placeholderLabelJobDate".localized()
        placeholderLabelJobAmount = "placeholderLabelJobAmount".localized()
        placeholderLabelYourBidAmount = "placeholderLabelYourBidAmount".localized()
        placeholderLabelRequesterImage = "placeholderLabelRequesterImage".localized()
        placeholderLabelProviderImage = "placeholderLabelProviderImage".localized()
        placeholderLabelBidAmount = "placeholderLabelBidAmount".localized()
        placeholderLabelEnterBidAmount = "placeholderLabelEnterBidAmount".localized()
        placeholderLabelOnline = "placeholderLabelOnline".localized()
        placeholderLabelPaymentOptions = "placeholderLabelPaymentOptions".localized()
        placeholderLabelRequestForServiceProviderRole = "placeholderLabelRequestForServiceProviderRole".localized()
        placeholderLabelBuyPackage = "placeholderLabelBuyPackage".localized()
        placeholderLabelReviews = "placeholderLabelReviews".localized()
        placeholderLabelBuyResults = "placeholderLabelBuyResults".localized()
        placeholderLabelMap = "placeholderLabelMap".localized()
        placeholderLabelKm = "placeholderLabelKm".localized()
        placeholderLabelAlbum = "placeholderLabelAlbum".localized()
        placeholderLabelGender = "placeholderLabelGender".localized()
        placeholderLabelSkills = "placeholderLabelSkills".localized()
        placeholderLabelSkillsCaps = "placeholderLabelSkillsCaps".localized()
        placeholderLabelMale = "placeholderLabelMale".localized()
        placeholderLabelFemale = "placeholderLabelFemale".localized()
        placeholderLabelBoth = "placeholderLabelBoth".localized()
        placeholderLabelAbout = "placeholderLabelAbout".localized()
        placeholderLabelDistance = "placeholderLabelDistance".localized()
        placeholderLabelComments = "placeholderLabelComments".localized()
        placeholderLabelRattings = "placeholderLabelRattings".localized()
        placeholderLabelTotalTaskDone = "placeholderLabelTotalTaskDone".localized()
        placeholderLabelOrder = "placeholderLabelOrder".localized()

        placeholderLabelWithdrawAmount = "placeholderLabelWithdrawAmount".localized()
        placeholderLabelTotalEarningsToBeWithdraw = "placeholderLabelTotalEarningsToBeWithdraw".localized()
        placeholderLabelListOfEarnings = "placeholderLabelListOfEarnings".localized()
        placeholderLabelDocuments = "placeholderLabelDocuments".localized()

        placeholderLabelSendRequestMessage = "placeholderLabelSendRequestMessage".localized()
        placeholderLabelApprovedRequestMessage = "placeholderLabelApprovedRequestMessage".localized()
        placeholderLabelAlreadySentRequestMessage = "placeholderLabelAlreadySentRequestMessage".localized()
        
        placeholderLabelCategory = "placeholderLabelCategory".localized()
        placeholderLabelRadius = "placeholderLabelRadius".localized()
        placeholderLabelAge = "placeholderLabelAge".localized()

        placeholderLabelMin = "placeholderLabelMin".localized()
        placeholderLabelMax = "placeholderLabelMax".localized()
        placeholderLabelProfile = "placeholderLabelProfile".localized()

        placeholderLabelUploadDocs = "placeholderLabelUploadDocs".localized()
        placeholderLabelChangePassword = "placeholderLabelChangePassword".localized()
        placeholderLabelWalletSummary = "placeholderLabelWalletSummary".localized()
        placeholderLabelUpdateBank = "placeholderLabelUpdateBank".localized()
        placeholderLabelLanguage = "placeholderLabelLanguage".localized()
        placeholderLabelLogout = "placeholderLabelLogout".localized()
        placeholderNoDataFoundBlank = "placeholderNoDataFoundBlank".localized()
        placeholderNoUserFoundBlank = "placeholderNoUserFoundBlank".localized()

        placeholderLabelWithdraw = "placeholderLabelWithdraw".localized()
        placeholderLabelWithdrawHistory = "placeholderLabelWithdrawHistory".localized()

        //MARK: Messages
        messageInternetConnectionAlert = "messageInternetConnectionAlert".localized()
        messageSomethingWentWrongAlertMessage = "messageSomethingWentWrongAlertMessage".localized()
        messageLogoutAlertMessage = "messageLogoutAlertMessage".localized()
        messageCompulsoryLogoutAlertMessage = "messageCompulsoryLogoutAlertMessage".localized()
        
        //MARK: Validation Messages
        
        message_Email_Blank = "message_Email_Blank".localized()
        message_Email_NotValid = "message_Email_NotValid".localized()
        message_Password_Blank = "message_Password_Blank".localized()
        message_Password_NotValid = "message_Password_NotValid".localized()
        message_Username_Blank = "message_Username_Blank".localized()
        message_Username_Length_NotValid = "message_Username_Length_NotValid".localized()
        message_Nickname_Blank = "message_Nickname_Blank".localized()
        message_Nickname_Length_NotValid = "message_Nickname_Length_NotValid".localized()
        message_FullName_Blank = "message_FullName_Blank".localized()
        message_FullName_NotValid = "message_FullName_NotValid".localized()
        message_SignUpPassword_Blank = "message_SignUpPassword_Blank".localized()
        message_SignUpPassword_NotValid = "message_SignUpPassword_NotValid".localized()
        message_ConfirmPassword_Blank = "message_ConfirmPassword_Blank".localized()
        message_ConfirmPassword_NotValid = "message_ConfirmPassword_NotValid".localized()
        message_PasswordNotMatch = "message_PasswordNotMatch".localized()
        message_OldPassword_Blank = "message_OldPassword_Blank".localized()
        message_OldPassword_NotValid = "message_OldPassword_NotValid".localized()
        message_New_Password_Blank = "message_New_Password_Blank".localized()
        message_New_Password_NotValid = "message_New_Password_NotValid".localized()
        message_Birthday_Blank = "message_Birthday_Blank".localized()
        message_Phone_Blank = "message_Phone_Blank".localized()
        message_Phone_Length_NotValid = "message_Phone_Length_NotValid".localized()
        message_Phone_Zero_NotValid = "message_Phone_Zero_NotValid".localized()
        message_Country_Blank = "message_Country_Blank".localized()
        message_Country_NotValid = "message_Country_NotValid".localized()
        message_City_Blank = "message_City_Blank".localized()
        message_City_NotValid = "message_City_NotValid".localized()
        message_State_Blank = "message_State_Blank".localized()
        message_State_NotValid = "message_State_NotValid".localized()
        message_Nationality_Blank = "message_Nationality_Blank".localized()
        message_Nationality_NotValid = "message_Nationality_NotValid".localized()
        message_TermsAndCondition_unChecked = "message_TermsAndCondition_unChecked".localized()
        message_AccountHolderName_Blank = "message_AccountHolderName_Blank".localized()
        message_AccountHolderName_NotValid = "message_AccountHolderName_NotValid".localized()
        message_AccountNumber_Blank = "message_AccountNumber_Blank".localized()
        message_AccountNumber_NotValid = "message_AccountNumber_NotValid".localized()
        message_BankName_Blank = "message_BankName_Blank".localized()
        message_BankName_NotValid = "message_BankName_NotValid".localized()
        message_RoutingNumber_Blank = "message_RoutingNumber_Blank".localized()
        message_RoutingNumber_NotValid = "message_RoutingNumber_NotValid".localized()
        message_Category_Blank = "message_Category_Blank".localized()
        message_Skills_Blank = "message_Skills_Blank".localized()
        message_Document_Blank = "message_Document_Blank".localized()
        
        message_Job_NotValid = "message_Job_NotValid".localized()
        message_Job_Blank = "message_Job_Blank".localized()
        message_JobAmount_Blank = "message_JobAmount_Blank".localized()
        message_JobRequirement_Blank = "message_JobRequirement_Blank".localized()
        message_Distance_Blank = "message_Distance_Blank".localized()
        message_Amount_NotValid = "message_Amount_NotValid".localized()
        message_Amount_Validation = "message_Amount_Validation".localized()
        message_Distance_Validation = "message_Distance_Validation".localized()
        message_ReportComment_Blank = "message_ReportComment_Blank".localized()
        message_Review_Blank = "message_Review_Blank".localized()
        message_Location_Blank = "message_Location_Blank".localized()
        
        currency = "currency".localized()
    }
}

//MARK:- ***************************************
//MARK:  Localization Extension
//MARK: ***************************************
//MARK:-

extension AILocalization {
    class func getCurruntDeviceLanguage() -> AILanguage {
        
        var lang: AILanguage = AILanguage.english
        if let value = getUserDefaultsForKey(key: UserDefaultsKeys.appLanguage) as? String, let objLang = AILanguage.init(rawValue: value) {
            lang = objLang
        }
        return lang
    }
    
    class func setCurrentDeviceLanguageTo(lang: AILanguage, with completion: ( () -> Void)?) {
        if AILocalization.getCurruntDeviceLanguage() == lang { // No update in language
            if let completion = completion {
                completion()
            }
            return
        }
        
        let languageCodeToSet = lang.rawValue
        setUserDefaultsFor(object: languageCodeToSet as AnyObject, with: UserDefaultsKeys.appLanguage)
        AILocalization.shared.updateStringOnLanguageChange()
        if let completion = completion {
            completion()
        }
    }
    
    class func toggleLanguage() {
        let languageCodeToSet = AILocalization.getCurruntDeviceLanguage()
        setUserDefaultsFor(object: languageCodeToSet == AILanguage.english ? AILanguage.arabic.rawValue as AnyObject : AILanguage.english.rawValue as AnyObject, with: UserDefaultsKeys.appLanguage)
    }
}

extension String {
    
    func localized(using tableName: String?, in bundle: Bundle?) -> String {
        
        let bundle: Bundle = bundle ?? .main
        
        let currentLanguage = AILocalization.getCurruntDeviceLanguage()
        
        if let path = bundle.path(forResource: currentLanguage.rawValue, ofType: "lproj"), let bundle = Bundle(path: path) {
            return bundle.localizedString(forKey: self, value: nil, table: tableName)
        }
        else if let path = bundle.path(forResource: "Base", ofType: "lproj"),  let bundle = Bundle(path: path)   {
            return bundle.localizedString(forKey: self, value: nil, table: tableName)
        }
        return self
    }
    
    func localized() -> String {
        return localized(using: nil, in: .main)
    }
}


