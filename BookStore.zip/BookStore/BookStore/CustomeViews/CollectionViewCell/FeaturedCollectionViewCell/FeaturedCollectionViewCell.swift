//
//  FeaturedCollectionViewCell.swift
//  BookStore
//
//  Created by agilemac-9 on 8/19/19.
//  Copyright © 2019 Agileinfoways. All rights reserved.
//

import UIKit

class FeaturedCollectionViewCell: SPCollectionViewCell {

    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var imgBook: UIImageView!
    @IBOutlet weak var lblBookName: SPLabel!
    @IBOutlet weak var btnDownload: SPButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        setupUI()
        // Initialization code
    }

    func setupUI() {
        
        imgBook.addShadowWithCorner()
        imgBook.layer.cornerRadius = 5.0
        
        btnDownload.addBorder(color: UIColor.appColor.appGreenColor, width: 1.0)
        btnDownload.layer.cornerRadius = 5.0
        btnDownload.setTitleColor(UIColor.appColor.appGreenColor, for: .normal)
        
        lblBookName.textColor = UIColor.appColor.appBlackColor
    }

}
