//
//  HomeCollectionViewCell.swift
//  BookStore
//
//  Created by agilemac-9 on 8/20/19.
//  Copyright © 2019 Agileinfoways. All rights reserved.
//

import UIKit

class HomeCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var imgView: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        setupUI()
        // Initialization code
    }

    func setupUI() {
        
        imgView.addShadowWithCorner()
        imgView.layer.cornerRadius = 5.0
        imgView.clipsToBounds = true
    }

}
