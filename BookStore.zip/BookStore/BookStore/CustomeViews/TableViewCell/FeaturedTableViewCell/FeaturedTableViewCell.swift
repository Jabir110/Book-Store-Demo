//
//  FeaturedTableViewCell.swift
//  BookStore
//
//  Created by agilemac-9 on 8/19/19.
//  Copyright © 2019 Agileinfoways. All rights reserved.
//

import UIKit

class FeaturedTableViewCell: SPTableViewCell {

    @IBOutlet weak var faeturedCollectionView: FeaturedCollectionView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
