//
//  HomeSectionHeaderView.swift
//  BookStore
//
//  Created by agilemac-9 on 8/20/19.
//  Copyright © 2019 Agileinfoways. All rights reserved.
//

import UIKit

class HomeSectionHeaderView: UITableViewHeaderFooterView {
    
    //MARK:- OUTLETS -
    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var lblTitle : SPLabel!
    
    //MARK:- PROPERTIES -
    let kCONTENT_XIB_NAME = "HomeSectionHeaderView"

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        commonInit()
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
    }
    
    override func draw(_ rect: CGRect) {
        super.draw(rect)
    }
    
    //MARK:- COMMON INIT -
    func commonInit() {
        Bundle.main.loadNibNamed(kCONTENT_XIB_NAME, owner: self, options: nil)
        //contentView.fixInView(self)
        self.lblTitle.textColor = UIColor.appColor.appBlackColor
    }
    
    //MARK:- UPDATE VIEW -
    func updateViewWith(title: String) {
        lblTitle.text = title
    }
    
}
