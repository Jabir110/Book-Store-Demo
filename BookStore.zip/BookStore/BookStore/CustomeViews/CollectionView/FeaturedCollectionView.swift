//
//  HomeCollectionView.swift
//  BookStore
//
//  Created by agilemac-9 on 8/19/19.
//  Copyright © 2019 Agileinfoways. All rights reserved.
//

import UIKit

class FeaturedCollectionView: SPCollectionView {
    
    //MARK:_ PROPERTIES -
    // var arrDocuments : [FileModel] = []
    
    //MARK:- BLOCK PROPERTIES -
    var blockSelectedItemCollection:((Int)->Void)?
    
    //MARK:- AWAKE FROM NIB -
    override func awakeFromNib() {
        super.awakeFromNib()
        self.setUpUI()
    }
    
    //MARK:- SETUP UI -
    func setUpUI() {
        self.registerCell(FeaturedCollectionViewCell.self)
        
        let flowLayout: UICollectionViewFlowLayout = UICollectionViewFlowLayout()
        flowLayout.scrollDirection = .horizontal
        self.collectionViewLayout = flowLayout
        self.contentInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
        self.allowsMultipleSelection = false
        self.isPagingEnabled = false
        self.backgroundColor = UIColor.clear
    }
    
    // MARK:- UICOLLECTIONVIEW DATASOURCE -
    override func numberOfSections(in collectionView: UICollectionView) -> Int
    {
        return 1
    }
    
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        return 5
    }
    
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        let cell:FeaturedCollectionViewCell = self.dequeueReusableCell(forIndexPath: indexPath)
        return cell
    }
    
    //MARK:- COLLECTIONVIEW  FLOWLAYOUT DELEGATE -
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 15
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets.init(top: 0.0, left: 15.0, bottom: 0.0, right: 15.0)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        let cellWidth   = self.frame.size.height/2 - 10
        let cellHeight  = self.frame.size.height
        return CGSize(width: cellWidth , height: cellHeight)
    }
    
    //MARK:- COLLECTIONVIEW DELEGATE -
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        if self.blockSelectedItemCollection != nil {
            self.blockSelectedItemCollection!(indexPath.row)
        }
    }
    /*
     // Only override draw() if you perform custom drawing.
     // An empty implementation adversely affects performance during animation.
     override func draw(_ rect: CGRect) {
     // Drawing code
     }
     */
    
}
