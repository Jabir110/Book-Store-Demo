//
//  HomeTableView.swift
//  BookStore
//
//  Created by agilemac-9 on 8/9/19.
//  Copyright © 2019 Agileinfoways. All rights reserved.
//

import UIKit

class HomeTableView: SPTableView {

    // MARK: - PROPERTIES -
    // var arrCategoryList: [CategoryListModel] = []
    
    //MARK:- BLOCK PROPERTIES -
    var blockTableViewDidSelectAtIndexPath: ((IndexPath) -> Void)?
    
    // MARK: - INIT METHODS -
    override func awakeFromNib() {
        super.awakeFromNib()
        self.contentInset = UIEdgeInsets(top: 15.0, left: 0.0, bottom: 15.0, right: 0.0)
        
        // CONFIGURATION
        self.backgroundColor = UIColor.clear
        self.estimatedRowHeight = 500.0
        self.rowHeight = UITableView.automaticDimension
        
        self.isPullToRefreshEnabled = true
    }
    
    // MARK: - TABLEVIEW DATASOURCE & DELEGATE METHODS -
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 3
    }
    
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if section == 0 {
            return 1
        }else if section == 1 {
            return 1
        }else {
            return 5
        }
        
//        if self.arrCategoryList.count == 0 {
//            self.showPlaceHolder()
//        } else {
//            self.hidePlaceholder()
//        }
//        return arrCategoryList.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        
        if indexPath.section == 0 {
            let cell: HomeTableViewCell = self.dequeueReusableCell()
            return cell
        }
        else if indexPath.section == 1 {
            let cell: FeaturedTableViewCell = self.dequeueReusableCell()
            return cell
        }else {
            let cell: LatestedTableViewCell = self.dequeueReusableCell()
            return cell
        }
        //cell.updateDataWith(data: arrCategoryList[indexPath.row])
        
        //REGISTER BLOCK : View All Comments
        //        cell.blockCheckBoxButtonClicked_cell = { [unowned self] status in
        //            if self.blockCheckBoxButtonClicked_table != nil {
        //                self.arrCategoryList[indexPath.row].isSelected = status
        //                self.blockCheckBoxButtonClicked_table!(status)
        //            }
        //        }

    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        if section == 1 {
            
            let headerView:HomeSectionHeaderView = tableView.dequeueReusableHeaderFooterView(withIdentifier: "HomeSectionHeaderView") as! HomeSectionHeaderView
            headerView.updateViewWith(title: "Featured")
            return headerView
            
            
        }
        else if section == 2 {
            let headerView:HomeSectionHeaderView = tableView.dequeueReusableHeaderFooterView(withIdentifier: "HomeSectionHeaderView") as! HomeSectionHeaderView
            headerView.updateViewWith(title: "Featured")
            return headerView
        }
        return UIView.init()
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 50.0
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        if self.blockTableViewDidSelectAtIndexPath != nil {
            self.blockTableViewDidSelectAtIndexPath!(indexPath)
        }
    }
}
